import math


G = 9.8
G_UNIVERSAL = 6.67e-11


def pedir_float(texto):
    while True:
        try:
            return float(input(texto))
        except:
            print("Entrada invalida.")


def pedir_int(texto):
    while True:
        try:
            return int(input(texto))
        except:
            print("Entrada invalida.")


def pedir_v0():
    modo = pedir_int("1 Reposo (v0=0), 2 Con v0: ")
    if modo == 1:
        return 0.0
    return pedir_float("v0: ")


def mostrar_error():
    print("Error")


def pausa():
    input("Enter para continuar...")
    print("")


def cinematica_velocidad():
    d = pedir_float("d (m): ")
    t = pedir_float("t (s): ")
    if t == 0:
        mostrar_error()
        return
    v = d / t
    print("v = d / t")
    print("v = " + str(d) + " / " + str(t))
    print("v = " + str(v) + " m/s")


def cinematica_mrua():
    print("1 Velocidad (v)")
    print("2 Posicion (x)")
    print("3 Aceleracion (a)")
    print("4 Tiempo con v")
    print("5 Sin tiempo (v o x)")
    print("6 Tiempo sin v")
    sel = pedir_int("Opcion: ")

    if sel == 1:
        v0 = pedir_v0()
        a = pedir_float("a: ")
        t = pedir_float("t: ")
        v = v0 + a * t
        print("v = v0 + a*t")
        print("v = " + str(v) + " m/s")
    elif sel == 2:
        v0 = pedir_v0()
        a = pedir_float("a: ")
        t = pedir_float("t: ")
        x = v0 * t + 0.5 * a * (t ** 2)
        print("x = v0*t + 0.5*a*t^2")
        print("x = " + str(x) + " m")
    elif sel == 3:
        v = pedir_float("v: ")
        v0 = pedir_v0()
        t = pedir_float("t: ")
        if t == 0:
            mostrar_error()
            return
        a = (v - v0) / t
        print("a = (v - v0) / t")
        print("a = " + str(a) + " m/s^2")
    elif sel == 4:
        v = pedir_float("v: ")
        v0 = pedir_v0()
        a = pedir_float("a: ")
        if a == 0:
            mostrar_error()
            return
        t = (v - v0) / a
        print("t = (v - v0) / a")
        print("t = " + str(t) + " s")
    elif sel == 5:
        print("1 Velocidad (v)")
        print("2 Posicion (x)")
        sub = pedir_int("Opcion: ")
        if sub == 1:
            v0 = pedir_v0()
            a = pedir_float("a: ")
            x = pedir_float("x: ")
            valor = v0 ** 2 + 2 * a * x
            if valor < 0:
                mostrar_error()
                return
            v = math.sqrt(valor)
            print("v^2 = v0^2 + 2*a*x")
            print("v = " + str(v) + " m/s")
        elif sub == 2:
            v = pedir_float("v: ")
            v0 = pedir_v0()
            a = pedir_float("a: ")
            if a == 0:
                mostrar_error()
                return
            x = (v ** 2 - v0 ** 2) / (2 * a)
            print("x = (v^2 - v0^2) / (2*a)")
            print("x = " + str(x) + " m")
        else:
            print("Opcion invalida.")
    elif sel == 6:
        v0 = pedir_v0()
        a = pedir_float("a: ")
        x = pedir_float("x: ")
        if a == 0:
            mostrar_error()
            return
        valor = v0 ** 2 + 2 * a * x
        if valor < 0:
            mostrar_error()
            return
        t = (-v0 + math.sqrt(valor)) / a
        print("t = (-v0 + sqrt(v0^2 + 2*a*x)) / a")
        print("t = " + str(t) + " s")
    else:
        print("Opcion invalida.")


def elegir_gravedad():
    print("1 Sube (-)")
    print("2 Baja (+)")
    direccion = pedir_int("Opcion: ")
    if direccion == 1:
        return -G
    return G


def cinematica_caida_libre():
    g = elegir_gravedad()

    print("1 Velocidad (v)")
    print("2 Altura (h)")
    print("3 Tiempo con v")
    print("4 Sin tiempo (v o h)")
    print("5 Tiempo sin v")
    sel = pedir_int("Opcion: ")

    if sel == 1:
        v0 = pedir_v0()
        t = pedir_float("t: ")
        v = v0 + g * t
        print("v = v0 + g*t")
        print("v = " + str(v) + " m/s")
    elif sel == 2:
        v0 = pedir_v0()
        t = pedir_float("t: ")
        h = v0 * t + 0.5 * g * (t ** 2)
        print("h = v0*t + 0.5*g*t^2")
        print("h = " + str(h) + " m")
    elif sel == 3:
        v = pedir_float("v: ")
        v0 = pedir_v0()
        if g == 0:
            mostrar_error()
            return
        t = (v - v0) / g
        print("t = (v - v0) / g")
        print("t = " + str(t) + " s")
    elif sel == 4:
        print("1 Velocidad (v)")
        print("2 Altura (h)")
        sub = pedir_int("Opcion: ")
        if sub == 1:
            v0 = pedir_v0()
            h = pedir_float("h: ")
            valor = v0 ** 2 + 2 * g * h
            if valor < 0:
                mostrar_error()
                return
            v = math.sqrt(valor)
            print("v^2 = v0^2 + 2*g*h")
            print("v = " + str(v) + " m/s")
        elif sub == 2:
            v = pedir_float("v: ")
            v0 = pedir_v0()
            if g == 0:
                mostrar_error()
                return
            h = (v ** 2 - v0 ** 2) / (2 * g)
            print("h = (v^2 - v0^2) / (2*g)")
            print("h = " + str(h) + " m")
        else:
            print("Opcion invalida.")
    elif sel == 5:
        v0 = pedir_v0()
        h = pedir_float("h: ")
        if g == 0:
            mostrar_error()
            return
        valor = v0 ** 2 + 2 * g * h
        if valor < 0:
            mostrar_error()
            return
        t = (-v0 + math.sqrt(valor)) / g
        print("t = (-v0 + sqrt(v0^2 + 2*g*h)) / g")
        print("t = " + str(t) + " s")
    else:
        print("Opcion invalida.")


def menu_cinematica():
    print("1 Velocidad")
    print("2 MRUA")
    print("3 Caida libre")
    seleccion = pedir_int("Opcion: ")

    if seleccion == 1:
        cinematica_velocidad()
    elif seleccion == 2:
        cinematica_mrua()
    elif seleccion == 3:
        cinematica_caida_libre()
    else:
        print("Opcion invalida.")


def dinamica_fma():
    print("1 Fuerza (N)")
    print("2 Masa (kg)")
    print("3 Aceleracion (m/s^2)")
    sub = pedir_int("Opcion: ")

    if sub == 1:
        masa = pedir_float("Masa (kg): ")
        aceleracion = pedir_float("Aceleracion (m/s^2): ")
        fuerza = masa * aceleracion
        print("F = m*a")
        print("F = " + str(fuerza) + " N")
    elif sub == 2:
        fuerza = pedir_float("Fuerza (N): ")
        aceleracion = pedir_float("Aceleracion (m/s^2): ")
        if aceleracion == 0:
            mostrar_error()
            return
        masa = fuerza / aceleracion
        print("m = F/a")
        print("m = " + str(masa) + " kg")
    elif sub == 3:
        fuerza = pedir_float("Fuerza (N): ")
        masa = pedir_float("Masa (kg): ")
        if masa == 0:
            mostrar_error()
            return
        aceleracion = fuerza / masa
        print("a = F/m")
        print("a = " + str(aceleracion) + " m/s^2")
    else:
        print("Opcion invalida.")


def dinamica_peso():
    print("1 Calcular peso (N)")
    print("2 Calcular masa (kg)")
    sub = pedir_int("Opcion: ")

    if sub == 1:
        masa = pedir_float("Masa (kg): ")
        peso = masa * G
        print("W = m*g")
        print("W = " + str(peso) + " N")
    elif sub == 2:
        peso = pedir_float("Peso (N): ")
        masa = peso / G
        print("m = W/g")
        print("m = " + str(masa) + " kg")
    else:
        print("Opcion invalida.")


def dinamica_equilibrio():
    f1 = pedir_float("F1 (N): ")
    f2 = pedir_float("F2 (N): ")
    fn = f1 - f2
    print("SF = F1 - F2")
    print("Fn = " + str(fn) + " N")
    if fn == 0:
        print("Equilibrio")
    else:
        print("No equilibrio")


def dinamica_fuerza_neta():
    f1 = pedir_float("F1 (N): ")
    f2 = pedir_float("F2 (N): ")
    fn = f1 - f2
    print("Fn = F1 - F2")
    print("Fn = " + str(fn) + " N")


def menu_dinamica():
    print("1 Inercia")
    print("2 F = m*a")
    print("3 Accion-Reaccion")
    print("4 Peso")
    print("5 Equilibrio")
    print("6 Fuerza neta")
    seleccion = pedir_int("Opcion: ")

    if seleccion == 1:
        print("1ra ley de Newton")
        print("Si SF = 0, mantiene su estado.")
    elif seleccion == 2:
        dinamica_fma()
    elif seleccion == 3:
        print("3ra ley de Newton")
        print("Accion-Reaccion")
        print("F12 = -F21")
    elif seleccion == 4:
        dinamica_peso()
    elif seleccion == 5:
        dinamica_equilibrio()
    elif seleccion == 6:
        dinamica_fuerza_neta()
    else:
        print("Opcion invalida.")


def energia_trabajo():
    print("1 Sin angulo")
    print("2 Con angulo")
    sub = pedir_int("Opcion: ")

    if sub == 1:
        fuerza = pedir_float("Fuerza (N): ")
        desplazamiento = pedir_float("Distancia (m): ")
        trabajo = fuerza * desplazamiento
        print("T = F*d")
        print("T = " + str(trabajo) + " J")
    elif sub == 2:
        fuerza = pedir_float("Fuerza (N): ")
        desplazamiento = pedir_float("Distancia (m): ")
        angulo = pedir_float("Angulo (grados): ")
        trabajo = fuerza * desplazamiento * math.cos(math.radians(angulo))
        print("T = F*d*cos(theta)")
        print("T = " + str(trabajo) + " J")
    else:
        print("Opcion invalida.")


def energia_potencial():
    g = elegir_gravedad()
    masa = pedir_float("Masa (kg): ")
    altura = pedir_float("Altura (m): ")
    ep = masa * g * altura
    print("Ep = m*g*h")
    print("Ep = " + str(ep) + " J")


def energia_cinetica():
    masa = pedir_float("Masa (kg): ")
    velocidad = pedir_float("Velocidad (m/s): ")
    ec = 0.5 * masa * (velocidad ** 2)
    print("Ec = 0.5*m*v^2")
    print("Ec = " + str(ec) + " J")


def cambio_energia_cinetica():
    masa = pedir_float("Masa (kg): ")
    vi = pedir_float("Vi (m/s): ")
    vf = pedir_float("Vf (m/s): ")
    dec = 0.5 * masa * (vf ** 2 - vi ** 2)
    print("dEc = 0.5*m*(vf^2 - vi^2)")
    print("dEc = " + str(dec) + " J")


def energia_mecanica():
    ec = pedir_float("Ec (J): ")
    ep = pedir_float("Ep (J): ")
    em = ec + ep
    print("Em = Ec + Ep")
    print("Em = " + str(em) + " J")


def conservacion_energia():
    em = pedir_float("Em (J): ")
    ep = pedir_float("Ep (J): ")
    ec = em - ep
    print("Ec = Em - Ep")
    print("Ec = " + str(ec) + " J")


def relacion_v_h():
    print("1 v desde h")
    print("2 h desde v")
    sub = pedir_int("Opcion: ")
    g = elegir_gravedad()

    if sub == 1:
        altura = pedir_float("h (m): ")
        valor = 2 * g * altura
        if valor < 0:
            mostrar_error()
            return
        velocidad = math.sqrt(valor)
        print("v = sqrt(2*g*h)")
        print("v = " + str(velocidad) + " m/s")
    elif sub == 2:
        velocidad = pedir_float("v (m/s): ")
        if g == 0:
            mostrar_error()
            return
        altura = (velocidad ** 2) / (2 * g)
        print("h = v^2 / (2*g)")
        print("h = " + str(altura) + " m")
    else:
        print("Opcion invalida.")


def menu_energia():
    print("1 Trabajo")
    print("2 Energia potencial")
    print("3 Energia cinetica")
    print("4 Cambio de energia cinetica")
    print("5 Energia mecanica")
    print("6 Conservacion de energia")
    print("7 Relacion v-h")
    seleccion = pedir_int("Opcion: ")

    if seleccion == 1:
        energia_trabajo()
    elif seleccion == 2:
        energia_potencial()
    elif seleccion == 3:
        energia_cinetica()
    elif seleccion == 4:
        cambio_energia_cinetica()
    elif seleccion == 5:
        energia_mecanica()
    elif seleccion == 6:
        conservacion_energia()
    elif seleccion == 7:
        relacion_v_h()
    else:
        print("Opcion invalida.")


def gravitacion():
    masa1 = pedir_float("Masa 1 (kg): ")
    masa2 = pedir_float("Masa 2 (kg): ")
    distancia = pedir_float("Distancia (m): ")
    if distancia == 0:
        mostrar_error()
        return
    fuerza = (G_UNIVERSAL * masa1 * masa2) / (distancia ** 2)
    print("F = G*m1*m2/r^2")
    print("F = " + str(fuerza) + " N")


def conversion():
    print("1 km/h -> m/s")
    print("2 m/s -> km/h")
    seleccion = pedir_int("Opcion: ")
    velocidad = pedir_float("Velocidad: ")

    if seleccion == 1:
        resultado = velocidad / 3.6
        print("m/s = (km/h) / 3.6")
        print("v = " + str(resultado) + " m/s")
    elif seleccion == 2:
        resultado = velocidad * 3.6
        print("km/h = (m/s) * 3.6")
        print("v = " + str(resultado) + " km/h")
    else:
        print("Opcion invalida.")


def utilidades():
    print("1 Constantes")
    print("2 Ayuda")
    seleccion = pedir_int("Opcion: ")

    if seleccion == 1:
        print("g = 9.8 m/s^2")
        print("G = 6.67E-11")
    elif seleccion == 2:
        print("v = d/t")
        print("v = v0 + a*t")
        print("x = v0*t + 0.5*a*t^2")
        print("F = m*a")
        print("W = m*g")
        print("Ep = m*g*h")
        print("Ec = 0.5*m*v^2")
    else:
        print("Opcion invalida.")


def mostrar_menu_principal():
    print("1 Cinematica")
    print("2 Dinamica")
    print("3 Energia/Trabajo")
    print("4 Gravitacion")
    print("5 Conversion")
    print("6 Utilidades")
    print("0 Salir")


def main():
    while True:
        mostrar_menu_principal()
        opcion = pedir_int("Opcion: ")
        print("")

        if opcion == 1:
            menu_cinematica()
        elif opcion == 2:
            menu_dinamica()
        elif opcion == 3:
            menu_energia()
        elif opcion == 4:
            gravitacion()
        elif opcion == 5:
            conversion()
        elif opcion == 6:
            utilidades()
        elif opcion == 0:
            print("Saliendo...")
            break
        else:
            print("Opcion invalida.")

        print("")
        pausa()


main()

