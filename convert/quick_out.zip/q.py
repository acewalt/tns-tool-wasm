print("hola desde plantilla")
