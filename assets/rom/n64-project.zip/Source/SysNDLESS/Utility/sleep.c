#include <unistd.h>
#include <stdint.h>

extern void msleep(unsigned ms);

#ifdef sleep
#undef sleep
#endif

int usleep(useconds_t usec)
{
    unsigned ms = (unsigned)((usec + 999u) / 1000u); /* round up */
    msleep(ms);
    return 0;
}

unsigned int sleep(unsigned int seconds)
{
    msleep(seconds * 1000u);
    return 0;
}
