/*
   DaedalusX64 - TI-Nspire CX II Port
   Memory and Cache Management
*/

#ifndef __MEMORYNDLESS_H__
#define __MEMORYNDLESS_H__

#ifdef __cplusplus
extern "C" {
#endif

// Cache management functions for ARM dynarec
void _InvalidateInstructionCache(void);
void _FlushDataCache(void);
void _InvalidateAndFlushCaches(void);

#ifdef __cplusplus
}
#endif

#endif //__MEMORYNDLESS_H__
