/*
   DaedalusX64 - TI-Nspire CX II Port
   Memory Management
*/

#include "MemoryNDLESS.h"

// Stack size for main thread (2MB)
int __stacksize__ = 2 * 1024 * 1024;

// TI-Nspire doesn't need special memory permission setup like 3DS
// Standard malloc/free works fine
