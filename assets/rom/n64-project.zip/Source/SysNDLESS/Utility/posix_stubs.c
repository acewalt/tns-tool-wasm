/*
 * POSIX function stubs for NDLESS
 *
 * Provides missing POSIX functions that libstdc++ filesystem expects
 * but NDLESS doesn't provide.
 */

#ifdef DAEDALUS_NDLESS

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

/*
 * fchmod - Change file permissions via file descriptor
 * NDLESS: No-op, files are always editable (effectively root access)
 */
int fchmod(int fd, mode_t mode)
{
    (void)fd;
    (void)mode;
    return 0;  // Success
}

/*
 * fchmodat - Change file permissions at directory path
 * NDLESS: No-op, files are always editable (effectively root access)
 */
int fchmodat(int dirfd, const char *pathname, mode_t mode, int flags)
{
    (void)dirfd;
    (void)pathname;
    (void)mode;
    (void)flags;
    return 0;  // Success
}

/*
 * symlink - Create symbolic link
 * NDLESS: Not supported
 */
int symlink(const char *target, const char *linkpath)
{
    (void)target;
    (void)linkpath;
    errno = ENOSYS;  // Function not implemented
    return -1;
}

/*
 * readlink - Read symbolic link target
 * NDLESS: Not supported
 */
ssize_t readlink(const char *pathname, char *buf, size_t bufsiz)
{
    (void)pathname;
    (void)buf;
    (void)bufsiz;
    errno = ENOSYS;  // Function not implemented
    return -1;
}

/*
 * truncate - Resize file to specified length
 * NDLESS: Not supported (could implement with fopen/ftruncate if needed)
 */
int truncate(const char *path, off_t length)
{
    (void)path;
    (void)length;
    errno = ENOSYS;  // Function not implemented
    return -1;
}

/*
 * pathconf - Get filesystem path configuration limits
 * NDLESS: Not supported
 */
long pathconf(const char *path, int name)
{
    (void)path;
    (void)name;
    errno = ENOSYS;  // Function not implemented
    return -1;
}

#endif // DAEDALUS_NDLESS
