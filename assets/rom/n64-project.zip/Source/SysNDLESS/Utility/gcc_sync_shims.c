/*
 * GCC __sync_* and __atomic_* builtin stubs for NDLESS
 *
 * NDLESS is single-threaded (DAEDALUS_ENABLE_THREADING=OFF), so we provide
 * simple non-atomic implementations.
 */

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* __sync_* stubs - old-style GCC atomics */

/* Returns the previous value (like GCC __sync_fetch_and_or) */
uint32_t __sync_fetch_and_or_4(volatile uint32_t *ptr, uint32_t value)
{
    uint32_t old = *ptr;
    *ptr = old | value;
    return old;
}

/* Returns the contents before the operation (like GCC __sync_val_compare_and_swap) */
uint32_t __sync_val_compare_and_swap_4(volatile uint32_t *ptr, uint32_t oldval, uint32_t newval)
{
    uint32_t cur = *ptr;
    if (cur == oldval) {
        *ptr = newval;
    }
    return cur;
}

/* __atomic_* stubs - modern GCC atomics */

/* Atomic fetch and OR operation */
uint32_t __atomic_fetch_or_4(volatile void *ptr, uint32_t value, int memorder)
{
    (void)memorder;
    volatile uint32_t *p = (volatile uint32_t *)ptr;
    uint32_t old = *p;
    *p = old | value;
    return old;
}

/* Atomic compare and exchange operation */
bool __atomic_compare_exchange_4(volatile void *ptr, void *expected, uint32_t desired,
                                  bool weak, int success_memorder, int failure_memorder)
{
    (void)weak;
    (void)success_memorder;
    (void)failure_memorder;

    volatile uint32_t *p = (volatile uint32_t *)ptr;
    uint32_t *exp = (uint32_t *)expected;
    uint32_t cur = *p;

    if (cur == *exp) {
        *p = desired;
        return true;
    } else {
        *exp = cur;
        return false;
    }
}

#ifdef __cplusplus
}
#endif
