//CHATGPT, needs improving/refactor. Quick implementation.

/*
 * memalign() + safe free() wrapping for NDLESS/newlib
 *
 * Goals:
 *  - Provide memalign() for C++17 aligned allocations / alignas()
 *  - Ensure alignment remains power-of-2 (correct masking)
 *  - Make free() safe: DO NOT read memory before ptr (no UB heuristics)
 *
 * Mechanism:
 *  - memalign() over-allocates, computes an aligned pointer inside the block
 *  - Stores base->aligned mapping in a small static registry
 *  - __wrap_free(ptr) looks up ptr in the registry:
 *      - if found: frees the original base pointer
 *      - else: calls __real_free(ptr)
 *
 * Linker:
 *  -Wl,--wrap=free
 */

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>

#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
  #include <stdalign.h>   /* alignof in C11 */
  #define ALIGNOF(T) alignof(T)
#else
  /* Best-effort fallback; on many ABIs this is fine. */
  #define ALIGNOF(T) (sizeof(void*))
#endif

/* ----------------------------- Helpers ----------------------------- */

static int is_pow2(size_t x) {
    return x && ((x & (x - 1)) == 0);
}

static size_t next_pow2(size_t x) {
    /* Returns the next power of 2 >= x (for x > 0). */
    size_t p = 1;
    while (p < x) p <<= 1;
    return p;
}

static size_t max_size(size_t a, size_t b) {
    return (a > b) ? a : b;
}

/* ------------------------ Registry (no UB) ------------------------- */
/*
 * Fixed-size open-addressing hash table:
 *   key   = aligned pointer returned to user
 *   value = base pointer returned by malloc
 *
 * This avoids reading memory at ptr-offsetof(header) inside free().
 *
 * Assumptions:
 *  - single-threaded (NDLESS typical)
 *  - bounded number of concurrently alive aligned allocations
 *  - if table fills up, memalign fails with ENOMEM (safe behavior)
 */

#define REG_CAPACITY 1024u  /* tune as needed */

struct reg_entry {
    void *key_aligned;
    void *val_base;
};

static struct reg_entry g_reg[REG_CAPACITY];

static uint32_t ptr_hash(void *p) {
    /* Simple pointer hash; good enough for open addressing. */
    uintptr_t x = (uintptr_t)p;
    x ^= x >> 16;
    x ^= x >> 8;
    return (uint32_t)x;
}

static int reg_insert(void *aligned, void *base) {
    uint32_t h = ptr_hash(aligned);
    for (uint32_t i = 0; i < REG_CAPACITY; i++) {
        uint32_t idx = (h + i) % REG_CAPACITY;
        if (g_reg[idx].key_aligned == NULL) {
            g_reg[idx].key_aligned = aligned;
            g_reg[idx].val_base = base;
            return 1;
        }
    }
    return 0; /* full */
}

static void *reg_remove(void *aligned) {
    /*
     * Remove and return base pointer if found, else NULL.
     * Deletion in open addressing needs care; simplest safe approach:
     *  - Mark slot as "tombstone" rather than NULL.
     *
     * To keep code small, we do a conservative approach:
     *  - when removing, set key to a special tombstone value
     *  - store base as NULL
     *  - lookup treats tombstones as occupied for probing
     */
    static void *const TOMBSTONE = (void*)(uintptr_t)1;

    uint32_t h = ptr_hash(aligned);
    for (uint32_t i = 0; i < REG_CAPACITY; i++) {
        uint32_t idx = (h + i) % REG_CAPACITY;
        void *k = g_reg[idx].key_aligned;

        if (k == NULL) {
            return NULL; /* not found; stop probe */
        }
        if (k == aligned) {
            void *base = g_reg[idx].val_base;
            g_reg[idx].key_aligned = TOMBSTONE;
            g_reg[idx].val_base = NULL;
            return base;
        }
        /* else continue probing (including TOMBSTONE) */
    }
    return NULL;
}

static int reg_probe_has_key(void *aligned) {
    /* Optional helper if you need it; not used below. */
    (void)aligned;
    return 0;
}

/* --------------------------- memalign() ---------------------------- */

void *memalign(size_t alignment, size_t size)
{
    if (!is_pow2(alignment)) {
        errno = EINVAL;
        return NULL;
    }

    /*
     * Ensure the returned pointer is usable for storing any pointer-sized data
     * and for our internal computations. Also keep power-of-2.
     */
    size_t min_align = max_size((size_t)ALIGNOF(void*), (size_t)ALIGNOF(uintptr_t));
    /* If you ever decide to place a header near the aligned ptr, include ALIGNOF(header) here. */

    size_t eff_align = max_size(alignment, min_align);
    if (!is_pow2(eff_align)) {
        /* Shouldn't happen because both are power-of-2 in practice, but keep it correct. */
        eff_align = next_pow2(eff_align);
    }

    /* Over-allocate: padding up to eff_align-1 is enough. */
    size_t extra = (eff_align - 1);

    void *base = malloc(size + extra);
    if (!base) {
        errno = ENOMEM;
        return NULL;
    }

    uintptr_t p = (uintptr_t)base;
    uintptr_t aligned = (p + (eff_align - 1)) & ~(uintptr_t)(eff_align - 1);

    void *aligned_ptr = (void *)aligned;

    /*
     * Insert into registry BEFORE returning, so free() can safely decide.
     * If registry is full, fail safely.
     */
    if (!reg_insert(aligned_ptr, base)) {
        free(base);
        errno = ENOMEM;
        return NULL;
    }

    return aligned_ptr;
}

/* Optional: posix_memalign wrapper */
int posix_memalign(void **memptr, size_t alignment, size_t size)
{
    if (!memptr) return EINVAL;
    void *p = memalign(alignment, size);
    if (!p) return errno ? errno : ENOMEM;
    *memptr = p;
    return 0;
}

/* ------------------------ Wrapped free() --------------------------- */
/*
 * Use GNU ld wrapping:
 *  - define __wrap_free
 *  - call __real_free
 *  - link with -Wl,--wrap=free
 */

extern void __real_free(void *ptr);

void __wrap_free(void *ptr)
{
    if (!ptr) return;

    /* If ptr was produced by memalign(), free the original base pointer. */
    void *base = reg_remove(ptr);
    if (base) {
        __real_free(base);
        return;
    }

    /* Otherwise, normal free. */
    __real_free(ptr);
}
