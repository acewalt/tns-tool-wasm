#include "embedded_rom.h"
#if __has_include("n64-hle-cache.h")
#include "n64-hle-cache.h"
#endif
/*
   DaedalusX64 - TI-Nspire CX II Port
   NDLESS main entry point
*/
#include <libndls.h>
#include <stdint.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include "Base/Types.h"
#include "Debug/Checkpoint.h"
#include "Interface/ConfigOptions.h"
#include "Interface/Cheats.h"
#include "Core/CPU.h"
#include "Core/Memory.h"
#include "Core/PIF.h"
#include "RomFile/RomSettings.h"
#include "Core/Save.h"
#include "Debug/DBGConsole.h"
#include "Debug/DebugLog.h"
#include "Graphics/GraphicsContext.h"
#include "HLEGraphics/TextureCache.h"
#include "Input/InputManager.h"
#include "Interface/RomDB.h"
#include "System/SystemInit.h"
#include "Utility/BatchTest.h"
#include "Interface/Preferences.h"
#include "Utility/Profiler.h"
#include "Utility/Timer.h"
#include "RomFile/RomFile.h"
#include "SysNDLESS/UI/RomSelector.h"
#include <os.h>

extern "C" {
#include <nspireio/nspireio.h>
}

static void dbg_log(const char* msg) {
    FILE* f = fopen("/documents/daedalus_dbg.txt", "a");
    if (!f) {
        char buf[256];
        snprintf(buf, sizeof(buf), "fopen failed errno=%d (%s)", errno, strerror(errno));
        show_msgbox("DBG", buf);
        return;
    }
    fputs(msg, f);
    fputs("\n", f);
    fclose(f);
}

// NDLESS FORCE-QUIT with a jmp
#include <setjmp.h>
static jmp_buf g_ndQuitJmp;
static volatile int g_ndQuitArmed = 0;
static u32 g_ndMainSP = 0;   // SP at main() — top of our usable stack
static u32 g_ndQuitSP = 0;   // SP at the ForceQuit call site (deep in the chain)
extern u32 g_ndMinSP;        // lowest SP seen at any probe paint (Checkpoint.cpp)

#define ND_READ_CPSR(dst) __asm__ volatile("mrs %0, cpsr" : "=r"(dst))
u32 g_ndCpsrMain    = 0xEE; // main() entry
u32 g_ndCpsrSysInit = 0xEE; // after System_Init
u32 g_ndCpsrRomOpen = 0xEE; // after System_Open, just before CPU_Run
u32 g_ndCpsrFirstTri= 0xEE; // first-triangle latch (RendererNDLESS)
u32 g_ndCpsrQuit    = 0xEE; // ForceQuit call site

extern "C" void NdSaveScreenshot(void);   // GraphicsContextNDLESS.cpp

extern "C" void Daedalus_ForceQuit(void)
{
	g_ndQuitSP = (u32)(uintptr_t)__builtin_frame_address(0);
	ND_READ_CPSR(g_ndCpsrQuit);
	if (g_ndQuitArmed)
		longjmp(g_ndQuitJmp, 1);
}

// Global
bool shouldQuit = false;
EAudioPluginMode enable_audio = APM_DISABLED;  // No audio on TI-Nspire

// Base paths for TI-Nspire
static const char* ROM_PATH = "/documents/ROM";
static const char* SAVE_PATH = "/documents/SAVES";
static const char* CONFIG_PATH = "/documents/CONFIG";

void DebugLog(const char* format, ...)
{
	// STUB
}

static void CreateDirectories()
{

	// Create necessary directories if they don't exist
	DIR* dir = opendir(ROM_PATH);
	if (dir) {
		closedir(dir);
	} else {

		//show_msgbox("DBG", "it appears as if the ROM_PATH dir doesn't exist.");
		// Directory doesn't exist - in NDLESS we can't create dirs easily
		// User must create them manually
	}

	dir = opendir(SAVE_PATH);
	if (dir) {
		closedir(dir);
	}

	dir = opendir(CONFIG_PATH);
	if (dir) {
		closedir(dir);
	}
}

static void Initialize()
{

	mkdir("/documents/SAVES",0700);
	mkdir("/documents/CONFIG",0700);
	CreateDirectories();

	// Switch to framebuffer mode
	lcd_init(lcd_type());

	// Start the spare hardware timer (0x900C0000) for profiling/timing.
	Daedalus_TimerInit();

	// TODO: Open log file for debugging
	// gLogFile = fopen("/documents/CONFIG/daedalus.log", "w");

	// Initialize graphics context (stub for now)
	// Graphics will be implemented later

	// NDLESS: debug msgbox before the menu — commented out (was for bring-up).
	//lcd_init(SCR_TYPE_INVALID);
	//show_msgbox("DBG", "Entering System_Init()");
	//lcd_init(lcd_type());

	// Initialize core systems
	System_Init();
}

void HandleEndOfFrame()
{

	// Check if ESC key is pressed to quit
	if (isKeyPressed(KEY_NSPIRE_ESC)) {
		shouldQuit = true;
		CPU_Halt("User requested exit");
	}

#ifdef NDLESS_DEBUG
	// Screenshot: '.' key, edge-triggered (one BMP per press). Writes to flash so
	// it briefly stalls the frame — fine for a deliberate action. Debug-only.
	{
		static bool s_prevShot = false;
		bool now = isKeyPressed(KEY_NSPIRE_PERIOD);
		if (now && !s_prevShot) NdSaveScreenshot();
		s_prevShot = now;
	}
#endif
}

static std::string SelectROM()
{
	// Use the ROM selector UI
	return TNS_ROM_FILENAME;
}

int main(int argc, char **argv) {
 if(tns_web_init(argc,argv,64u*1024*1024)) return 2;

	ND_READ_CPSR(g_ndCpsrMain);

	Initialize();
	ND_READ_CPSR(g_ndCpsrSysInit);

	// Force-quit landing point: probes call Daedalus_ForceQuit() to land here,
	// flush the RAM log, and exit cleanly (no CPU_Halt/System_Close involved —
	// destructors and shutdown are skipped on purpose; the flash commit is all
	// that matters).
	g_ndMainSP = (u32)(uintptr_t)__builtin_frame_address(0);
	if (setjmp(g_ndQuitJmp) != 0)
	{
		// NDLESS debug
		Daedalus_ShowStageLog(0x55, 0, 0, 0);
		Daedalus_FlushLog();
		Daedalus_ShowStageLog(0x58, 0, 0, 0);              // flash flush done
		return 0;
	}
	g_ndQuitArmed = 1;

	while (!shouldQuit)
	{

		// Select ROM
		std::string rom_path = SelectROM();

		if (rom_path.empty()) {
			// No ROM selected, exit
			break;
		}

		// Open and run ROM
		if (System_Open(rom_path.c_str())) {

			ND_READ_CPSR(g_ndCpsrRomOpen);
			#ifdef TNS_HLE_CACHE_SIZE
			mkdir("/documents/SaveGames",0700);mkdir("/documents/SaveGames/Cache",0700);FILE *cache=fopen(TNS_HLE_CACHE_FILENAME,"rb");if(cache)fclose(cache);else{cache=fopen(TNS_HLE_CACHE_FILENAME,"wb");if(cache){fwrite(tns_hle_cache,1,TNS_HLE_CACHE_SIZE,cache);fclose(cache);}}
#endif
			CPU_SelectCore();
			CPU_Run();
			shouldQuit=true;
			System_Close();
		} else {
			// Failed to open ROM
			break;
		}

		#ifdef DAEDALUS_DEBUG_CONSOLE
		DBGConsole_Msg(0, "Finished Loop()"); // NDLESS
		#endif
	}

	// if (gLogFile) {
	// 	fclose(gLogFile);
	// }
	
	System_Finalize();

	// NDLESS: write the RAM-buffered debug log right before the clean exit that
	// commits it to flash (the only point the Nspire persists file writes).
	Daedalus_FlushLog();

	return 0;
}