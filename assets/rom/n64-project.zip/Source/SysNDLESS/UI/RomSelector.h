//TODO: remove/deprecate or improve.

/*
   DaedalusX64 - TI-Nspire CX II Port
   ROM Selector - STUB FILE
*/

#pragma once

#include <string>

namespace UI
{
	// TODO: Implement ROM selector UI
	std::string DrawRomSelector();
}
