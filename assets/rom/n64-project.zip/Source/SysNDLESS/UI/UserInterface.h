/*
   DaedalusX64 - TI-Nspire CX II Port
   User Interface - STUB FILE
*/

#pragma once

namespace UI
{
	// TODO: Implement UI initialization
	void Initialize();
	void RestoreRenderState();
}
