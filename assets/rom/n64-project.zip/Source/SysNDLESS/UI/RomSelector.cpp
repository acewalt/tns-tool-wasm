//CHATGPT (to improve, quick runaway)

/*
   DaedalusX64 - TI-Nspire CX II Port
   ROM Selector Implementation
*/

#include "RomSelector.h"
#include <libndls.h>
#include <nspireio/nspireio.h>
#include <dirent.h>
#include <string.h>
#include <vector>
#include <algorithm>
#include <cstdio>   // snprintf

namespace UI
{

static bool IsRomFile(const char* name)
{
    if (!name) return false;

    size_t len = strlen(name);
    // ".n64.tns" is 8 chars including the dot
    if (len >= 8) {
        const char* end = name + (len - 8);
        if (strcmp(end, ".n64.tns") == 0 ||
            strcmp(end, ".z64.tns") == 0 ||
            strcmp(end, ".v64.tns") == 0) {
            return true;
        }
    }
    return false;
}

static std::string RemoveTnsSuffix(const std::string& filename)
{
    if (filename.size() >= 4 && filename.compare(filename.size() - 4, 4, ".tns") == 0) {
        return filename.substr(0, filename.size() - 4);
    }
    return filename;
}

// Optional: truncate for display to avoid console wrap weirdness
static std::string TruncDisplay(const std::string& s, size_t maxLen)
{
    if (s.size() <= maxLen) return s;
    // Avoid string concatenation buffer overflow - build result string safely
    std::string result;
    result.reserve(maxLen);  // Pre-allocate to avoid SSO issues
    result.assign(s, 0, maxLen - 3);  // Copy first (maxLen-3) chars
    result.append("...");  // Append ellipsis
    return result;
}

std::string DrawRomSelector()
{

    const char* ROM_PATH = "/documents/ROM";
    lcd_init(lcd_type());

    nio_console csl;
    // IMPORTANT: check return value
    int rc = nio_init(&csl, NIO_MAX_COLS, NIO_MAX_ROWS, 0, 0,
                      NIO_COLOR_WHITE, NIO_COLOR_BLACK, TRUE);
    if (rc != 0) {
        // If nspireio can’t start, avoid touching it further.
        // show_msgbox is usually safe to call early.
        //WARNING
        //Should not need the console can't initialize for some reason. i will comment it out.
        //return;
    }

    nio_set_default(&csl);

    // NDLESS: debug msgbox before the menu — commented out (was for bring-up).
    //lcd_init(SCR_TYPE_INVALID);
    //show_msgbox("DBG", "nio_set_default");
    //lcd_init(lcd_type());

    std::vector<std::string> roms;
    DIR* dir = opendir(ROM_PATH);
    if (!dir) {
        nio_clear(&csl);
        nio_printf("Error: Cannot open %s\n", ROM_PATH);
        nio_printf("Create the directory and add ROM files.\n");
        nio_printf("\nPress ESC to exit.\n");

        while (!isKeyPressed(KEY_NSPIRE_ESC)) {
            idle();
        }
        while (isKeyPressed(KEY_NSPIRE_ESC)) {
            idle();
        }

        nio_free(&csl);
        return "";
    }

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (IsRomFile(entry->d_name)) {
            roms.emplace_back(entry->d_name);
        }
    }
    closedir(dir);

    std::sort(roms.begin(), roms.end());

    if (roms.empty()) {
        nio_clear(&csl);
        nio_printf("No ROM files found in:\n%s\n\n", ROM_PATH);
        nio_printf("Supported: .n64.tns, .z64.tns, .v64.tns\n");
        nio_printf("\nPress ESC to exit.\n");

        while (!isKeyPressed(KEY_NSPIRE_ESC)) {
            idle();
        }
        while (isKeyPressed(KEY_NSPIRE_ESC)) {
            idle();
        }

        nio_free(&csl);
        return "";
    }

    int selected = 0;
    int firstVisible = 0;

    // Keep this conservative to avoid overflowing console rows.
    // Title + blank + instructions consume some lines.
    const int MAX_VISIBLE = 12;

    std::string result;

    for (;;) {
        // Clamp selection
        if (selected < 0) selected = 0;
        if (selected >= (int)roms.size()) selected = (int)roms.size() - 1;

        // Scroll window to keep selection visible
        if (selected < firstVisible) firstVisible = selected;
        if (selected >= firstVisible + MAX_VISIBLE) firstVisible = selected - MAX_VISIBLE + 1;
        if (firstVisible < 0) firstVisible = 0;

        nio_clear(&csl);
        nio_printf("=== DaedalusX64 ROM Selector ===\n\n");

        int end = firstVisible + MAX_VISIBLE;
        if (end > (int)roms.size()) end = (int)roms.size();

        for (int i = firstVisible; i < end; i++) {
            std::string disp = TruncDisplay(RemoveTnsSuffix(roms[i]), 48);
            if (i == selected) nio_printf("> %s\n", disp.c_str());
            else               nio_printf("  %s\n", disp.c_str());
        }

        nio_printf("\nUP/8: Up   DOWN/2: Down\n");
        nio_printf("ENTER: Select   ESC: Exit\n");

        // Input (debounced)
        while (true) {
            if (isKeyPressed(KEY_NSPIRE_UP) || isKeyPressed(KEY_NSPIRE_8)) {
                selected--;
                while (isKeyPressed(KEY_NSPIRE_UP) || isKeyPressed(KEY_NSPIRE_8)) idle();
                break;
            }

            if (isKeyPressed(KEY_NSPIRE_DOWN) || isKeyPressed(KEY_NSPIRE_2)) {
                selected++;
                while (isKeyPressed(KEY_NSPIRE_DOWN) || isKeyPressed(KEY_NSPIRE_2)) idle();
                break;
            }

            if (isKeyPressed(KEY_NSPIRE_ENTER)) {
                char full_path[512];
                // selected is clamped above
                std::snprintf(full_path, sizeof(full_path), "%s/%s", ROM_PATH, roms[selected].c_str());
                result = full_path;

                while (isKeyPressed(KEY_NSPIRE_ENTER)) idle();
                nio_free(&csl);
                return result;
            }

            if (isKeyPressed(KEY_NSPIRE_ESC)) {
                while (isKeyPressed(KEY_NSPIRE_ESC)) idle();
                nio_free(&csl);
                return "";
            }

            idle();
        }
    }
}

} // namespace UI
