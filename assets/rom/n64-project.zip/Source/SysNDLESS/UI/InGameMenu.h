/*
   DaedalusX64 - TI-Nspire CX II Port
   In-Game Menu - STUB FILE
*/

#pragma once

#include "Core/ROM.h"

namespace UI
{
	// TODO: Implement in-game menu
	void LoadRomPreferences(RomID mRomID);
	//TODO: Implement DrawOptionsPage() - currently commented out
	//bool DrawOptionsPage(RomID mRomID);
	//TODO: Implement DrawInGameMenu() - currently commented out
	//void DrawInGameMenu();
}
