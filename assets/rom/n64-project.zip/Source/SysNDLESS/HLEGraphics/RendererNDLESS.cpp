
#include "RendererNDLESS.h"



#include "Combiner/BlendConstant.h"
#include "Combiner/CombinerTree.h"
#include "Combiner/RenderSettings.h"
#include "Core/ROM.h"
#include "Debug/DBGConsole.h" // NDLESS: For DBGConsole_Msg
#include "Debug/Checkpoint.h"
#include "Debug/Dump.h"
#include "Graphics/GraphicsContext.h"
#include "Graphics/NativeTexture.h"
#include "HLEGraphics/CachedTexture.h"
#include "HLEGraphics/DLDebug.h"
#include "HLEGraphics/RDPStateManager.h"
#include "HLEGraphics/TextureCache.h"
#include "Utility/MathUtil.h"
#include "Ultra/ultra_gbi.h"

#include "Utility/Profiler.h"
#include <glm/gtc/type_ptr.hpp>
#include <libndls.h> // NDLESS: For lcd_init, show_msgbox, lcd_type
#include <cmath>
#include <cstdlib>

// NDLESS: External vertex counter for debugging
extern uint32_t gVerticesThisFrame;

// NDLESS: software framebuffer owned by GraphicsContextNDLESS (320x240 RGB565).
extern uint16_t* gFramebuffer;

// Heartbeat counters (painted by DrawPrimitives every 64 triangles; DLParser
// reads g_ndTriCount to arm its per-command hang locator). External linkage
// on purpose — DO NOT move into the anonymous namespace.
u32 g_ndTriCount  = 0;   // cumulative triangles reaching the draw loop
u32 g_ndLineCalls = 0;   // cumulative DrawLine invocations


// 16-bit depth buffer for the software rasterizer (0 = near, 0xFFFF = far).
// External linkage: GraphicsContextNDLESS clears it at each frame blit.
u16  g_ndZBuf[320 * 240];
bool g_ndZTest = true;   // set per-batch from RenderTriangles' disable_zbuffer

// Profiling counters live in GraphicsContextNDLESS.cpp. Declared at GLOBAL scope
// here so the anonymous-namespace fill kernels below reference the real globals
// (a local `extern` inside an anon-namespace function would bind to a bogus
// anon-namespace symbol and fail to link).
extern u32 g_rPixTested, g_rPixWritten;

extern "C" void NdRasterClearZ()
{
	memset(g_ndZBuf, 0xFF, sizeof(g_ndZBuf));
}

namespace
{
	const int kFbW = 320;
	const int kFbH = 240;

	// Render mode: false = filled flat-shaded triangles with z-buffer (default),
	// true = the original wireframe bring-up path.
	const bool kWireframe = false;

	inline u16 ColourTo565(const c32 & c)
	{
		return (u16)(((c.GetR() >> 3) << 11) | ((c.GetG() >> 2) << 5) | (c.GetB() >> 3));
	}

	inline void PlotClip(int x, int y, u16 col)
	{
		if ((unsigned)x < (unsigned)kFbW && (unsigned)y < (unsigned)kFbH)
			gFramebuffer[y * kFbW + x] = col;
	}

	// Cohen-Sutherland region codes for the framebuffer rect [0..W-1]x[0..H-1].
	enum { CS_INSIDE = 0, CS_LEFT = 1, CS_RIGHT = 2, CS_BOTTOM = 4, CS_TOP = 8 };
	inline int CSCode(int x, int y)
	{
		int c = CS_INSIDE;
		if      (x < 0)          c |= CS_LEFT;
		else if (x > kFbW - 1)   c |= CS_RIGHT;
		if      (y < 0)          c |= CS_BOTTOM;
		else if (y > kFbH - 1)   c |= CS_TOP;
		return c;
	}

	// Clip the segment to the screen rect (Cohen-Sutherland), THEN Bresenham.
	// Clipping first is essential: an unclipped endpoint can be billions of
	// pixels away (near-plane projection blow-up), and stepping there one pixel
	// at a time would hang the CPU. After clipping, every span is <= W+H steps.
	void DrawLine(int x0, int y0, int x1, int y1, u16 col)
	{
		++g_ndLineCalls; // heartbeat
		int c0 = CSCode(x0, y0);
		int c1 = CSCode(x1, y1);
		int guard = 0;
		for (;;)
		{
			if (!(c0 | c1)) break;          // both inside -> accept
			if (c0 & c1)    return;         // both share an outside zone -> reject
			if (++guard > 8) return;        // clip converges fast; bail if not
			int c  = c0 ? c0 : c1;
			int x = 0, y = 0;
			// Guard divides against horizontal/vertical segments.
			if (c & CS_TOP)         { if (y1==y0) return; x = x0 + (x1-x0)*(kFbH-1-y0)/(y1-y0); y = kFbH-1; }
			else if (c & CS_BOTTOM) { if (y1==y0) return; x = x0 + (x1-x0)*(0     -y0)/(y1-y0); y = 0; }
			else if (c & CS_RIGHT)  { if (x1==x0) return; y = y0 + (y1-y0)*(kFbW-1-x0)/(x1-x0); x = kFbW-1; }
			else /* CS_LEFT */      { if (x1==x0) return; y = y0 + (y1-y0)*(0     -x0)/(x1-x0); x = 0; }
			if (c == c0) { x0 = x; y0 = y; c0 = CSCode(x0, y0); }
			else         { x1 = x; y1 = y; c1 = CSCode(x1, y1); }
		}

		int dx =  std::abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
		int dy = -std::abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
		int err = dx + dy;
		// Hard safety cap: after clipping every span is <= ~560 px, but if the
		// clip math overflowed (huge coords) this guarantees we never spin.
		for (int steps = 0; steps <= 1024; ++steps)
		{
			PlotClip(x0, y0, col);
			if (x0 == x1 && y0 == y1) break;
			int e2 = 2 * err;
			if (e2 >= dy) { err += dy; x0 += sx; }
			if (e2 <= dx) { err += dx; y0 += sy; }
		}
	}

	// Filled-triangle rasterizer: integer edge functions stepped incrementally,
	// flat colour, optional 16-bit z test/write. The ARM926 has NO FPU (all
	// float ops are ~100-cycle softfloat calls) so the per-pixel loop is pure
	// integer; per-triangle setup allows a couple of 64-bit divides.
	// Coordinate contract: |x|,|y| <= 4096 (project() enforces it), so at any
	// screen pixel |A*x + B*y + C| < 2^26 — the inner loop walks pure s32.
	// z steps in a u32 16.16 accumulator: mod-2^32 addition is exact, and the
	// true interpolant inside the triangle is within the vertex range 0..65535,
	// so (zx >> 16) needs no clamp there. ZTEST is a compile-time template flag
	// so the no-z path carries zero per-pixel cost (2x fewer branches).
	template <bool ZTEST>
	void FillTriFlat(int x0, int y0, s32 z0,
	                 int x1, int y1, s32 z1,
	                 int x2, int y2, s32 z2, u16 col)
	{
		s64 area = (s64)(x1 - x0) * (y2 - y0) - (s64)(y1 - y0) * (x2 - x0);
		if (area == 0) return;
		if (area < 0) // make CCW so all edge functions are >= 0 inside
		{
			std::swap(x1, x2); std::swap(y1, y2); std::swap(z1, z2);
			area = -area;
		}

		int minx = std::max(std::min(std::min(x0, x1), x2), 0);
		int maxx = std::min(std::max(std::max(x0, x1), x2), kFbW - 1);
		int miny = std::max(std::min(std::min(y0, y1), y2), 0);
		int maxy = std::min(std::max(std::max(y0, y1), y2), kFbH - 1);
		if (minx > maxx || miny > maxy) return;

		// Edge functions E(x,y) = A*x + B*y + C, one per edge, >= 0 inside.
		const s32 A0 = y1 - y2, B0 = x2 - x1; const s64 C0 = (s64)x1 * y2 - (s64)y1 * x2;
		const s32 A1 = y2 - y0, B1 = x0 - x2; const s64 C1 = (s64)x2 * y0 - (s64)y2 * x0;
		const s32 A2 = y0 - y1, B2 = x1 - x0; const s64 C2 = (s64)x0 * y1 - (s64)y0 * x1;
		s32 w0row = (s32)((s64)A0 * minx + (s64)B0 * miny + C0);
		s32 w1row = (s32)((s64)A1 * minx + (s64)B1 * miny + C1);
		s32 w2row = (s32)((s64)A2 * minx + (s64)B2 * miny + C2);

		// z as 16.16 fixed: value at (minx,miny) + per-pixel/per-row gradients.
		const u32 dzdx = (u32)((((s64)A0 * z0 + (s64)A1 * z1 + (s64)A2 * z2) << 16) / area);
		const u32 dzdy = (u32)((((s64)B0 * z0 + (s64)B1 * z1 + (s64)B2 * z2) << 16) / area);
		u32 zrow = (u32)((((s64)w0row * z0 + (s64)w1row * z1 + (s64)w2row * z2) << 16) / area);

		for (int y = miny; y <= maxy; ++y)
		{
			s32 w0 = w0row, w1 = w1row, w2 = w2row;
			u32 zx = zrow;
			u16 * frow = &gFramebuffer[y * kFbW];
			u16 * zbrow = &g_ndZBuf[y * kFbW];
			for (int x = minx; x <= maxx; ++x)
			{
				if ((w0 | w1 | w2) >= 0) // sign-bit trick: all three >= 0
				{
					if (ZTEST)
					{
						// Edge-pixel rounding can push zx out of 0..65535<<16;
						// then zx>>16 > 0xFFFF and the test just rejects.
						u32 z = zx >> 16;
						if (z <= zbrow[x])
						{
							zbrow[x] = (u16)z;
							frow[x]  = col;
						}
					}
					else
					{
						frow[x] = col;
					}
				}
				w0 += A0; w1 += A1; w2 += A2; zx += dzdx;
			}
			w0row += B0; w1row += B1; w2row += B2; zrow += dzdy;
		}
	}

	// Does the RDP colour-combiner mux actually reference the texture units?
	// Batches routinely have the TnL texture flag set while the combiner uses
	// only SHADE/PRIM (e.g. Mario's solid-colour body parts) — sampling the
	// leftover bound texture there modulates with garbage (black faces bug).
	// RGB sources per cycle: a(4b) 1/2 = TEXEL0/1; c(5b) also 8/9 = TEXEL alpha.
	bool MuxUsesTexture(u64 mux)
	{
		const u32 mux0 = (u32)(mux >> 32), mux1 = (u32)mux;
		const u32 aC0 = (mux0 >> 20) & 0xF, cC0 = (mux0 >> 15) & 0x1F;
		const u32 aC1 = (mux0 >>  5) & 0xF, cC1 =  mux0        & 0x1F;
		const u32 bC0 = (mux1 >> 28) & 0xF, dC0 = (mux1 >> 15) & 0x7;
		const u32 bC1 = (mux1 >> 24) & 0xF, dC1 = (mux1 >>  6) & 0x7;
		auto texABD = [](u32 v){ return v == 1 || v == 2; };
		auto texC   = [](u32 v){ return v == 1 || v == 2 || v == 8 || v == 9; };
		return texABD(aC0) || texABD(bC0) || texC(cC0) || texABD(dC0)
		    || texABD(aC1) || texABD(bC1) || texC(cC1) || texABD(dC1);
	}

	// Software sampler state for the current batch (bound in RenderTriangles).
	// Texels are RGBA8888 (R in the low byte — NativePf8888 layout).
	const u32 * s_texPx     = nullptr;
	u32         s_texStride = 0;   // pixels per row
	u32         s_texMaskS  = 0;   // pow2-1 wrap masks (corrected dims are pow2)
	u32         s_texMaskT  = 0;
	float       s_texOffS   = 0.f; // tile top-left in texels
	float       s_texOffT   = 0.f;

	// Per-axis N64 wrap mode. Only two cases matter for the *sampler*:
	//   WRAP_REPEAT — plain AND against the corrected width.
	//   WRAP_CLAMP  — hold the edge for coords outside the buffer.
	// MIRROR is NOT handled here: RDPStateManager runs with EmulateMirror=true, so
	// CachedTexture::MirrorTexels already bakes the mirror into a 2x-wide buffer
	// [orig|reversed] (CachedTexture.cpp), and plain repeat-mask against the
	// corrected width samples that baked mirror correctly. Re-applying mirror in the
	// sampler double-folds it -> the "duplicating" trees. So mirror maps to REPEAT.
	// Likewise CLAMP relies on ClampTexels having pre-filled the pow2 padding with
	// edge texels, so clamping the coord to [0, corrected-1] yields the edge colour.
	enum EWrap : u8 { WRAP_REPEAT = 0, WRAP_CLAMP = 1 };
	u8 s_wrapS = WRAP_REPEAT, s_wrapT = WRAP_REPEAT;

	// Fold an integer texel coord (u>>16, may be negative) per wrap mode. mask =
	// corrected width-1 (pow2). Only called on the WRAP_FULL (clamp) path; pure
	// repeat uses a bare AND inline.
	static inline u32 WrapCoord(s32 c, u32 mask, u8 mode)
	{
		if (mode == WRAP_CLAMP)
			return (c < 0) ? 0u : ((u32)c > mask ? mask : (u32)c);
		return (u32)c & mask;                        // WRAP_REPEAT
	}

	// Per-batch combiner approximation. The RDP colour combiner computes
	// out = (A - B) * C + D per channel; with the texel as the multiplier C
	// every mode seen in SM64 reduces to one integer kernel:
	//     out = D + ((A - B) * texel >> 8)
	// where A/B/D are per-triangle (SHADE) or per-batch (PRIM/ENV/1/0) colours.
	//   modulate (T*SHADE):        A=SHADE B=0     D=0
	//   lerp     ((P-S)*T+S):      A=PRIM  B=SHADE D=SHADE   (Mario head!)
	//   replace  (T):              A=1     B=0     D=0
	enum ECmbSrc : u8 { SRC_ZERO, SRC_ONE, SRC_SHADE, SRC_PRIM, SRC_ENV };
	u8  s_cmbA = SRC_SHADE, s_cmbB = SRC_ZERO, s_cmbD = SRC_ZERO;
	u32 s_primCol = 0xFFFFFFFF, s_envCol = 0xFFFFFFFF; // c32 GetColour packing

	// Combiner kernel specializations for FillTriTex. Dispatched per batch so
	// the per-pixel loop only pays for the maths its mux actually needs:
	//   CMB_REPLACE  out = texel                  (no muls, no clamps)
	//   CMB_MODULATE out = (A*texel)>>8, A 0..255 (3 muls, provably <=255 so
	//                                              no clamps)
	//   CMB_GENERIC  out = D + ((A-B)*texel>>8)   (full path, clamped)
	enum ECmbMode { CMB_GENERIC = 0, CMB_MODULATE = 1, CMB_REPLACE = 2 };

	// Textured triangle: affine UV (16.16) + z, alpha-cutout, combiner kernel
	// per MODE above. A/B/D are resolved to concrete 0..255 channels by the
	// caller. Pure integer. Same s32/u32 accumulator contract as FillTriFlat
	// (|x|,|y| <= 4096; |uv| <= 2047 texels in 16.16 so the true interpolant
	// fits s32 and mod-2^32 stepping is exact). Z-reject runs BEFORE the texel
	// fetch — occluded pixels skip the texture read entirely; alpha-cutout
	// pixels never write z (same visible semantics as before).
	template <bool ZTEST, ECmbMode MODE, bool WRAPFAST>
	void FillTriTex(int x0, int y0, s32 z0, s32 u0, s32 v0,
	                int x1, int y1, s32 z1, s32 u1, s32 v1,
	                int x2, int y2, s32 z2, s32 u2, s32 v2,
	                s32 ar, s32 ag, s32 ab,
	                s32 br, s32 bg, s32 bb,
	                s32 dr, s32 dg, s32 db)
	{
		s64 area = (s64)(x1 - x0) * (y2 - y0) - (s64)(y1 - y0) * (x2 - x0);
		if (area == 0) return;
		if (area < 0)
		{
			std::swap(x1, x2); std::swap(y1, y2); std::swap(z1, z2);
			std::swap(u1, u2); std::swap(v1, v2);
			area = -area;
		}

		int minx = std::max(std::min(std::min(x0, x1), x2), 0);
		int maxx = std::min(std::max(std::max(x0, x1), x2), kFbW - 1);
		int miny = std::max(std::min(std::min(y0, y1), y2), 0);
		int maxy = std::min(std::max(std::max(y0, y1), y2), kFbH - 1);
		if (minx > maxx || miny > maxy) return;

		const s32 A0 = y1 - y2, B0 = x2 - x1; const s64 C0 = (s64)x1 * y2 - (s64)y1 * x2;
		const s32 A1 = y2 - y0, B1 = x0 - x2; const s64 C1 = (s64)x2 * y0 - (s64)y2 * x0;
		const s32 A2 = y0 - y1, B2 = x1 - x0; const s64 C2 = (s64)x0 * y1 - (s64)y0 * x1;
		s32 w0row = (s32)((s64)A0 * minx + (s64)B0 * miny + C0);
		s32 w1row = (s32)((s64)A1 * minx + (s64)B1 * miny + C1);
		s32 w2row = (s32)((s64)A2 * minx + (s64)B2 * miny + C2);

		const u32 dzdx = (u32)((((s64)A0 * z0 + (s64)A1 * z1 + (s64)A2 * z2) << 16) / area);
		const u32 dzdy = (u32)((((s64)B0 * z0 + (s64)B1 * z1 + (s64)B2 * z2) << 16) / area);
		u32 zrow = (u32)((((s64)w0row * z0 + (s64)w1row * z1 + (s64)w2row * z2) << 16) / area);
		// u/v arrive already in 16.16 — gradients need no extra shift.
		const u32 dudx = (u32)(((s64)A0 * u0 + (s64)A1 * u1 + (s64)A2 * u2) / area);
		const u32 dudy = (u32)(((s64)B0 * u0 + (s64)B1 * u1 + (s64)B2 * u2) / area);
		const u32 dvdx = (u32)(((s64)A0 * v0 + (s64)A1 * v1 + (s64)A2 * v2) / area);
		const u32 dvdy = (u32)(((s64)B0 * v0 + (s64)B1 * v1 + (s64)B2 * v2) / area);
		u32 urow = (u32)(((s64)w0row * u0 + (s64)w1row * u1 + (s64)w2row * u2) / area);
		u32 vrow = (u32)(((s64)w0row * v0 + (s64)w1row * v1 + (s64)w2row * v2) / area);

		// (A-B) factors for the generic kernel; plain A for modulate.
		const s32 fr = ar - br, fg = ag - bg, fb = ab - bb;

		const u32 * const texPx     = s_texPx;
		const u32         texStride = s_texStride;
		const u32         maskS     = s_texMaskS;
		const u32         maskT     = s_texMaskT;
		const u8          wrapS     = s_wrapS;
		const u8          wrapT     = s_wrapT;

		// Local pixel counters (registers) flushed once at exit — measures fill
		// coverage vs actual writes (overdraw) without per-pixel global traffic.
		u32 nTested = 0, nWritten = 0;

		for (int y = miny; y <= maxy; ++y)
		{
			s32 w0 = w0row, w1 = w1row, w2 = w2row;
			u32 zx = zrow, ux = urow, vx = vrow;
			u16 * frow  = &gFramebuffer[y * kFbW];
			u16 * zbrow = &g_ndZBuf[y * kFbW];
			for (int x = minx; x <= maxx; ++x)
			{
				if ((w0 | w1 | w2) >= 0)
				{
					++nTested;
					u32 z = 0;
					bool vis = true;
					if (ZTEST)
					{
						z = zx >> 16;              // exact inside the tri
						vis = (z <= zbrow[x]);     // out-of-range rounding rejects
					}
					if (vis)
					{
						u32 ts, tt;
						if (WRAPFAST)
						{
							ts = ((u32)((s32)ux >> 16)) & maskS;
							tt = ((u32)((s32)vx >> 16)) & maskT;
						}
						else
						{
							ts = WrapCoord((s32)ux >> 16, maskS, wrapS);
							tt = WrapCoord((s32)vx >> 16, maskT, wrapT);
						}
						const u32 texel = texPx[tt * texStride + ts];
						if ((texel >> 24) >= 8) // alpha cutout (trees, coins, fonts)
						{
							++nWritten;
							if (ZTEST)
								zbrow[x] = (u16)z;
							if (MODE == CMB_REPLACE)
							{
								frow[x] = (u16)(((texel & 0xF8) << 8) |
								                ((texel >>  5) & 0x7E0) |
								                ((texel >> 19) & 0x1F));
							}
							else if (MODE == CMB_MODULATE)
							{
								const s32 tr =  texel        & 0xFF;
								const s32 tg = (texel >>  8) & 0xFF;
								const s32 tb = (texel >> 16) & 0xFF;
								frow[x] = (u16)((((ar * tr) >> 11) << 11) |
								                (((ag * tg) >> 10) <<  5) |
								                 ((ab * tb) >> 11));
							}
							else
							{
								const s32 tr =  texel        & 0xFF;
								const s32 tg = (texel >>  8) & 0xFF;
								const s32 tb = (texel >> 16) & 0xFF;
								s32 r = dr + ((fr * tr) >> 8);
								s32 g = dg + ((fg * tg) >> 8);
								s32 b = db + ((fb * tb) >> 8);
								if (r < 0) r = 0; else if (r > 255) r = 255;
								if (g < 0) g = 0; else if (g > 255) g = 255;
								if (b < 0) b = 0; else if (b > 255) b = 255;
								frow[x] = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
							}
						}
					}
				}
				w0 += A0; w1 += A1; w2 += A2; zx += dzdx; ux += dudx; vx += dvdx;
			}
			w0row += B0; w1row += B1; w2row += B2; zrow += dzdy; urow += dudy; vrow += dvdy;
		}
		g_rPixTested += nTested; g_rPixWritten += nWritten;
	}

	// Per-(ztest, mode) dispatch table so DrawPrimitives makes one indirect
	// call per triangle instead of re-branching per pixel.
	typedef void (*FillTriTexFn)(int, int, s32, s32, s32,
	                             int, int, s32, s32, s32,
	                             int, int, s32, s32, s32,
	                             s32, s32, s32, s32, s32, s32, s32, s32, s32);
	// [ztest][combiner mode][wrapfast]. wrapfast=1 (both axes REPEAT) is the
	// common single-AND sampler; wrapfast=0 honours CLAMP via WrapCoord.
	// (An OPAQUE specialization to drop the per-pixel alpha branch was tried and
	// reverted 2026-07-17: 73% coverage but 0 measurable ras gain — the loop is
	// memory-bound, not ALU-bound — for +30KB code. See renderer-gotchas.)
	const FillTriTexFn kFillTriTex[2][3][2] =
	{
		{ { &FillTriTex<false, CMB_GENERIC,  false>, &FillTriTex<false, CMB_GENERIC,  true> },
		  { &FillTriTex<false, CMB_MODULATE, false>, &FillTriTex<false, CMB_MODULATE, true> },
		  { &FillTriTex<false, CMB_REPLACE,  false>, &FillTriTex<false, CMB_REPLACE,  true> } },
		{ { &FillTriTex<true,  CMB_GENERIC,  false>, &FillTriTex<true,  CMB_GENERIC,  true> },
		  { &FillTriTex<true,  CMB_MODULATE, false>, &FillTriTex<true,  CMB_MODULATE, true> },
		  { &FillTriTex<true,  CMB_REPLACE,  false>, &FillTriTex<true,  CMB_REPLACE,  true> } },
	};
}

//TODO: Implement OpenGL-equivalent rendering for NDLESS - currently all GL calls are no-ops
// Dummy GL defines for NDLESS (no OpenGL support)
#define GL_ALPHA_TEST 0x0BC0
#define GL_BLEND 0x0BE2
#define GL_DEPTH_TEST 0x0B71
#define GL_DST_ALPHA 0x0304
#define GL_FALSE 0
#define GL_FOG 0x0B60
#define GL_FOG_MODE 0x0B65
#define GL_FUNC_ADD 0x8006
#define GL_GEQUAL 0x0206
#define GL_GREATER 0x0204
#define GL_LEQUAL 0x0203
#define GL_LINEAR 0x2601
#define GL_MODELVIEW 0x1700
#define GL_MODULATE 0x2100
#define GL_NEAREST 0x2600
#define GL_ONE 1
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_POLYGON_OFFSET_FILL 0x8037
#define GL_PROJECTION 0x1701
#define GL_REPLACE 0x1E01
#define GL_SCISSOR_TEST 0x0C11
#define GL_SRC_ALPHA 0x0302
#define GL_TEXTURE_2D 0x0DE1
#define GL_TEXTURE_COORD_ARRAY 0x8078
#define GL_TEXTURE_ENV 0x2300
#define GL_TEXTURE_ENV_COLOR 0x2201
#define GL_TEXTURE_ENV_MODE 0x2200
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
// NDLESS wrap stubs — these MUST match BaseRenderer.cpp:76-78, which is the TU
// that actually fills mTexWrap. It uses tiny sentinel values, NOT real GL enums.
#define ND_WRAP_CLAMP  0
#define ND_WRAP_REPEAT 1
#define ND_WRAP_MIRROR 2
#define GL_TRIANGLES 0x0004
#define GL_TRIANGLE_FAN 0x0006
#define GL_TRIANGLE_STRIP 0x0005
#define GL_TRUE 1
#define GL_ZERO 0

//TODO: Implement actual rendering functions for NDLESS
static inline void glAlphaFunc(unsigned int func, float ref) { /* TODO */ }
static inline void glBlendEquation(unsigned int mode) { /* TODO */ }
static inline void glBlendFunc(unsigned int sfactor, unsigned int dfactor) { /* TODO */ }
static inline void glColor3f(float r, float g, float b) { /* TODO */ }
static inline void glDepthFunc(unsigned int func) { /* TODO */ }
static inline void glDepthMask(unsigned char flag) { /* TODO */ }
static inline void glDisable(unsigned int cap) { /* TODO */ }
static inline void glDisableClientState(unsigned int array) { /* TODO */ }
static inline void glDrawArrays(unsigned int mode, int first, int count) { /* TODO */ }
static inline void glEnable(unsigned int cap) { /* TODO */ }
static inline void glEnableClientState(unsigned int array) { /* TODO */ }
static inline void glFogi(unsigned int pname, int param) { /* TODO */ }
static inline void glLoadIdentity() { /* TODO */ }
static inline void glLoadMatrixf(const float* m) { /* TODO */ }
static inline void glMatrixMode(unsigned int mode) { /* TODO */ }
static inline void glPolygonOffset(float factor, float units) { /* TODO */ }
static inline void glScissor(int x, int y, int width, int height) { /* TODO */ }
static inline void glTexEnvfv(int target, int pname, const float* params) { /* TODO */ }
static inline void glTexEnvi(int target, int pname, int param) { /* TODO */ }
static inline void glTexParameteri(unsigned int target, unsigned int pname, int param) { /* TODO */ }

BaseRenderer *gRenderer    = nullptr;
RendererNDLESS  *gRendererNDLESS = nullptr;

//TODO: Implement actual vertex buffers for software rendering
// Dummy vertex buffers - graphics rendering is stubbed for NDLESS
static float 	dummy_vertex_buffer[3];
static uint32_t	dummy_color_buffer[1];
static float 	dummy_texcoord_buffer[2];

float 	*gVertexBuffer = dummy_vertex_buffer;
uint32_t *gColorBuffer = dummy_color_buffer;
float 	*gTexCoordBuffer = dummy_texcoord_buffer;
uint32_t gVertexCount = 0;
extern uint32_t  gMaxVertices;

struct ScePspFMatrix4
{
	float m[16];
};


ScePspFMatrix4		gProjection;

void sceGuSetMatrix(int type, const ScePspFMatrix4 * mtx)
{
	if (type == GL_PROJECTION)
	{
		memcpy(&gProjection, mtx, sizeof(gProjection));
	}
}

static void InitBlenderMode()
{
	u32 cycle_type    = gRDPOtherMode.cycle_type;
	u32 cvg_x_alpha   = gRDPOtherMode.cvg_x_alpha;
	u32 alpha_cvg_sel = gRDPOtherMode.alpha_cvg_sel;
	u32 blendmode     = gRDPOtherMode.blender;

	// NB: If we're running in 1cycle mode, ignore the 2nd cycle.
	u32 active_mode = (cycle_type == CYCLE_2CYCLE) ? blendmode : (blendmode & 0xCCCC);
	
	if (alpha_cvg_sel && (gRDPOtherMode.L & 0x7000) != 0x7000) {
		switch (active_mode) {
		case 0x4055: // Mario Golf
		case 0x5055: // Paper Mario Intro
			glBlendFunc(GL_ZERO, GL_ONE);
			glEnable(GL_BLEND);
			break;
		default:
			glDisable(GL_BLEND);
		}
		return;
	}

	switch (active_mode)
	{
	case 0x00C0: // ISS 64
	case 0x0091: // Mace special blend mode
	case 0x0302: // Bomberman 2 special blend mode
	case 0x0382: // Mace objects
	case 0x07C2: // ISS 64
	case 0x0C08: // 1080 sky
	case 0xC302: // ISS 64
	case 0xC702: // Donald Duck: Quack Attack
	case 0xC800: // Conker's Bad Fur Day
	case 0x0F0A: // DK64 blueprints
	case 0xA500: // Sin and Punishment
	case 0xFA00: // Bomberman second attack
		glDisable(GL_BLEND);
		break;
	case 0x55F0: // Bust-A-Move 3 DX
		glBlendFunc(GL_ONE, GL_SRC_ALPHA);
		glEnable(GL_BLEND);
		break;
	case 0x0F1A:
		if (cycle_type == CYCLE_1CYCLE)
			glDisable(GL_BLEND);
		else {
			glBlendFunc(GL_ZERO, GL_ONE);
			glEnable(GL_BLEND);
		}
		break;
	case 0x0448: // Space Invaders
	case 0x0554:
		glBlendFunc(GL_ONE, GL_ONE);
		glEnable(GL_BLEND);
		break;
	case 0x0F5A: // Zelda: MM
	case 0x0FA5: // OOT menu
	case 0x5055: // Paper Mario intro
	case 0xAF50: // Zelda: MM
	case 0xC712: // Pokemon Stadium
		glBlendFunc(GL_ZERO, GL_ONE);
		glEnable(GL_BLEND);
		break;
	case 0x0C40: // Extreme-G
	case 0x0C48: // Star Wars: Shadow of the Empire text and hud
	case 0x4C40: // Wave Race
	case 0x5F50:
		glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_ALPHA);
		glEnable(GL_BLEND);
		break;
	case 0x0010: // Diddy Kong rare logo
	case 0x0040: // F-Zero X
	case 0x0050: // A Bug's Life
	case 0x0051:
	case 0x0055:
	case 0x0150: // Spiderman
	case 0x0321:
	case 0x0440: // Bomberman 64
	case 0x04D0: // Conker's Bad Fur Day
	case 0x0550: // Bomberman 64
	case 0x0C18: // StarFox 64 main menu
	case 0x0F54: // Star Wars racers
	case 0xC410: // Donald Duck: Quack Attack dust
	case 0xC440: // Banjo-Kazooie / Banjo-Tooie
	case 0xC810: // AeroGauge
	case 0xCB02: // Doom 64 weapons
	case 0x0D18:
	case 0x8410: // Paper Mario
	case 0xF550:
		if (!(!alpha_cvg_sel || cvg_x_alpha)) glDisable(GL_BLEND);
		else {
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glEnable(GL_BLEND);
		}
		break;
	case 0xC912: // 40 Winks
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glEnable(GL_BLEND);
		break;
	case 0x0C19:
	case 0xC811:
		glBlendFunc(GL_SRC_ALPHA, GL_DST_ALPHA);
		glEnable(GL_BLEND);
		break;
	case 0x5000: // V8 explosions
		glBlendFunc(GL_ONE_MINUS_SRC_ALPHA, GL_SRC_ALPHA);
		glEnable(GL_BLEND);
		break;
	default:
		//DBGConsole_Msg(0, "Uncommon blender mode: 0x%04X", active_mode);
		if (!(!alpha_cvg_sel || cvg_x_alpha)) glDisable(GL_BLEND);
		else {
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glEnable(GL_BLEND);
		}
		break;
	}
}

RendererNDLESS::RendererNDLESS()
{
	//
	//	Set up RGB = T0, A = T0
	//
	mCopyBlendStates = new CBlendStates;
	{
		CAlphaRenderSettings *	alpha_settings( new CAlphaRenderSettings( "Copy" ) );
		CRenderSettingsModulate *	colour_settings( new CRenderSettingsModulate( "Copy" ) );

		alpha_settings->AddTermTexel0();
		colour_settings->AddTermTexel0();

		mCopyBlendStates->SetAlphaSettings( alpha_settings );
		mCopyBlendStates->AddColourSettings( colour_settings );
	}

	//
	//	Set up RGB = Diffuse, A = Diffuse
	//
	mFillBlendStates = new CBlendStates;
	{
		CAlphaRenderSettings *	alpha_settings( new CAlphaRenderSettings( "Fill" ) );
		CRenderSettingsModulate *	colour_settings( new CRenderSettingsModulate( "Fill" ) );

		alpha_settings->AddTermConstant( new CBlendConstantExpressionValue( BC_SHADE ) );
		colour_settings->AddTermConstant(  new CBlendConstantExpressionValue( BC_SHADE ) );

		mFillBlendStates->SetAlphaSettings( alpha_settings );
		mFillBlendStates->AddColourSettings( colour_settings );
	}

}

RendererNDLESS::~RendererNDLESS()
{
	delete mFillBlendStates;
	delete mCopyBlendStates;
}

void RendererNDLESS::RestoreRenderStates()
{	
	// Initialise the device to our default state
	glEnable(GL_TEXTURE_2D);
	
	// No fog
	glDisable(GL_FOG);
	glFogi(GL_FOG_MODE, GL_LINEAR);

	glScissor(0,0, 400, 240);
	glEnable(GL_SCISSOR_TEST);
	
	glBlendEquation(GL_FUNC_ADD);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glDisable( GL_BLEND );
	
	// Default is ZBuffer disabled
	glDepthMask(GL_FALSE);
	glDepthFunc(GL_LEQUAL);
	glDisable(GL_DEPTH_TEST);
	
	// Enable this for rendering decals (glPolygonOffset).
	glEnable(GL_POLYGON_OFFSET_FILL);
		
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	float envcolor[4] = { c32::White.GetRf(), c32::White.GetGf(), c32::White.GetBf(), c32::White.GetAf() };

	glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, envcolor);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	glColor3f(1.0f, 1.0f, 1.0f);
}

RendererNDLESS::SBlendStateEntry RendererNDLESS::LookupBlendState( u64 mux, bool two_cycles )
{
	#ifdef DAEDALUS_DEBUG_DISPLAYLIST
	DAEDALUS_PROFILE( "RendererCtr::LookupBlendState" );
	mRecordedCombinerStates.insert( mux );
	#endif

	REG64 key;
	key._u64 = mux;

	// Top 8 bits are never set - use the very top one to differentiate between 1/2 cycles
	key._u32_1 |= (two_cycles << 31);

	BlendStatesMap::const_iterator	it( mBlendStatesMap.find( key._u64 ) );
	if( it != mBlendStatesMap.end() )
	{
		return it->second;
	}

	// Blendmodes with Inexact blends either get an Override blend or a Default blend (GU_TFX_MODULATE)
	// If its not an Inexact blend then we check if we need to Force a blend mode none the less// Salvy
	//
	SBlendStateEntry entry;
	CCombinerTree tree( mux, two_cycles );
	entry.States = tree.GetBlendStates();

	if( entry.States->IsInexact() )
	{
		entry.OverrideFunction = LookupOverrideBlendModeInexact( mux );
	}
	else
	{
		// This is for non-inexact blends, errg hacks and such to be more precise
		entry.OverrideFunction = LookupOverrideBlendModeForced( mux );
	}

	#ifdef DAEDALUS_DEBUG_DISPLAYLIST
	printf( "Adding %08x%08x - %d cycles - %s\n", u32(mux>>32), u32(mux), two_cycles ? 2 : 1, entry.States->IsInexact() ?  IsCombinerStateDefault(mux) ? "Inexact(Default)" : "Inexact(Override)" : entry.OverrideFunction==nullptr ? "Auto" : "Forced");
	#endif

	//Add blend mode to the Blend States Map
	mBlendStatesMap[ key._u64 ] = entry;

	return entry;
}

void RendererNDLESS::DrawPrimitives(DaedalusVtx * p_vertices, u32 num_vertices, u32 triangle_mode, bool has_texture)
{
	gVerticesThisFrame += num_vertices; // NDLESS: Track vertices per frame
	{ extern u32 g_dbgDrawVerts; g_dbgDrawVerts += num_vertices; } // NDLESS render diag
	//	Daedalus_ShowStage(6, num_vertices, triangle_mode, has_texture ? 1 : 0); // DrawPrimitives entry // disabled

	// Screen-space viewport rect derived from the current N64 viewport.
	glm::vec2 vmin, vmax;
	ConvertN64ToScreen( glm::vec2(mVpTrans.x - mVpScale.x, mVpTrans.y - mVpScale.y), vmin );
	ConvertN64ToScreen( glm::vec2(mVpTrans.x + mVpScale.x, mVpTrans.y + mVpScale.y), vmax );
	const float vp_x = vmin.x;
	const float vp_y = vmin.y;
	const float vp_w = vmax.x - vmin.x;
	const float vp_h = vmax.y - vmin.y;

#ifdef DAEDALUS_DEBUG_CONSOLE
	{
		static u32 s_logVp = 0;
		if (s_logVp < 8)
		{
			++s_logVp;
			extern bool g_ndLogEnable; g_ndLogEnable = true; // mesh diagnostics: force into RAM log
			// Integer-only: %f on this libc hangs on NaN/huge floats. proj scaled x1000.
			DBGConsole_Msg(0, "DrawPrim nverts=%u vp[x%d y%d w%d h%d] projx1000[0]=%d [5]=%d [10]=%d [15]=%d",
				num_vertices, (int)vp_x, (int)vp_y, (int)vp_w, (int)vp_h,
				(int)(gProjection.m[0]*1000.f), (int)(gProjection.m[5]*1000.f),
				(int)(gProjection.m[10]*1000.f), (int)(gProjection.m[15]*1000.f));
			g_ndLogEnable = false;
		}
	}
#endif

	// gProjection is the N64 projection matrix (column-major glm layout).
	// Vertices arrive as TransformedPos (eye space), so clip = P * (pos,1).
	const float * M = gProjection.m;

	struct SVert { float sx, sy; s32 zi; bool ok; };
	auto project = [&](const DaedalusVtx & v) -> SVert
	{
		const float x = v.Position.x, y = v.Position.y, z = v.Position.z;
		const float cx = M[0]*x + M[4]*y + M[8] *z + M[12];
		const float cy = M[1]*x + M[5]*y + M[9] *z + M[13];
		const float cz = M[2]*x + M[6]*y + M[10]*z + M[14];
		const float cw = M[3]*x + M[7]*y + M[11]*z + M[15];
		SVert out { 0.f, 0.f, 0, false };
		if (cw <= 0.0001f)            // behind camera -> crude reject
			return out;
		const float ndc_x = cx / cw;
		const float ndc_y = cy / cw;
		const float ndc_z = cz / cw;  // -1..1 for in-frustum geometry
		out.sx = vp_x + (ndc_x * 0.5f + 0.5f) * vp_w;
		out.sy = vp_y + (1.0f - (ndc_y * 0.5f + 0.5f)) * vp_h; // flip Y for top-down screen
		// Depth 0..65535 for the 16-bit z-buffer, clamped.
		float zf = (ndc_z * 0.5f + 0.5f) * 65535.f;
		out.zi  = (zf < 0.f) ? 0 : (zf > 65535.f) ? 65535 : (s32)zf;
		// Reject non-finite / absurd coords so the integer rasterizer can't
		// overflow. 4096 = ~12x screen guard band: keeps tris that straddle the
		// screen edge, kills near-plane blow-ups, and caps every s64 product in
		// FillTriFlat (edge values * 65535 << 16 must stay below 2^63).
		if (!std::isfinite(out.sx) || !std::isfinite(out.sy) ||
		    std::fabs(out.sx) > 4096.f || std::fabs(out.sy) > 4096.f)
			return out;              // out.ok stays false
		out.ok = true;
		return out;
	};

	// Wireframe: draw the three edges of every triangle. The 3D path always
	// feeds us an expanded triangle list (3 verts per tri, triangle_mode
	// GL_TRIANGLES), so step by 3.
	for (u32 i = 0; i + 2 < num_vertices; i += 3)
	{
		SVert a = project(p_vertices[i + 0]);
		SVert b = project(p_vertices[i + 1]);
		SVert c = project(p_vertices[i + 2]);

		// ON-SCREEN COORD PROBE: paint the FIRST triangle's projected screen
		// coords to the LCD and latch, so the boot counter stops overwriting it.
		// Rows (ShowSpinMem layout): 0=Ax 1=Ay 2=Bx 3=By 4=Cx 5=Cy (signed, hex;
		// a small 0..320/0..240 value = on-screen, huge/negative = off-screen).
		// Bottom bar GREEN = all 3 verts projected in front of camera, RED = at
		// least one behind camera (its coords read 0). Screen is 320x240.
		{
			extern bool g_ndCoordsCaptured;
			if (!g_ndCoordsCaptured)
			{
				g_ndCoordsCaptured = true;
				// RAM-logging stays OFF in play builds: with the per-frame
				// messages (RenderTriangles, PIF flood) every vsnprintf runs
				// mid-frame — measurable speed cost, 512KB of noise per run.
				// Flip g_ndLogEnable back on only for debugging sessions.
			}
		}

		++g_ndTriCount;

#ifdef DAEDALUS_DEBUG_CONSOLE
		// Log the first N triangles' projected screen coords + eye-space input so
		// we can see WHERE geometry lands (onscreen? offscreen? behind camera?).
		// Capped so it can't flood the small render-window log.
		{
			static u32 s_logTri = 0;
			// Sampled: 4 consecutive tris every 500, so the 64 lines cover the
			// whole run (logo AND in-game) instead of just the first frame.
			if (s_logTri < 64 && (g_ndTriCount % 500) < 4)
			{
				++s_logTri;
				extern bool g_ndLogEnable; g_ndLogEnable = true; // mesh diagnostics
				// Integer-only (no %f — it hangs on NaN/huge on this libc).
				DBGConsole_Msg(0, "TRI%u ok=%d%d%d  scr a(%d,%d) b(%d,%d) c(%d,%d)  eyeA(%d,%d,%d)",
					s_logTri, a.ok?1:0, b.ok?1:0, c.ok?1:0,
					(int)a.sx,(int)a.sy,(int)b.sx,(int)b.sy,(int)c.sx,(int)c.sy,
					(int)p_vertices[i].Position.x, (int)p_vertices[i].Position.y, (int)p_vertices[i].Position.z);
				g_ndLogEnable = false;
			}
		}
#endif

		if (!a.ok || !b.ok || !c.ok)
			continue;

		// NOTE: NO backface cull here. BaseRenderer::AddTri already backface-culls
		// during T&L (projected-pos cross product, BaseRenderer.cpp:499) before tris
		// reach us — a DrawPrimitives-level cull measured CUT=0/5473 (log 32), pure
		// overhead. The fill routines' `if(area<0) swap` only fixes winding of the
		// already-front-facing survivors, not real back-faces.

		extern u32 g_rTrisTex, g_rTrisFlat, g_rTrisWire;
		const c32 & shade = p_vertices[i].Colour;
		if (kWireframe)
		{
			++g_rTrisWire;
			const u16 col = ColourTo565(shade);
			DrawLine((int)a.sx, (int)a.sy, (int)b.sx, (int)b.sy, col);
			DrawLine((int)b.sx, (int)b.sy, (int)c.sx, (int)c.sy, col);
			DrawLine((int)c.sx, (int)c.sy, (int)a.sx, (int)a.sy, col);
		}
		else if (has_texture && s_texPx)
		{
			++g_rTrisTex;
			extern bool g_ndZTest;
			// Per-vertex UV -> 16.16 texels relative to the tile origin.
			// Clamp to +/-2047 texels so every s64 product in FillTriTex stays
			// in range (and NaN/garbage can't hit s32-conversion UB).
			auto fixUV = [](float t, float off) -> s32 {
				float f = (t - off);
				if (!std::isfinite(f)) f = 0.f;
				if (f >  2047.f) f =  2047.f;
				if (f < -2047.f) f = -2047.f;
				return (s32)(f * 65536.f);
			};
			// Resolve the combiner's A/B/D sources for THIS triangle.
			auto resolve = [&shade](u8 src, s32 & r, s32 & g, s32 & b) {
				switch (src) {
				case SRC_SHADE: r = shade.GetR(); g = shade.GetG(); b = shade.GetB(); break;
				case SRC_PRIM:  { c32 p(s_primCol); r = p.GetR(); g = p.GetG(); b = p.GetB(); } break;
				case SRC_ENV:   { c32 e(s_envCol);  r = e.GetR(); g = e.GetG(); b = e.GetB(); } break;
				case SRC_ONE:   r = g = b = 255; break;
				default:        r = g = b = 0;   break;
				}
			};
			s32 kar, kag, kab, kbr, kbg, kbb, kdr, kdg, kdb;
			resolve(s_cmbA, kar, kag, kab);
			resolve(s_cmbB, kbr, kbg, kbb);
			resolve(s_cmbD, kdr, kdg, kdb);
			// Pick the cheapest specialized kernel this batch's mux allows:
			// B=D=0 -> modulate (or replace when A is also ONE); else generic.
			ECmbMode mode = CMB_GENERIC;
			if (s_cmbB == SRC_ZERO && s_cmbD == SRC_ZERO)
				mode = (s_cmbA == SRC_ONE) ? CMB_REPLACE : CMB_MODULATE;
			extern u32 g_rCmbModulate, g_rCmbReplace, g_rCmbGeneric;
			if (mode == CMB_MODULATE) ++g_rCmbModulate;
			else if (mode == CMB_REPLACE) ++g_rCmbReplace;
			else ++g_rCmbGeneric;
			const int wf = (s_wrapS == WRAP_REPEAT && s_wrapT == WRAP_REPEAT) ? 1 : 0;
			kFillTriTex[g_ndZTest ? 1 : 0][mode][wf](
			           (int)a.sx, (int)a.sy, a.zi,
			           fixUV(p_vertices[i+0].Texture.x, s_texOffS), fixUV(p_vertices[i+0].Texture.y, s_texOffT),
			           (int)b.sx, (int)b.sy, b.zi,
			           fixUV(p_vertices[i+1].Texture.x, s_texOffS), fixUV(p_vertices[i+1].Texture.y, s_texOffT),
			           (int)c.sx, (int)c.sy, c.zi,
			           fixUV(p_vertices[i+2].Texture.x, s_texOffS), fixUV(p_vertices[i+2].Texture.y, s_texOffT),
			           kar, kag, kab, kbr, kbg, kbb, kdr, kdg, kdb);
		}
		else
		{
			++g_rTrisFlat;
			extern bool g_ndZTest;
			if (g_ndZTest)
				FillTriFlat<true>((int)a.sx, (int)a.sy, a.zi,
				                  (int)b.sx, (int)b.sy, b.zi,
				                  (int)c.sx, (int)c.sy, c.zi, ColourTo565(shade));
			else
				FillTriFlat<false>((int)a.sx, (int)a.sy, a.zi,
				                   (int)b.sx, (int)b.sy, b.zi,
				                   (int)c.sx, (int)c.sy, c.zi, ColourTo565(shade));
		}
	}
}

void RendererNDLESS::RenderUsingRenderSettings( const CBlendStates * states, DaedalusVtx * p_vertices, u32 num_vertices, u32 triangle_mode)
{
	const CAlphaRenderSettings *	alpha_settings( states->GetAlphaSettings() );

	SRenderState	state;

	state.Vertices = p_vertices;
	state.NumVertices = num_vertices;
	state.PrimitiveColour = mPrimitiveColour;
	state.EnvironmentColour = mEnvColour;

	if( states->GetNumStates() > 1 )
	{
		memcpy( mVtx_Save, p_vertices, num_vertices * sizeof( DaedalusVtx ) );
	}

	for( u32 i = 0; i < states->GetNumStates(); ++i )
	{
		const CRenderSettings *		settings( states->GetColourSettings( i ) );

		bool install_texture0( settings->UsesTexture0() || alpha_settings->UsesTexture0() );
		bool install_texture1( settings->UsesTexture1() || alpha_settings->UsesTexture1() );

		SRenderStateOut out = {};

		settings->Apply( install_texture0 || install_texture1, state, out );
		alpha_settings->Apply( install_texture0 || install_texture1, state, out );

		// TODO: this nobbles the existing diffuse colour on each pass. Need to use a second buffer...
		if( i > 0 )
		{
			memcpy( p_vertices, mVtx_Save, num_vertices * sizeof( DaedalusVtx ) );
		}

		if(out.VertexExpressionRGB != nullptr)
		{
			out.VertexExpressionRGB->ApplyExpressionRGB( state );
		}
		if(out.VertexExpressionA != nullptr)
		{
			out.VertexExpressionA->ApplyExpressionAlpha( state );
		}

		bool installed_texture = false;

		u32 texture_idx;

		if(install_texture0 || install_texture1)
		{
			u32	tfx = GL_MODULATE;
			switch( out.BlendMode )
			{
			case PBM_MODULATE:
				tfx = GL_MODULATE;
				break;
			case PBM_REPLACE:
				tfx = GL_REPLACE;
				break;
			case PBM_BLEND:
				tfx = GL_BLEND;
				float envcolor[4] = { out.TextureFactor.GetRf(), out.TextureFactor.GetGf(), out.TextureFactor.GetBf(), out.TextureFactor.GetAf() };
				glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, envcolor);
				break;
			}
			
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, tfx);

			if( g_ROM.T1_HACK )
			{
				// NB if install_texture0 and install_texture1 are both set, 1 wins out
				texture_idx = install_texture1;

				// NOTE: Rinnegatamante 15/04/20
				// Technically we calculate this on DrawTriangles, is it enough?
				
				/*const CNativeTexture * texture1 = mBoundTexture[ 1 ];

				if( install_texture1 && texture1 && mTnL.Flags.Texture && (mTnL.Flags._u32 & (TNL_LIGHT|TNL_TEXGEN)) != (TNL_LIGHT|TNL_TEXGEN) )
				{
					
					float scale_x = texture1->GetScaleX();
					float scale_y = texture1->GetScaleY();

					sceGuTexOffset( -mTileTopLeft[ 1 ].s * scale_x / 4.f,
									-mTileTopLeft[ 1 ].t * scale_y / 4.f );
					sceGuTexScale( scale_x, scale_y );
				}*/
			}
			else
			{
				// NB if install_texture0 and install_texture1 are both set, 0 wins out
				texture_idx = install_texture0 ? 0 : 1;
			}

			std::shared_ptr<CNativeTexture> texture;

			if(out.MakeTextureWhite)
			{
				TextureInfo white_ti = mBoundTextureInfo[ texture_idx ];
				white_ti.SetWhite(true);
				texture = CTextureCache::Get()->GetOrCreateTexture( white_ti );
			}
			else
			{
				texture = mBoundTexture[ texture_idx ];
			}

			if(texture != nullptr)
			{
				texture->InstallTexture();
				installed_texture = true;
			}
		}

		// If no texture was specified, or if we couldn't load it, clear it out
		if( !installed_texture )
			glDisable(GL_TEXTURE_2D);
		else
		{
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, mTexWrap[texture_idx].u);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, mTexWrap[texture_idx].v);
		}

		DrawPrimitives(p_vertices, num_vertices, triangle_mode, installed_texture);

		/*if ( mTnL.Flags.Fog )
		{
			RenderFog( p_FogVtx, num_vertices, triangle_mode, render_flags );
		}*/
	}
}


void RendererNDLESS::RenderUsingCurrentBlendMode(const float* mat_project, DaedalusVtx * p_vertices, u32 num_vertices, u32 triangle_mode, bool disable_zbuffer )
{
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf((float*)mat_project);
	
	if ( disable_zbuffer )
	{
		glDisable(GL_DEPTH_TEST);
		glDepthMask(GL_FALSE);
	}
	else
	{
		// Decal mode
		if( gRDPOtherMode.zmode == 3 )
		{
			glPolygonOffset(-1.0, -1.0);
		}
		else
		{
			glPolygonOffset(0, 0);
		}
		
		// Enable or Disable ZBuffer test
		if ( (mTnL.Flags.Zbuffer & gRDPOtherMode.z_cmp) || gRDPOtherMode.z_upd )
		{
			glEnable(GL_DEPTH_TEST);
		}
		else
		{
			glDisable(GL_DEPTH_TEST);
		}

		glDepthMask( gRDPOtherMode.z_upd ? GL_TRUE : GL_FALSE );
	}
	
	u32 cycle_mode = gRDPOtherMode.cycle_type;
	
	// Initiate Texture Filter
	//
	// G_TF_AVERAGE : 1, G_TF_BILERP : 2 (linear)
	// G_TF_POINT   : 0 (nearest)
	//
	if( ((gRDPOtherMode.text_filt != G_TF_POINT) && cycle_mode != CYCLE_COPY) || (gGlobalPreferences.ForceLinearFilter) )
	{
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	}
	else
	{
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
	}
	
	// Initiate Blender
	//
	if(cycle_mode < CYCLE_COPY && gRDPOtherMode.force_bl)
	{
		InitBlenderMode();
	}
	else if (gRDPOtherMode.clr_on_cvg)
	{
		if ((cycle_mode == CYCLE_1CYCLE && gRDPOtherMode.c1_m2a == 1) ||
		    (cycle_mode == CYCLE_2CYCLE && gRDPOtherMode.c2_m2a == 1)) {
			glBlendFunc(GL_ZERO, GL_ONE);
			glEnable(GL_BLEND);
		} else
			glDisable( GL_BLEND );
	}
	else
	{
		glDisable( GL_BLEND );
	}
	
	// Initiate Alpha test
	//
	if( (gRDPOtherMode.alpha_compare == G_AC_THRESHOLD) && !gRDPOtherMode.alpha_cvg_sel )
	{
		u8 alpha_threshold = mBlendColour.GetA();
		glAlphaFunc((alpha_threshold || g_ROM.ALPHA_HACK) ? GL_GEQUAL : GL_GREATER, mBlendColour.GetAf());
		glEnable(GL_ALPHA_TEST);
	}
	else if (gRDPOtherMode.cvg_x_alpha)
	{
		glAlphaFunc(GL_GEQUAL, 0.04392f);
		glEnable(GL_ALPHA_TEST);
	}
	else
	{
		glDisable(GL_ALPHA_TEST);
	}
	
	SBlendStateEntry		blend_entry;

	Daedalus_ShowStage(10, num_vertices, cycle_mode, (u32)(mMux & 0xFFFFFFFF)); // before blend-state lookup
	switch ( cycle_mode )
	{
		case CYCLE_COPY:		blend_entry.States = mCopyBlendStates; break;
		case CYCLE_FILL:		blend_entry.States = mFillBlendStates; break;
		case CYCLE_1CYCLE:		blend_entry = LookupBlendState( mMux, false ); break;
		case CYCLE_2CYCLE:		blend_entry = LookupBlendState( mMux, true ); break;
	}
	Daedalus_ShowStage(11, num_vertices, blend_entry.OverrideFunction ? 1 : 0,
		blend_entry.States ? 1 : 0); // blend-state lookup returned
	
	if( blend_entry.OverrideFunction != nullptr )
	{
		// Local vars for now
		SBlendModeDetails details;

		details.EnvColour = mEnvColour;
		details.PrimColour = mPrimitiveColour;
		details.InstallTexture = true;
		details.ColourAdjuster.Reset();

		blend_entry.OverrideFunction( details );

		bool installed_texture = false;

		if( details.InstallTexture )
		{
			int texture_idx = g_ROM.T1_HACK ? 1 : 0;

			if( mBoundTexture[ texture_idx ] )
			{
				mBoundTexture[ texture_idx ]->InstallTexture();
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, mTexWrap[texture_idx].u);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, mTexWrap[texture_idx].v);
				installed_texture = true;
			}
		}
		
		// If no texture was specified, or if we couldn't load it, clear it out
		if( !installed_texture )
		{
			glDisable(GL_TEXTURE_2D);
		}
		

		details.ColourAdjuster.Process(p_vertices, num_vertices);
		DrawPrimitives(p_vertices, num_vertices, triangle_mode, installed_texture);
	}
	else if( blend_entry.States != nullptr )
	{
		Daedalus_ShowStage(12, num_vertices, blend_entry.States->GetNumStates(), 0); // into RenderUsingRenderSettings
		RenderUsingRenderSettings( blend_entry.States, p_vertices, num_vertices, triangle_mode );
	}
	else
	{
		#ifdef DAEDALUS_DEBUG_CONSOLE
		// Set default states
		DAEDALUS_ERROR( "Unhandled blend mode" );
		#endif
		glDisable(GL_TEXTURE_2D);
		DrawPrimitives(p_vertices, num_vertices, triangle_mode, false);
	}

}

// Profile accumulators (reset+logged every 8 blits in GraphicsContextNDLESS).
u32 g_profDL  = 0; // whole DLParser_Process
u32 g_profRas = 0; // RenderTriangles (combiner setup + rasterizer)

void RendererNDLESS::RenderTriangles(DaedalusVtx *p_vertices, u32 num_vertices, bool disable_zbuffer)
{
	struct SProf {
		u32 t0;
		SProf()  { t0 = Daedalus_Ticks(); }
		// Timer is 16-bit: accumulate mod-65536 deltas (each call < 1 wrap).
		~SProf() { g_profRas += (u16)(Daedalus_Ticks() - t0); }
	} prof_;
	// Software rasterizer: honour the batch's z-buffer setting (also require
	// the RDP z-compare bit, like the GL renderer does).
	{ extern bool g_ndZTest;
	  g_ndZTest = !disable_zbuffer && (gRDPOtherMode.z_cmp || gRDPOtherMode.z_upd); }

	// NDLESS: Debug - track RenderTriangles calls
	static int render_count = 0; // NDLESS
	render_count++; // NDLESS
	{ extern u32 g_dbgRenderTris; ++g_dbgRenderTris; } // NDLESS render diag
	//	Daedalus_ShowStage(5, num_vertices, disable_zbuffer ? 1 : 0, 0); // RenderTriangles entry // disabled
	#ifdef DAEDALUS_DEBUG_CONSOLE
	DBGConsole_Msg(0, "RenderTriangles #%d - num_vertices: %u, texture: %s", // NDLESS
		render_count, num_vertices, mTnL.Flags.Texture ? "YES" : "NO"); // NDLESS
	#endif

	// Texture snapshot: decode the current N64 tile into an RGBA8888 native
	// texture and bind it to the software sampler. (This path was disabled
	// during wireframe bring-up because it "hung" — that was the TempVerts
	// null-pointer heap corruption, since fixed, wedging the allocations here.)
	// White-texture diagnosis (BK): count WHY a tri that WANTS a texture fails to
	// bind. null = mBoundTexture[0] never created; nodata = created but its pixel
	// malloc failed (HasData false). Emitted in PROF, reset per frame by the GC.
	extern u32 g_ndTexWant, g_ndTexFailNull, g_ndTexFailNoData;
	bool textured = false;
	if (mTnL.Flags.Texture && MuxUsesTexture(mMux))
	{
		// Time the tile snapshot/decode — a hidden sub-slice of "ras" (RenderTriangles
		// is timed whole into g_profRas); tells us how much of raster is decode.
		extern u32 g_profTexDecode, g_rTexBinds;
		u32 _td0 = Daedalus_Ticks();
		UpdateTileSnapshots( mTextureTile );
		g_profTexDecode += (u16)(Daedalus_Ticks() - _td0);
		++g_rTexBinds;
		const auto & texture = mBoundTexture[0];
		++g_ndTexWant;
		if      (!texture)              ++g_ndTexFailNull;
		else if (!texture->HasData())   ++g_ndTexFailNoData;
		if (texture && texture->HasData())
		{
			s_texPx     = static_cast<const u32 *>(texture->GetData());
			s_texStride = texture->GetStride() / 4;
			s_texMaskS  = texture->GetCorrectedWidth()  - 1;
			s_texMaskT  = texture->GetCorrectedHeight() - 1;
			s_texOffS   = mTileTopLeft[0].s / 4.0f;
			s_texOffT   = mTileTopLeft[0].t / 4.0f;
			// Honour clamp instead of always repeating (was the cause of trees
			// tiling). MIRROR is already baked into the buffer at decode time, so
			// it maps to REPEAT here (see WrapCoord note). mTexWrap holds the
			// BaseRenderer stub values 0=clamp 1=repeat 2=mirror.
			auto toWrap = [](u32 w) -> u8 {
				return (w == ND_WRAP_CLAMP) ? WRAP_CLAMP : WRAP_REPEAT;
			};
			s_wrapS = toWrap(mTexWrap[0].u);
			s_wrapT = toWrap(mTexWrap[0].v);
			textured    = true;

#ifdef DAEDALUS_DEBUG_CONSOLE
			// TEXTURE-BIND DUMP: sample the first N binds so we can SEE what a tree
			// actually is (real vs corrected dims, GL wrap, and the raw RDP tile
			// fields) instead of guessing. corrW>realW => pow2 pad; mirror/clamp
			// tell us the true addressing.
			{
				static u32 s_logTex = 0;
				const RDP_Tile & t = gRDPStateManager.GetTile(mActiveTile[0]);
				const RDP_TileSize & ts = gRDPStateManager.GetTileSize(mActiveTile[0]);
				// Only the INTERESTING binds: anything not plain-repeat (clamp/mirror
				// set, non-repeat wrap, or pow2-padded) — that's where a "strange"
				// tree would show up. Skips the flood of 32x32 repeat terrain tiles.
				const bool interesting =
					t.clamp_s || t.clamp_t || t.mirror_s || t.mirror_t ||
					mTexWrap[0].u != ND_WRAP_REPEAT || mTexWrap[0].v != ND_WRAP_REPEAT ||
					texture->GetCorrectedWidth()  != ts.GetWidth() ||
					texture->GetCorrectedHeight() != ts.GetHeight();
				if (s_logTex < 48 && interesting)
				{
					++s_logTex;
					extern bool g_ndLogEnable; g_ndLogEnable = true;
					DBGConsole_Msg(0, "TEX%u corr[%ux%u] tile[%ux%u] str=%u wrap[u%x v%x] mask[s%u t%u] mir[s%u t%u] clamp[s%u t%u] off[%d,%d]",
						s_logTex,
						texture->GetCorrectedWidth(), texture->GetCorrectedHeight(),
						ts.GetWidth(), ts.GetHeight(), s_texStride,
						mTexWrap[0].u, mTexWrap[0].v,
						t.mask_s, t.mask_t, t.mirror_s, t.mirror_t, t.clamp_s, t.clamp_t,
						(int)mTileTopLeft[0].s, (int)mTileTopLeft[0].t);
					g_ndLogEnable = false;
				}
			}
#endif
		}
	}

	if (textured)
	{
		// Map the RDP colour-combiner mux onto our fixed software kernel:
		//     out = D + ((A - B) * texel) >> 8
		// The texel is hardwired as the C multiplicand, so we can express any
		// combine of the form  D + (A-B)*<texel>  with A/B/D flat colours
		// (SHADE/PRIM/ENV/ONE/ZERO). (Alpha isn't combined — the texel alpha only
		// drives the cutout test.)
		//
		// The mux packs TWO cycles (RDP_Combine). In 1-cycle mode only cycle-0 is
		// visible; in 2-cycle mode the OUTPUT is cycle-1, whose inputs may name
		// COMBINED (= cycle-0's result). BK leans on 2-cycle (texel*shade lighting,
		// prim modulation, ...) — decoding cycle-0 there yields garbage sources
		// that collapse to a white D term (the "white shadow/feet/wings/sky" bug).
		// So with DAEDALUS_ND_ACCURATE_COMBINER set we decode the correct cycle and
		// treat COMBINED as "the textured value" flowing out of cycle-0.
		//
		// DAEDALUS_ND_ACCURATE_COMBINER 0 = simplified (cycle-0 only): faster,
		//   fine for SM64, WRONG for BK's 2-cycle combines.
		// DAEDALUS_ND_ACCURATE_COMBINER 1 = 2-cycle aware: correct for BK
		// (confirmed on-device — main geometry renders right; only particles/FX
		// remain, a separate combine tail). 0 = cycle-0 only (SM64-simplified).
		#define DAEDALUS_ND_ACCURATE_COMBINER 1

		const u32 mux0 = (u32)(mMux >> 32), mux1 = (u32)mMux;

		// A/B/D slot source -> flat colour. TEXEL0/1 (and, in 2-cycle, COMBINED)
		// never reach here as a flat colour — they're the texel multiplicand.
		auto srcABD = [](u32 v) -> u8 {
			switch (v) { case 3: return SRC_PRIM; case 4: return SRC_SHADE;
			             case 5: return SRC_ENV;  case 6: return SRC_ONE;
			             default: return SRC_ZERO; }
		};
		// C slot source -> colour, for the commuted (texel-in-A) case.
		auto srcC = [](u32 v) -> u8 {
			switch (v) { case 3: return SRC_PRIM; case 4: return SRC_SHADE;
			             case 5: return SRC_ENV;  default: return SRC_ONE; }
		};
		// One-cycle decode. isTex(v) marks a source carrying the texture (TEXEL0/1,
		// plus COMBINED in 2-cycle). Folds (A-B)*C+D onto D + (A-B)*texel.
		auto decodeCycle = [&](u32 a, u32 b, u32 c, u32 d, auto isTex) {
			if      (isTex(c)) { s_cmbA = srcABD(a); s_cmbB = srcABD(b); s_cmbD = srcABD(d); } // D+(A-B)*texel
			else if (isTex(a)) { s_cmbA = srcC(c);   s_cmbB = SRC_ZERO;  s_cmbD = srcABD(d); } // c*texel + d
			else if (isTex(d)) { s_cmbA = SRC_ONE;   s_cmbB = SRC_ZERO;  s_cmbD = SRC_ZERO; }  // replace (texel)
			else               { s_cmbA = SRC_SHADE; s_cmbB = SRC_ZERO;  s_cmbD = SRC_ZERO; }  // fallback modulate
		};

	#if DAEDALUS_ND_ACCURATE_COMBINER
		if (gRDPOtherMode.cycle_type == CYCLE_2CYCLE)
		{
			// Cycle-1 RGB fields (RDP_Combine bit layout): the visible output.
			const u32 a1 = (mux0 >>  5) & 0xF;   // aRGB1 (mux bits 37..40)
			const u32 b1 = (mux1 >> 24) & 0xF;   // bRGB1 (mux bits 24..27)
			const u32 c1 = (mux0      ) & 0x1F;  // cRGB1 (mux bits 32..36)
			const u32 d1 = (mux1 >>  6) & 0x7;   // dRGB1 (mux bits  6.. 8)
			// COMBINED(0) is cycle-0's result — here it carries the texel.
			decodeCycle(a1, b1, c1, d1, [](u32 v){ return v == 0 || v == 1 || v == 2; });
		}
		else
	#endif
		{
			// Cycle-0 RGB fields: the only visible combine in 1-cycle mode.
			const u32 a0 = (mux0 >> 20) & 0xF;
			const u32 b0 = (mux1 >> 28) & 0xF;
			const u32 c0 = (mux0 >> 15) & 0x1F;
			const u32 d0 = (mux1 >> 15) & 0x7;
			decodeCycle(a0, b0, c0, d0, [](u32 v){ return v == 1 || v == 2; });
		}

		s_primCol = mPrimitiveColour.GetColour();
		s_envCol  = mEnvColour.GetColour();

#ifdef DAEDALUS_DEBUG_CONSOLE
		// MUX DUMP: log each DISTINCT combiner mux we bind (with cycle type + both
		// cycles' RGB source indices) so we can implement BK's ACTUAL combines
		// instead of guessing. Small ring of seen muxes to avoid log flooding.
		{
			static u64 s_seen[64]; static u32 s_nSeen = 0;
			bool known = false;
			for (u32 k = 0; k < s_nSeen; ++k) if (s_seen[k] == mMux) { known = true; break; }
			if (!known && s_nSeen < 64)
			{
				s_seen[s_nSeen++] = mMux;
				const u32 a0=(mux0>>20)&0xF, b0=(mux1>>28)&0xF, c0=(mux0>>15)&0x1F, d0=(mux1>>15)&0x7;
				const u32 a1=(mux0>>5)&0xF,  b1=(mux1>>24)&0xF, c1=(mux0)&0x1F,     d1=(mux1>>6)&0x7;
				extern bool g_ndLogEnable; g_ndLogEnable = true;
				DBGConsole_Msg(0, "MUX cyc=%u %08x%08x c0[a%u b%u c%u d%u] c1[a%u b%u c%u d%u]",
					gRDPOtherMode.cycle_type, mux0, mux1,
					a0,b0,c0,d0, a1,b1,c1,d1);
				g_ndLogEnable = false;
			}
		}
#endif
	}

	// Still bypassing RenderUsingCurrentBlendMode/CCombinerTree: the software
	// rasterizer approximates the combiner as texture*shade (modulate), which
	// covers the vast majority of surfaces. Full mux handling can come later.
	DrawPrimitives(p_vertices, num_vertices, GL_TRIANGLES, textured);
}

void RendererNDLESS::TexRect(u32 tile_idx, const glm::vec2 & xy0, const glm::vec2 & xy1, TexCoord st0, TexCoord st1)
{
	// FIXME(strmnnrmn): in copy mode, depth buffer is always disabled. Might not need to check this explicitly.
	UpdateTileSnapshots( tile_idx );

	// NB: we have to do this after UpdateTileSnapshot, as it set up mTileTopLeft etc.
	// We have to do it before PrepareRenderState, because those values are applied to the graphics state.
	PrepareTexRectUVs(&st0, &st1);
	
	glm::vec2 uv0( (float)st0.s / 32.f, (float)st0.t / 32.f );
	glm::vec2 uv1( (float)st1.s / 32.f, (float)st1.t / 32.f );

	glm::vec2 screen0;
	glm::vec2 screen1;
	
	if( gGlobalPreferences.ViewportType == VT_FULLSCREEN_HD )
	{
		screen0.x = roundf( roundf( HD_SCALE * xy0.x ) * mN64ToScreenScale.x + 40 );
		screen0.y = roundf( roundf( xy0.y )            * mN64ToScreenScale.y + mN64ToScreenTranslate.y );

		screen1.x = roundf( roundf( HD_SCALE * xy1.x ) * mN64ToScreenScale.x + 40 ); 
		screen1.y = roundf( roundf( xy1.y )            * mN64ToScreenScale.y + mN64ToScreenTranslate.y );
	}
	else
	{
		ConvertN64ToScreen( xy0, screen0 );
		ConvertN64ToScreen( xy1, screen1 );
	}

	const f32 depth = gRDPOtherMode.depth_source ? mPrimDepth : 0.0f;

	auto texture = mBoundTexture[0];

	//TODO: Software rendering - use texture coords directly, no scaling needed
	//float scale_x = texture->GetScaleX();
	//float scale_y = texture->GetScaleY();

	DaedalusVtx p_vertices[4];

	p_vertices[0].Texture.x = uv0.x; // * scale_x;
	p_vertices[0].Texture.y = uv0.y; // * scale_y;
	p_vertices[1].Texture.x = uv1.x; // * scale_x;
	p_vertices[1].Texture.y = uv0.y; // * scale_y;
	p_vertices[2].Texture.x = uv0.x; // * scale_x;
	p_vertices[2].Texture.y = uv1.y; // * scale_y;
	p_vertices[3].Texture.x = uv1.x; // * scale_x;
	p_vertices[3].Texture.y = uv1.y; // * scale_y;
	
	p_vertices[0].Position.x = screen0.x;
	p_vertices[0].Position.y = screen0.y;
	p_vertices[0].Position.z = depth;
	p_vertices[0].Colour = c32(0xffffffff);

	p_vertices[1].Position.x = screen1.x;
	p_vertices[1].Position.y = screen0.y;
	p_vertices[1].Position.z = depth;
	p_vertices[1].Colour = c32(0xffffffff);

	p_vertices[2].Position.x = screen0.x;
	p_vertices[2].Position.y = screen1.y;
	p_vertices[2].Position.z = depth;
	p_vertices[2].Colour = c32(0xffffffff);

	p_vertices[3].Position.x = screen1.x;
	p_vertices[3].Position.y = screen1.y;
	p_vertices[3].Position.z = depth;
	p_vertices[3].Colour = c32(0xffffffff);

	glEnable(GL_TEXTURE_2D);

	//TODO: Implement software rendering for TexRect
	//RenderUsingCurrentBlendMode(glm::value_ptr(mScreenToDevice), p_vertices, 4, GL_TRIANGLE_STRIP, gRDPOtherMode.depth_source ? false : true);
}

void RendererNDLESS::TexRectFlip(u32 tile_idx, const glm::vec2 & xy0, const glm::vec2 & xy1, TexCoord st0, TexCoord st1)
{
	// FIXME(strmnnrmn): in copy mode, depth buffer is always disabled. Might not need to check this explicitly.
	UpdateTileSnapshots( tile_idx );

	// NB: we have to do this after UpdateTileSnapshot, as it set up mTileTopLeft etc.
	// We have to do it before PrepareRenderState, because those values are applied to the graphics state.
	PrepareTexRectUVs(&st0, &st1);

	glm::vec2 uv0( (float)st0.s / 32.f, (float)st0.t / 32.f );
	glm::vec2 uv1( (float)st1.s / 32.f, (float)st1.t / 32.f );

	glm::vec2 screen0;
	glm::vec2 screen1;
	ConvertN64ToScreen( xy0, screen0 );
	ConvertN64ToScreen( xy1, screen1 );

	auto texture = mBoundTexture[0];

	//TODO: Software rendering - use texture coords directly, no scaling needed
	//float scale_x = texture->GetScaleX();
	//float scale_y = texture->GetScaleY();

	DaedalusVtx p_vertices[4];

	p_vertices[0].Position.x = screen0.x;
	p_vertices[0].Position.y = screen0.y;
	p_vertices[0].Position.z = 0.0f;
	p_vertices[0].Colour = c32(0xffffffff);
	p_vertices[0].Texture.x = uv0.x; // * scale_x;
	p_vertices[0].Texture.y = uv0.y; // * scale_y;

	p_vertices[1].Position.x = screen1.x;
	p_vertices[1].Position.y = screen0.y;
	p_vertices[1].Position.z = 0.0f;
	p_vertices[1].Colour = c32(0xffffffff);
	p_vertices[1].Texture.x = uv0.x; // * scale_x;
	p_vertices[1].Texture.y = uv1.y; // * scale_y;

	p_vertices[2].Position.x = screen0.x;
	p_vertices[2].Position.y = screen1.y;
	p_vertices[2].Position.z = 0.0f;
	p_vertices[2].Colour = c32(0xffffffff);
	p_vertices[2].Texture.x = uv1.x; // * scale_x;
	p_vertices[2].Texture.y = uv0.y; // * scale_y;

	p_vertices[3].Position.x = screen1.x;
	p_vertices[3].Position.y = screen1.y;
	p_vertices[3].Position.z = 0.0f;
	p_vertices[3].Colour = c32(0xffffffff);
	p_vertices[3].Texture.x = uv1.x; // * scale_x;
	p_vertices[3].Texture.y = uv1.y; // * scale_y;

	glEnable(GL_TEXTURE_2D);

	//TODO: Implement software rendering for TexRectFlip
	//RenderUsingCurrentBlendMode(glm::value_ptr(mScreenToDevice), p_vertices, 4, GL_TRIANGLE_STRIP, gRDPOtherMode.depth_source ? false : true);
}

void RendererNDLESS::FillRect(const glm::vec2 & xy0, const glm::vec2 & xy1, u32 color)
{
	glm::vec2 screen0;
	glm::vec2 screen1;
	ScaleN64ToScreen( xy0, screen0 );
	ScaleN64ToScreen( xy1, screen1 );
	
	DaedalusVtx p_vertices[4];
	
	p_vertices[0].Position.x = screen0.x;
	p_vertices[0].Position.y = screen0.y;
	p_vertices[0].Position.z = 0.0f;
	p_vertices[0].Colour = c32(color);

	p_vertices[1].Position.x = screen1.x;
	p_vertices[1].Position.y = screen0.y;
	p_vertices[1].Position.z = 0.0f;
	p_vertices[1].Colour = c32(color);

	p_vertices[2].Position.x = screen0.x;
	p_vertices[2].Position.y = screen1.y;
	p_vertices[2].Position.z = 0.0f;
	p_vertices[2].Colour = c32(color);

	p_vertices[3].Position.x = screen1.x;
	p_vertices[3].Position.y = screen1.y;
	p_vertices[3].Position.z = 0.0f;
	p_vertices[3].Colour = c32(color);

	// Software FillRect: direct RGB565 fill of the framebuffer rect. This is
	// how games clear the screen every frame (RDP FILL-mode rectangle), so it
	// must actually write pixels or old frames ghost through.
	{
		int rx0 = (int)screen0.x, ry0 = (int)screen0.y;
		int rx1 = (int)screen1.x, ry1 = (int)screen1.y;
		if (rx0 > rx1) std::swap(rx0, rx1);
		if (ry0 > ry1) std::swap(ry0, ry1);
		rx0 = std::max(rx0, 0); ry0 = std::max(ry0, 0);
		rx1 = std::min(rx1, 319); ry1 = std::min(ry1, 239);
		const u16 col565 = ColourTo565(c32(color)); // same packing as vertex path
		for (int y = ry0; y <= ry1; ++y)
		{
			u16 * row = &gFramebuffer[y * 320];
			for (int x = rx0; x <= rx1; ++x)
				row[x] = col565;
		}
	}
}

void RendererNDLESS::Draw2DTexture(f32 x0, f32 y0, f32 x1, f32 y1,
								f32 u0, f32 v0, f32 u1, f32 v1,
								const std::shared_ptr<CNativeTexture> texture)
{
	texture->InstallTexture();

	//TODO: Software rendering - use texture coords directly, no scaling needed
	//float scale_x = texture->GetScaleX();
	//float scale_y = texture->GetScaleY();

	float sx0 = N64ToScreenX(x0);
	float sy0 = N64ToScreenY(y0);

	float sx1 = N64ToScreenX(x1);
	float sy1 = N64ToScreenY(y1);

	DaedalusVtx p_vertices[4];

	p_vertices[0].Position.x = sx0;
	p_vertices[0].Position.y = sy0;
	p_vertices[0].Position.z = 0.0f;
	p_vertices[0].Colour = c32(0xffffffff);
	p_vertices[0].Texture.x = u0; // * scale_x;
	p_vertices[0].Texture.y = v0; // * scale_y;

	p_vertices[1].Position.x = sx1;
	p_vertices[1].Position.y = sy0;
	p_vertices[1].Position.z = 0.0f;
	p_vertices[1].Colour = c32(0xffffffff);
	p_vertices[1].Texture.x = u1; // * scale_x;
	p_vertices[1].Texture.y = v0; // * scale_y;

	p_vertices[2].Position.x = sx0;
	p_vertices[2].Position.y = sy1;
	p_vertices[2].Position.z = 0.0f;
	p_vertices[2].Colour = c32(0xffffffff);
	p_vertices[2].Texture.x = u0; // * scale_x;
	p_vertices[2].Texture.y = v1; // * scale_y;

	p_vertices[3].Position.x = sx1;
	p_vertices[3].Position.y = sy1;
	p_vertices[3].Position.z = 0.0f;
	p_vertices[3].Colour = c32(0xffffffff);
	p_vertices[3].Texture.x = u1; // * scale_x;
	p_vertices[3].Texture.y = v1; // * scale_y;

	glEnable(GL_TEXTURE_2D);
	//TODO: Implement software rendering for Draw2DTexture
	//RenderUsingCurrentBlendMode(glm::value_ptr(mScreenToDevice), p_vertices, 4, GL_TRIANGLE_STRIP, true);
}

void RendererNDLESS::Draw2DTextureR(f32 x0, f32 y0, f32 x1, f32 y1, f32 x2,
								 f32 y2, f32 x3, f32 y3, f32 s, f32 t,
								 const std::shared_ptr<CNativeTexture> texture)
{	
	texture->InstallTexture();

	//TODO: Software rendering - use texture coords directly, no scaling needed
	//float scale_x = texture->GetScaleX();
	//float scale_y = texture->GetScaleY();

	DaedalusVtx p_vertices[4];

	p_vertices[0].Position.x = N64ToScreenX(x0);
	p_vertices[0].Position.y = N64ToScreenY(y0);
	p_vertices[0].Position.z = 0.0f;
	p_vertices[0].Colour = c32(0xffffffff);
	p_vertices[0].Texture.x = 0.0f;
	p_vertices[0].Texture.y = 0.0f;

	p_vertices[1].Position.x = N64ToScreenX(x1);
	p_vertices[1].Position.y = N64ToScreenY(y1);
	p_vertices[1].Position.z = 0.0f;
	p_vertices[1].Colour = c32(0xffffffff);
	p_vertices[1].Texture.x = s; // * scale_x;
	p_vertices[1].Texture.y = 0.0f;

	p_vertices[2].Position.x = N64ToScreenX(x2);
	p_vertices[2].Position.y = N64ToScreenY(y2);
	p_vertices[2].Position.z = 0.0f;
	p_vertices[2].Colour = c32(0xffffffff);
	p_vertices[2].Texture.x = s; // * scale_x;
	p_vertices[2].Texture.y = t; // * scale_y;

	p_vertices[3].Position.x = N64ToScreenX(x3);
	p_vertices[3].Position.y = N64ToScreenY(y3);
	p_vertices[3].Position.z = 0.0f;
	p_vertices[3].Colour = c32(0xffffffff);
	p_vertices[3].Texture.x = 0.0f;
	p_vertices[3].Texture.y = t; // * scale_y;

	glEnable(GL_TEXTURE_2D);
	//TODO: Implement software rendering for Draw2DTextureR
	//RenderUsingCurrentBlendMode(glm::value_ptr(mScreenToDevice), p_vertices, 4, GL_TRIANGLE_FAN, true);
}

bool CreateRenderer()
{
	gRendererNDLESS = new RendererNDLESS();
	gRenderer    = gRendererNDLESS;
	return true;
}

void DestroyRenderer()
{
	delete gRendererNDLESS;
	gRendererNDLESS = nullptr;
	gRenderer    = nullptr;
}
