/*
Copyright (C) 2007 StrmnNrmn

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/



#include <cstdio>

#include <libndls.h> // NDLESS: For lcd_init, show_msgbox

#include "Debug/Checkpoint.h"
#include "Debug/DBGConsole.h"

#include "HLEGraphics/BaseRenderer.h"
#include "HLEGraphics/TextureCache.h"
#include "HLEGraphics/DLParser.h"
#include "HLEGraphics/DisplayListDebugger.h"

#include "Graphics/GraphicsContext.h"
#include "HLEGraphics/GraphicsPlugin.h"

#include "Utility/Profiler.h"
#include "Utility/FramerateLimiter.h"
#include "Interface/Preferences.h"
#include "System/Timing/Timing.h"

#include "Core/Memory.h"
#include "Core/CPU.h"			// NDLESS: CPU_Halt for clean-exit log capture



extern bool gFrameskipActive;

// NDLESS render-pipeline diagnostics (cumulative until the capture halt).
// Incremented at each choke point so a single log line tells us where
// geometry dies: DL commands dispatched -> tris added -> flushed -> rendered
// -> vertices drawn. Externed by DLParser.cpp / BaseRenderer.cpp / RendererNDLESS.cpp.
u32 g_dbgDLCommands = 0;   // display-list commands dispatched
u32 g_dbgAddTriCall = 0;   // AddTri() attempts
u32 g_dbgAddTriPass = 0;   // AddTri() that survived culling
u32 g_dbgFlushTris  = 0;   // FlushTris() calls
u32 g_dbgRenderTris = 0;   // RenderTriangles() calls
u32 g_dbgDrawVerts  = 0;   // vertices reaching DrawPrimitives
u32 g_dbgVtxLoad    = 0;   // vertices loaded via G_VTX (SetNewVertexInfo)

// Interrupt-delivery counters: how many times each source was raised. The one
// the stalled game is waiting on will stay frozen while the others climb.
// On-screen coord probe: once the first triangle's projected coords are painted
// to the LCD, this latches true so the boot counter stops repainting over them.
bool g_ndCoordsCaptured = false;
u32 g_ndFrameBlits = 0;    // UpdateFrame lcd_blits of the rendered framebuffer

u32 g_dbgVI = 0;   // VI  (vertical retrace)
u32 g_dbgSI = 0;   // SI  (serial / PIF controller)
u32 g_dbgDP = 0;   // DP  (RDP done)
u32 g_dbgPI = 0;   // PI  (cartridge/peripheral DMA done)
u32 g_dbgSP = 0;   // SP  (RSP task done)
u32 g_dbgIntTaken = 0; // interrupts ACTUALLY dispatched to the game handler (vector jump)

u32		gSoundSync = 44100;
u32		gVISyncRate = 1500;
bool	gTakeScreenshot = false;
bool	gTakeScreenshotSS = false;

EFrameskipValue		gFrameskipValue = FV_DISABLED;

float				gCurrentFramerate = 0.0f;

namespace
{
	//u32					gVblCount = 0;
	u32					gFlipCount = 0;
	//float				gCurrentVblrate = 0.0f;
	u64					gLastFramerateCalcTime = 0;
	u64					gTicksPerSecond = 0;

#ifdef DAEDALUS_FRAMERATE_ANALYSIS
	u32					gTotalFrames = 0;
	u64					gFirstFrameTime = 0;
	FILE *				gFramerateFile = nullptr;
#endif

static void	UpdateFramerate()
{
#ifdef DAEDALUS_FRAMERATE_ANALYSIS
	gTotalFrames++;
#endif
	gFlipCount++;

	u64			now {};
	NTiming::GetPreciseTime( &now );

	if(gLastFramerateCalcTime == 0)
	{
		u64		freq {};
		gLastFramerateCalcTime = now;

		NTiming::GetPreciseFrequency( &freq );
		gTicksPerSecond = freq;
	}

#ifdef DAEDALUS_FRAMERATE_ANALYSIS
	if( gFramerateFile == nullptr )
	{
		gFirstFrameTime = now;
		gFramerateFile = fopen( "ux0:data/DaedalusX64/framerate.csv", "w" );
	}
	fprintf( gFramerateFile, "%d,%f\n", gTotalFrames, f32(now - gFirstFrameTime) / f32(gTicksPerSecond) );
#endif

	// If 1 second has elapsed since last recalculation, do it now
	u64		ticks_since_recalc( now - gLastFramerateCalcTime );
	if(ticks_since_recalc > gTicksPerSecond)
	{
		//gCurrentVblrate = float( gVblCount * gTicksPerSecond ) / float( ticks_since_recalc );
		gCurrentFramerate = float( gFlipCount * gTicksPerSecond ) / float( ticks_since_recalc );

		//gVblCount = 0;
		gFlipCount = 0;
		gLastFramerateCalcTime = now;

#ifdef DAEDALUS_FRAMERATE_ANALYSIS
		if( gFramerateFile != nullptr )
		{
			fflush( gFramerateFile );
		}
#endif
	}

}
}

class CGraphicsPluginImpl : public CGraphicsPlugin
{
	public:
	CGraphicsPluginImpl();
	~CGraphicsPluginImpl();

		bool		Initialise();
		
		virtual bool		StartEmulation()		{ return true; }

		virtual void		ViStatusChanged()		{}
		virtual void		ViWidthChanged()		{}
		virtual void		ProcessDList();

		virtual void		UpdateScreen();

		virtual void		RomClosed();
private:
		u32					LastOrigin;
};

CGraphicsPlugin::~CGraphicsPlugin()
{
}


CGraphicsPluginImpl::CGraphicsPluginImpl():	LastOrigin( 0 )
{
}

CGraphicsPluginImpl::~CGraphicsPluginImpl()
{
}

bool CGraphicsPluginImpl::Initialise()
{
	if(!CreateRenderer())
	{
		return false;
	}

	if(!CTextureCache::Create())
	{
		return false;
	}

	if (!DLParser_Initialise())
	{
		return false;
	}

	return true;
}

void CGraphicsPluginImpl::ProcessDList()
{
	// NDLESS: Debug - track ProcessDList calls
	static int dlist_count = 0; // NDLESS
	dlist_count++; // NDLESS
	#ifdef DAEDALUS_DEBUG_CONSOLE
	DBGConsole_Msg(0, "ProcessDList called #%d", dlist_count); // NDLESS
	#endif

	// NDLESS render diagnostics: the pipeline counters (g_dbg*) are painted live
	// to the LCD from the interpreter loop (Daedalus_ShowCounters in Interpret.cpp),
	// so no halt/log is needed here — just read the screen. ProcessDList is only
	// reached for REAL graphics tasks, so once these counters start moving on
	// screen, SM64 has begun submitting geometry.

#ifdef DAEDALUS_DEBUG_DISPLAYLIST
	if (!DLDebugger_Process())
	{
		DLParser_Process();
	}
#else
	// Profile bucket: whole DL processing (parse + T&L + raster).
	{
		extern u32 g_profDL;
		extern u32 g_ndDLCalls; ++g_ndDLCalls;
		u32 t0 = Daedalus_Ticks();
		DLParser_Process();
		// Timer is 16-bit: accumulate mod-65536 deltas (each call < 1 wrap).
		g_profDL += (u16)(Daedalus_Ticks() - t0);
	}
#endif

}

#ifdef DAEDALUS_DEBUG_DISPLAYLIST
extern u32 gNumInstructionsExecuted;
extern u32 gNumDListsCulled;
extern u32 gNumRectsClipped;
#endif

void CGraphicsPluginImpl::UpdateScreen()
{
	DAEDALUS_CHECKPOINT_TAG(TAG_SCREEN);
	u32 current_origin = Memory_VI_GetRegister(VI_ORIGIN_REG);
	static bool Old_FrameskipActive = false;
	static bool Older_FrameskipActive = false;
	
	if( current_origin != LastOrigin)
	{
		if( gGlobalPreferences.DisplayFramerate )
			UpdateFramerate();

		const f32 Fsync = FramerateLimiter_GetSync();

		if (gVideoRateMatch || gAudioRateMatch)
		{
			const f32 inv_Fsync = 1.0f / Fsync;

			gSoundSync  = (u32)(44100.0f * inv_Fsync);
			gVISyncRate = (u32)( 1500.0f * inv_Fsync);

			if( gVISyncRate > 4000 )
				gVISyncRate = 4000;
			else if ( gVISyncRate < 1500 )
				gVISyncRate = 1500;
		}
		
		if(!gFrameskipActive)
		{
			CGraphicsContext::Get()->UpdateFrame( false );

			// NDLESS: Debug - check if we get past UpdateFrame
			#ifdef DAEDALUS_DEBUG_CONSOLE
			DBGConsole_Msg(0, "Past UpdateFrame in UpdateScreen()"); // NDLESS
			#endif
		}

		static u32 current_frame = 0;
		current_frame++;
	
		Older_FrameskipActive = Old_FrameskipActive;
		Old_FrameskipActive = gFrameskipActive;

		switch(gFrameskipValue)
		{
		case FV_DISABLED:
			gFrameskipActive = false;
			break;
		case FV_AUTO1:
			if(!Old_FrameskipActive && (Fsync < 0.965f)) gFrameskipActive = true;
			else gFrameskipActive = false;
			break;
		case FV_AUTO2:
			if((!Old_FrameskipActive | !Older_FrameskipActive) && (Fsync < 0.965f)) gFrameskipActive = true;
			else gFrameskipActive = false;
			break;
		default:
			gFrameskipActive = (current_frame % (gFrameskipValue - 1)) != 0;
			break;
		}

		LastOrigin = current_origin;

		// NDLESS: the port never calls HandleEndOfFrame anywhere, so in-game ESC
		// never worked. Call it here (the per-frame boundary) so ESC can quit.
		extern void HandleEndOfFrame();
		HandleEndOfFrame();
	}

	// (Force-quit rig removed 2026-07-16. Root cause of the post-frame wedge
	// was TempVerts::Alloc leaving Verts NULL on NDLESS — every FlushTris wrote
	// the vertex batch through a null pointer over the OS heap. Fixed in
	// BaseRenderer.cpp; the emulator now free-runs.)
}

void CGraphicsPluginImpl::RomClosed()
{
	#ifdef DAEDALUS_DEBUG_CONSOLE
	DBGConsole_Msg(0, "Finalising Graphics");
	#endif
	DLParser_Finalise();
	CTextureCache::Destroy();
	DestroyRenderer();
}

class std::unique_ptr<CGraphicsPlugin>	CreateGraphicsPlugin()
{
	DBGConsole_Msg( 0, "Initialising Graphics Plugin [NDLESS]" );
	auto plugin = std::make_unique<CGraphicsPluginImpl>();
	if (!plugin->Initialise())
	{
		plugin = nullptr;
	}

	return plugin;
}