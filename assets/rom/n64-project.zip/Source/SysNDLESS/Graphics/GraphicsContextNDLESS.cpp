/*
   DaedalusX64 - TI-Nspire CX II Port
   Graphics Context Implementation - STUB FILE

   TODO: Implement framebuffer rendering for TI-Nspire
   Screen: 320x240 RGB565 little-endian VRAM
   Access framebuffer via SCREEN_BASE_ADDRESS or ndless functions
*/

#include "Graphics/GraphicsContext.h"
#include "Graphics/ColourValue.h"
#include "Debug/DBGConsole.h"
#include "Debug/Checkpoint.h"

#include <libndls.h>
#include <string.h>
#include <stdio.h>

// TODO: Define framebuffer access
// For TI-Nspire CX II: 320x240 RGB565
#define SCREEN_WIDTH  320
#define SCREEN_HEIGHT 240

// Software rasterizer depth-buffer reset (RendererNDLESS.cpp).
extern "C" void NdRasterClearZ();

// Profiler sub-buckets carved out of the "CPU/rest" (tot-dl) share so we can see
// how much is pure bandwidth vs actual MIPS interpretation:
//   clr = per-frame framebuffer + z clears (memset traffic)
//   blt = lcd_blit (framebuffer -> LCD copy)
// true interpreter time = tot - dl - clr - blt.
u32 g_profClr = 0;
u32 g_profBlt = 0;
// Vertex T&L (softfloat transform+light in BaseRenderer::SetNewVertexInfo); a
// sub-slice of dl. dl-ras-tnl = pure DL parse / raster setup.
u32 g_profTnL = 0;

// White-texture diagnosis (BK): per-frame counts of texture-bind failures.
// twant = tris wanting a texture; tnull = mBoundTexture null; tnod = created but
// pixel malloc failed (HasData false); tmf/tmfb = cumulative failed mallocs & bytes.
u32 g_ndTexWant = 0, g_ndTexFailNull = 0, g_ndTexFailNoData = 0;
u32 g_ndTexMallocFail = 0, g_ndTexMallocFailBytes = 0;

// ============================================================================
// PROFILING PROBES (2026-07-17) — measure GPU + CPU so we optimise from data.
// All reset per PROF window (8 frames) unless noted. The 0x900C timer is coarse
// (~20us/tick) so fine work is COUNTED (exact), aggregates are TIMED.
// ============================================================================
// --- Rasterizer work (RendererNDLESS.cpp) ---
u32 g_rTrisTex   = 0;   // textured triangles drawn
u32 g_rTrisFlat  = 0;   // flat (untextured) triangles drawn
u32 g_rTrisWire  = 0;   // wireframe lines (debug builds)
u32 g_rPixTested = 0;   // pixels inside tri bbox that passed the edge test
u32 g_rPixWritten= 0;   // pixels actually written (passed z + alpha) -> real fill
u32 g_rTexBinds  = 0;   // texture binds attempted this window
u32 g_rCmbModulate=0, g_rCmbReplace=0, g_rCmbGeneric=0; // combiner-mode mix
u32 g_profTexDecode = 0; // coarse ticks in texture decode (UpdateTileSnapshots)
// --- CPU interpreter opcode histogram (Interpret.cpp) ---
// [op] = MIPS primary opcode (6 bits); [spec] = SPECIAL funct when op==0.
// Cumulative (not reset) — a steady-state distribution builds up. Emitted as the
// top few each window so we know WHERE interpreter time goes (loads? mult? fpu?).
u32 g_opHist[64]     = {0};
u32 g_opSpecHist[64] = {0};

// Full 32-bit tick delta helper (Daedalus_Ticks is 32-bit free-running).
// ----------------------------------------------------------------------------
// ARM ISA (ARM926EJ-S / ARMv5TE) memory-write microbenchmark. Answers "what is
// the fastest way to move a framebuffer-sized block?" — memcpy vs word loop vs
// LDM/STM burst vs LDRD/STRD (v5TE 64-bit). Each timed over the 150KB fb, looped
// so the coarse timer resolves it. Run ONCE (first PROF window) -> BENCH line.
static void NdRunMemBenchmarks()
{
	const u32 N = SCREEN_WIDTH * SCREEN_HEIGHT;      // 76800 u16 = 150KB
	static u16 src[SCREEN_WIDTH * SCREEN_HEIGHT];
	static u16 dst[SCREEN_WIDTH * SCREEN_HEIGHT];
	for (u32 i = 0; i < N; ++i) src[i] = (u16)i;
	const int LOOPS = 32;                            // amortise 20us/tick
	u32 t0, sink = 0;

	// 1) memset (clear baseline)
	t0 = Daedalus_Ticks();
	for (int l = 0; l < LOOPS; ++l) memset(dst, 0, N * 2);
	u32 tMemset = Daedalus_Ticks() - t0;

	// 2) memcpy (libc)
	t0 = Daedalus_Ticks();
	for (int l = 0; l < LOOPS; ++l) memcpy(dst, src, N * 2);
	u32 tMemcpy = Daedalus_Ticks() - t0;

	// 3) naive u32 word copy loop
	t0 = Daedalus_Ticks();
	for (int l = 0; l < LOOPS; ++l) {
		const u32 * s = (const u32 *)src; u32 * d = (u32 *)dst;
		for (u32 i = 0; i < N / 2; ++i) d[i] = s[i];
	}
	u32 tWord = Daedalus_Ticks() - t0;

	// 4) LDM/STM 8-register burst (32 bytes/iter — one cache line)
	t0 = Daedalus_Ticks();
	for (int l = 0; l < LOOPS; ++l) {
		const u32 * s = (const u32 *)src; u32 * d = (u32 *)dst;
		u32 n = (N * 2) / 32;   // 32-byte blocks
		__asm__ volatile(
			"1:\n\t"
			"ldmia %0!, {r3-r10}\n\t"
			"stmia %1!, {r3-r10}\n\t"
			"subs  %2, %2, #1\n\t"
			"bne   1b\n\t"
			: "+r"(s), "+r"(d), "+r"(n)
			:
			: "r3","r4","r5","r6","r7","r8","r9","r10","memory","cc");
	}
	u32 tLdmStm = Daedalus_Ticks() - t0;

	// 5) LDRD/STRD 64-bit pair (ARMv5TE) x4 unrolled = 32 bytes/iter
	t0 = Daedalus_Ticks();
	for (int l = 0; l < LOOPS; ++l) {
		const u8 * s = (const u8 *)src; u8 * d = (u8 *)dst;
		u32 n = (N * 2) / 32;
		__asm__ volatile(
			"1:\n\t"
			"ldrd r4, r5, [%0, #0]\n\t"  "strd r4, r5, [%1, #0]\n\t"
			"ldrd r6, r7, [%0, #8]\n\t"  "strd r6, r7, [%1, #8]\n\t"
			"ldrd r8, r9, [%0, #16]\n\t" "strd r8, r9, [%1, #16]\n\t"
			"ldrd r10,r11,[%0, #24]\n\t" "strd r10,r11,[%1, #24]\n\t"
			"add  %0, %0, #32\n\t"
			"add  %1, %1, #32\n\t"
			"subs %2, %2, #1\n\t"
			"bne  1b\n\t"
			: "+r"(s), "+r"(d), "+r"(n)
			:
			: "r4","r5","r6","r7","r8","r9","r10","r11","memory","cc");
	}
	u32 tLdrd = Daedalus_Ticks() - t0;

	// 6) the real lcd_blit (fb -> LCD). Not a memcpy — includes the LCD push.
	t0 = Daedalus_Ticks();
	for (int l = 0; l < LOOPS; ++l) lcd_blit(dst, SCR_320x240_565);
	u32 tBlit = Daedalus_Ticks() - t0;

	(void)sink;
	extern bool g_ndLogEnable; g_ndLogEnable = true;
	DBGConsole_Msg(0, "BENCH x%d/150KB memset=%u memcpy=%u word=%u ldmstm=%u ldrd=%u blit=%u (ticks; lower=faster)",
		LOOPS, tMemset, tMemcpy, tWord, tLdmStm, tLdrd, tBlit);
	g_ndLogEnable = false;
}

// Daedalus_Ticks() (16-bit spare timer 0x900C0000) comes from Debug/Checkpoint.h,
// already included above.

// CP15 coprocessor reads (we run privileged — the dynarec cache-clean mcr p15,c7
// ops already work). ID registers are read-only and safe.
static inline u32 ReadCP15_MainID()    { u32 v; __asm__ volatile("mrc p15,0,%0,c0,c0,0":"=r"(v)); return v; }
static inline u32 ReadCP15_CacheType() { u32 v; __asm__ volatile("mrc p15,0,%0,c0,c0,1":"=r"(v)); return v; }
static inline u32 ReadCP15_Control()   { u32 v; __asm__ volatile("mrc p15,0,%0,c1,c0,0":"=r"(v)); return v; }
// TCM (scratchpad) region registers, ARM926 CP15 c9,c1,{0=DTCM,1=ITCM}. Non-zero
// size field => on-chip fast RAM we can address explicitly (the real "pin to fast
// memory" mechanism). Standard on ARM926; reading is PL1 like the c7 ops we use.
static inline u32 ReadCP15_DTCM()      { u32 v; __asm__ volatile("mrc p15,0,%0,c9,c1,0":"=r"(v)); return v; }
static inline u32 ReadCP15_ITCM()      { u32 v; __asm__ volatile("mrc p15,0,%0,c9,c1,1":"=r"(v)); return v; }

// NDLESS: software framebuffer, 320x240 RGB565, pushed to the LCD via lcd_blit().
// Global (not static) so RendererNDLESS.cpp can draw into it directly.
static uint16_t gFramebufferStorage[SCREEN_WIDTH * SCREEN_HEIGHT];
uint16_t* gFramebuffer = gFramebufferStorage;

// NDLESS: Vertex counter for debugging
uint32_t gVerticesThisFrame = 0;

// SCREENSHOT: dump the current RGB565 framebuffer as a 24-bit BMP to /documents.
// Triggered by the '.' key (see main.cpp HandleEndOfFrame). Written as .bmp.tns so
// the desktop link software transfers it; strip the .tns on PC and open the BMP.
// One deliberate flash write per press (brief stall, same as the log flush).
extern "C" void NdSaveScreenshot()
{
	static int shotN = 0;
	char path[64];
	snprintf(path, sizeof(path), "/documents/daedalus_shot%d.bmp.tns", shotN++);
	FILE * f = fopen(path, "wb");
	if (!f) return;

	const int W = SCREEN_WIDTH, H = SCREEN_HEIGHT;
	const uint32_t rowbytes = (uint32_t)W * 3;      // 960, already a multiple of 4
	const uint32_t imgsize  = rowbytes * H;
	const uint32_t filesize = 54 + imgsize;

	uint8_t hdr[54];
	memset(hdr, 0, sizeof(hdr));
	hdr[0] = 'B'; hdr[1] = 'M';
	hdr[2]=filesize; hdr[3]=filesize>>8; hdr[4]=filesize>>16; hdr[5]=filesize>>24;
	hdr[10]=54;                                     // pixel data offset
	hdr[14]=40;                                     // DIB header size
	hdr[18]=W;   hdr[19]=W>>8;                      // width
	hdr[22]=H;   hdr[23]=H>>8;                      // height (positive = bottom-up)
	hdr[26]=1;                                      // planes
	hdr[28]=24;                                     // bpp
	hdr[34]=imgsize; hdr[35]=imgsize>>8; hdr[36]=imgsize>>16; hdr[37]=imgsize>>24;
	fwrite(hdr, 1, 54, f);

	// Rows bottom-up, BGR. RGB565 -> RGB888 with bit-replication.
	static uint8_t row[SCREEN_WIDTH * 3];
	for (int y = H - 1; y >= 0; --y)
	{
		const uint16_t * src = &gFramebuffer[y * W];
		for (int x = 0; x < W; ++x)
		{
			const uint16_t px = src[x];
			uint8_t r = (px >> 11) & 0x1F; r = (r << 3) | (r >> 2);
			uint8_t g = (px >>  5) & 0x3F; g = (g << 2) | (g >> 4);
			uint8_t b =  px        & 0x1F; b = (b << 3) | (b >> 2);
			row[x*3+0] = b; row[x*3+1] = g; row[x*3+2] = r;
		}
		fwrite(row, 1, rowbytes, f);
	}
	fclose(f);
}

class IGraphicsContext : public CGraphicsContext
{
public:
	IGraphicsContext();
	virtual ~IGraphicsContext();

	bool				Initialise();
	bool				IsInitialised() const { return mInitialised; }

	void				ClearAllSurfaces();
	void				ClearToBlack();
	void				ClearZBuffer();
	void				ClearColBuffer(const c32 &colour);
	void				ClearColBufferAndDepth(const c32 &colour);

	void				BeginFrame();
	void				EndFrame();
	void				UpdateFrame(bool wait_for_vbl);
	void				GetScreenSize(u32 * width, u32 * height) const;

	void				SetDebugScreenTarget( ETargetSurface buffer );

	void				ViewportType(u32 *d_width, u32 *d_height) const;
	void				DumpScreenShot();
	void				DumpNextScreen()			{ mDumpNextScreen = 2; }

private:
	bool				mInitialised;
	u32					mDumpNextScreen;
};

template<> bool CSingleton< CGraphicsContext >::Create()
{
	#ifdef DAEDALUS_ENABLE_ASSERTS
	DAEDALUS_ASSERT_Q(mpInstance == nullptr);
	#endif
	mpInstance = std::make_shared<IGraphicsContext>();
	return mpInstance->Initialise();
}

IGraphicsContext::IGraphicsContext()
	: mInitialised(false)
	, mDumpNextScreen(0)
{
}

IGraphicsContext::~IGraphicsContext()
{
}

bool IGraphicsContext::Initialise()
{
	// Framebuffer is a static array (gFramebuffer already points at it).
	// It gets pushed to the LCD in UpdateFrame() via lcd_blit().
	memset(gFramebuffer, 0, SCREEN_WIDTH * SCREEN_HEIGHT * 2);

	mInitialised = true;
	return true;
}

void IGraphicsContext::ClearAllSurfaces()
{
	// TODO: Clear framebuffer to black
	ClearToBlack();
}

void IGraphicsContext::ClearToBlack()
{
	// TODO: Fill framebuffer with black (RGB565 = 0x0000)
	if (gFramebuffer) {
		memset(gFramebuffer, 0, SCREEN_WIDTH * SCREEN_HEIGHT * 2);
	}
}

void IGraphicsContext::ClearZBuffer()
{
	// TODO: Clear depth buffer (if we implement one)
	// For now, no-op
}

void IGraphicsContext::ClearColBuffer(const c32 & colour)
{
	// TODO: Fill framebuffer with specified color converted to RGB565
	if (gFramebuffer) {
		// Convert c32 (RGBA8888) to RGB565
		u16 rgb565 = ((colour.GetR() >> 3) << 11) |
		             ((colour.GetG() >> 2) << 5) |
		             (colour.GetB() >> 3);

		for (u32 i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
			gFramebuffer[i] = rgb565;
		}
	}
}

void IGraphicsContext::ClearColBufferAndDepth(const c32 & colour)
{
	// TODO: Clear both color and depth
	ClearColBuffer(colour);
	ClearZBuffer();
}

void IGraphicsContext::BeginFrame()
{
	// NDLESS: Reset vertex counter for new frame
	gVerticesThisFrame = 0;

	// Start each frame from a clean black slate so the wireframe is visible.
	// (The N64 framebuffer clear goes through FillRect, which the software
	// renderer doesn't implement yet, so we clear here instead.)
	u32 tc = Daedalus_Ticks();
	memset(gFramebuffer, 0, SCREEN_WIDTH * SCREEN_HEIGHT * 2);
	g_profClr += (u16)(Daedalus_Ticks() - tc);
}

void IGraphicsContext::EndFrame()
{
	// NDLESS: Log vertex count for debugging (every frame)
	static int frame_count = 0; // NDLESS
	frame_count++; // NDLESS
	#ifdef DAEDALUS_DEBUG_CONSOLE
	DBGConsole_Msg(0, "EndFrame #%d - Vertices: %u", frame_count, gVerticesThisFrame); // NDLESS
	#endif

	// TODO: Finalize frame rendering
	// For now, no-op
}

void IGraphicsContext::UpdateFrame(bool wait_for_vbl)
{
	// NDLESS: Debug - check if UpdateFrame is called
	static int update_count = 0; // NDLESS
	update_count++; // NDLESS
	#ifdef DAEDALUS_DEBUG_CONSOLE
	DBGConsole_Msg(0, "UpdateFrame #%d (wait_vbl=%d)", update_count, wait_for_vbl ? 1 : 0); // NDLESS
	#endif

	// Blit the wireframe framebuffer to the LCD, but only once the first triangle
	// has been drawn (g_ndCoordsCaptured). Before that the boot counter owns the
	// screen for liveness; after it, we show the actual rendered frame.
	{
		extern bool g_ndCoordsCaptured;
		extern u32 g_ndFrameBlits;
		if (g_ndCoordsCaptured)
		{
			++g_ndFrameBlits; // liveness counter in Interpret.cpp stops once we blit
			u32 tbl = Daedalus_Ticks();
			lcd_blit(gFramebuffer, SCR_320x240_565);
			g_profBlt += (u16)(Daedalus_Ticks() - tbl);
			// Frame boundary: reset the software rasterizer's depth buffer.
			u32 tcz = Daedalus_Ticks();
			NdRasterClearZ();
			g_profClr += (u16)(Daedalus_Ticks() - tcz);

#ifdef NDLESS_DEBUG
			// FRAME PROFILER: every 8 blits log the tick totals of the three
			// buckets (dl = parse+T&L+raster, ras = raster only, tot = wall
			// between blits) + RTC seconds for offline rate calibration.
			// cpu-interpretation share = tot - dl. Debug-only: the per-window
			// histogram scan + one-shot benchmark cost real time, so it is
			// compiled out of release builds.
			{
				extern u32 g_profDL, g_profRas;
				static u32 s_profBlits = 0, s_lastT = 0;
				static u32 s_profTot = 0;
				u32 now = Daedalus_Ticks();
				// Timer is 16-bit: per-frame deltas mod 65536. Undercounts
				// only if a frame exceeds one wrap (~2s @32kHz) — acceptable.
				if (s_lastT) s_profTot += (u16)(now - s_lastT);
				s_lastT = now;
				if ((++s_profBlits & 7) == 0)
				{
					extern bool g_ndLogEnable;
					extern u32 g_ndDLCalls, g_ndCacheFlushes, g_ndCompileCount;
					extern u32 g_ndCacheResets, g_ndLastResetAddr, g_ndLastResetLen;
					g_ndLogEnable = true;

					// One-time CP15 cache geometry dump (I/D size, assoc, line) so
					// we KNOW the cache sizes instead of guessing. ARM926 = L1 only.
					static bool s_cacheProbed = false;
					if (!s_cacheProbed)
					{
						s_cacheProbed = true;
						const u32 mid = ReadCP15_MainID();
						const u32 ct  = ReadCP15_CacheType();
						const u32 cr  = ReadCP15_Control();
						// Decode both size fields (ARMv5, M=0 path): size KB = 512<<sz,
						// assoc = 1<<as, line bytes = 1<<(len+3). M/S/enables printed raw.
						const u32 isz = ct & 0xFFF, dsz = (ct >> 12) & 0xFFF;
						auto kb   = [](u32 f){ return (512u << ((f >> 6) & 7)) >> 10; };
						auto assoc= [](u32 f){ return 1u << ((f >> 3) & 7); };
						auto line = [](u32 f){ return 1u << ((f & 3) + 3); };
						DBGConsole_Msg(0, "CACHE mainid=%08x ctype=%08x ctrl=%08x S=%u",
							mid, ct, cr, (ct >> 24) & 1);
						DBGConsole_Msg(0, "CACHE I: %uKB %u-way %uB line (M=%u)  D: %uKB %u-way %uB line (M=%u)  Ion=%u Don=%u MMU=%u",
							kb(isz), assoc(isz), line(isz), (isz >> 2) & 1,
							kb(dsz), assoc(dsz), line(dsz), (dsz >> 2) & 1,
							(cr >> 12) & 1, (cr >> 2) & 1, cr & 1);

						// TCM probe: size field bits[5:2] (0 = absent), base bits[31:12],
						// enable bit0. Non-zero size => explicit fast scratchpad exists,
						// which is the real "pin to fast memory" mechanism (better than
						// cache lockdown). If this line is the LAST thing in the log, the
						// c9 read faulted -> TCM not accessible in our mode.
						const u32 dtcm = ReadCP15_DTCM();
						const u32 itcm = ReadCP15_ITCM();
						auto tcmkb = [](u32 v){ u32 sf = (v >> 2) & 0xF; return sf ? ((512u << sf) >> 10) : 0u; };
						DBGConsole_Msg(0, "TCM  D: raw=%08x %uKB en=%u base=%08x  I: raw=%08x %uKB en=%u base=%08x",
							dtcm, tcmkb(dtcm), dtcm & 1, dtcm & 0xFFFFF000u,
							itcm, tcmkb(itcm), itcm & 1, itcm & 0xFFFFF000u);
					}

					extern u32 g_profTnL;
					struct timeval tv; gettimeofday(&tv, NULL);
					DBGConsole_Msg(0, "PROF blits=%u tot=%u dl=%u ras=%u tnl=%u clr=%u blt=%u sec=%u dlc=%u cfl=%u cmp=%u rst=%u@%08x+%x",
						s_profBlits, s_profTot, g_profDL, g_profRas, g_profTnL, g_profClr, g_profBlt, (u32)tv.tv_sec,
						g_ndDLCalls, g_ndCacheFlushes, g_ndCompileCount,
						g_ndCacheResets, g_ndLastResetAddr, g_ndLastResetLen);
					// White-texture diagnosis: WHY textured tris fell back to flat white.
					extern u32 g_ndTexWant, g_ndTexFailNull, g_ndTexFailNoData;
					extern u32 g_ndTexMallocFail, g_ndTexMallocFailBytes;
					DBGConsole_Msg(0, "TEXFAIL want=%u null=%u nodata=%u mallocfail=%u bytes=%u",
						g_ndTexWant, g_ndTexFailNull, g_ndTexFailNoData,
						g_ndTexMallocFail, g_ndTexMallocFailBytes);

					// --- GPU raster work this window (exact counts + decode ticks) ---
					// overdraw = pixWritten/pixTested tells us wasted fill; texdec =
					// coarse ticks decoding textures (a hidden cost inside "dl").
					u32 pxT = g_rPixTested ? g_rPixTested : 1;
					DBGConsole_Msg(0, "GPU tris[tex=%u flat=%u wire=%u] px[test=%u writ=%u ovr=%u%%] binds=%u texdec=%u cmb[mod=%u rep=%u gen=%u]",
						g_rTrisTex, g_rTrisFlat, g_rTrisWire,
						g_rPixTested, g_rPixWritten, (g_rPixWritten * 100) / pxT,
						g_rTexBinds, g_profTexDecode,
						g_rCmbModulate, g_rCmbReplace, g_rCmbGeneric);

					// --- CPU interpreter opcode histogram: top 6 primary opcodes +
					// top 4 SPECIAL functs. Tells us where interpreter time goes. ---
					{
						// Top-N by repeated max-scan with a used-mask (distinct picks).
						// Primary list SKIPS op0 (SPECIAL) — it's a category, broken out
						// separately in the spec list below.
						auto topN = [](const u32 * h, u32 * out, int n, int skip) {
							bool used[64] = {false};
							if (skip >= 0) used[skip] = true;
							for (int s = 0; s < n; ++s) {
								u32 best = 0; int bi = -1;
								for (int o = 0; o < 64; ++o)
									if (!used[o] && h[o] >= best) { best = h[o]; bi = o; }
								out[s] = (bi < 0) ? 0 : (u32)bi;
								if (bi >= 0) used[bi] = true;
							}
						};
						u32 bi[6], si[4];
						topN(g_opHist,     bi, 6, 0);   // skip op0=SPECIAL
						topN(g_opSpecHist, si, 4, -1);
						extern u32 g_opHist[64], g_opSpecHist[64];
						DBGConsole_Msg(0, "CPUOP prim: op%u=%u op%u=%u op%u=%u op%u=%u op%u=%u op%u=%u | SPEC(op0)=%u spec%u=%u spec%u=%u spec%u=%u spec%u=%u",
							bi[0],g_opHist[bi[0]], bi[1],g_opHist[bi[1]], bi[2],g_opHist[bi[2]],
							bi[3],g_opHist[bi[3]], bi[4],g_opHist[bi[4]], bi[5],g_opHist[bi[5]],
							g_opHist[0],
							si[0],g_opSpecHist[si[0]], si[1],g_opSpecHist[si[1]],
							si[2],g_opSpecHist[si[2]], si[3],g_opSpecHist[si[3]]);
					}

					// --- ARM memory-primitive benchmark: run ONCE (first window) ---
					{
						static bool s_benched = false;
						if (!s_benched) { s_benched = true; NdRunMemBenchmarks(); }
					}

					g_ndLogEnable = false;
					g_ndDLCalls = 0; // per-window; cfl/cmp stay cumulative
					s_profTot = 0; g_profDL = 0; g_profRas = 0;
					g_profClr = 0; g_profBlt = 0; g_profTnL = 0;
					g_ndTexWant = 0; g_ndTexFailNull = 0; g_ndTexFailNoData = 0;
					// GPU counters reset per window; opcode histogram stays cumulative.
					g_rTrisTex = g_rTrisFlat = g_rTrisWire = 0;
					g_rPixTested = g_rPixWritten = g_rTexBinds = 0;
					g_rCmbModulate = g_rCmbReplace = g_rCmbGeneric = 0;
					g_profTexDecode = 0;
					// mallocfail/bytes stay CUMULATIVE (a single failure is the smoking gun)
				}
			}
#endif // NDLESS_DEBUG
		}
	}
	(void)wait_for_vbl;
}

void IGraphicsContext::GetScreenSize(u32 * width, u32 * height) const
{
	*width = SCREEN_WIDTH;
	*height = SCREEN_HEIGHT;
}

void IGraphicsContext::ViewportType(u32 *d_width, u32 *d_height) const
{
	*d_width = SCREEN_WIDTH;
	*d_height = SCREEN_HEIGHT;
}

void IGraphicsContext::SetDebugScreenTarget( ETargetSurface buffer )
{
	// TODO: Set debug screen target
	// For now, no-op
}

void IGraphicsContext::DumpScreenShot()
{
	// TODO: Save screenshot to file
	// For now, no-op
}
