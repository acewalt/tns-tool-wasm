/*
   DaedalusX64 - TI-Nspire CX II Port
   Native Texture Implementation - STUB FILE

   TODO: Implement texture management for TI-Nspire
   - Convert N64 texture formats to RGB565
   - Manage texture memory
   - Implement texture rendering to framebuffer
*/

#include "Graphics/NativeTexture.h"
#include "Graphics/NativePixelFormat.h"
#include "Graphics/ColourValue.h"
#include "Utility/MathUtil.h"

#include <stdlib.h>
#include <string.h>

// TODO: Port PNG loading or disable it
// #include <png.h>

static const u32 kPalette4BytesRequired = 16 * sizeof( NativePf8888 );
static const u32 kPalette8BytesRequired = 256 * sizeof( NativePf8888 );

static u32 GetTextureBlockWidth( u32 dimension, ETextureFormat texture_format )
{
	DAEDALUS_ASSERT( GetNextPowerOf2( dimension ) == dimension, "This is not a power of 2" );

	// Ensure that the pitch is at least 16 bytes
	while( CalcBytesRequired( dimension, texture_format ) < 16 )
	{
		dimension *= 2;
	}

	return dimension;
}

static inline u32 CorrectDimension( u32 dimension )
{
	static const u32 MIN_TEXTURE_DIMENSION = 8;
	u32 next_pow2 = GetNextPowerOf2( dimension );
	return (next_pow2 > MIN_TEXTURE_DIMENSION) ? next_pow2 : MIN_TEXTURE_DIMENSION;
}

std::shared_ptr<CNativeTexture> CNativeTexture::Create( u32 width, u32 height, ETextureFormat texture_format )
{
	return std::make_shared<CNativeTexture>( width, height, texture_format );
}

CNativeTexture::CNativeTexture( u32 w, u32 h, ETextureFormat texture_format )
:	mTextureFormat( texture_format )
,	mWidth( w )
,	mHeight( h )
,	mCorrectedWidth( CorrectDimension( w ) )
,	mCorrectedHeight( CorrectDimension( h ) )
,	mTextureBlockWidth( GetTextureBlockWidth( mCorrectedWidth, texture_format ) )
,	mpData( nullptr )
,	mpPalette( nullptr )
{
	// TODO: Allocate texture memory
	size_t data_len = GetBytesRequired();
	mpData = malloc(data_len);
	if (mpData) {
		memset(mpData, 0, data_len);
	} else {
		// White-texture diagnosis (BK): pixel malloc failed => this texture will
		// report HasData()==false => renderer falls back to flat white. Count it
		// and the total bytes we tried to hold, emitted in PROF.
		extern u32 g_ndTexMallocFail; extern u32 g_ndTexMallocFailBytes;
		++g_ndTexMallocFail; g_ndTexMallocFailBytes += (u32)data_len;
	}

	// TODO: Allocate palette if needed
	if (texture_format == TexFmt_CI4_8888) {
		mpPalette = malloc(kPalette4BytesRequired);
		if (mpPalette) {
			memset(mpPalette, 0, kPalette4BytesRequired);
		}
	} else if (texture_format == TexFmt_CI8_8888) {
		mpPalette = malloc(kPalette8BytesRequired);
		if (mpPalette) {
			memset(mpPalette, 0, kPalette8BytesRequired);
		}
	}
}

CNativeTexture::~CNativeTexture()
{
	// TODO: Free texture memory
	if (mpData) {
		free(mpData);
		mpData = nullptr;
	}

	if (mpPalette) {
		free(mpPalette);
		mpPalette = nullptr;
	}
}

std::shared_ptr<CNativeTexture> CNativeTexture::CreateFromPng( const std::filesystem::path filename, ETextureFormat texture_format )
{
	// TODO: Implement PNG loading or disable this feature
	// For now, return nullptr
	return nullptr;
}

void CNativeTexture::SetData( void * data, void * palette )
{
	// TODO: Copy texture data
	if (data && mpData) {
		size_t data_len = GetBytesRequired();
		memcpy(mpData, data, data_len);
	}

	if (palette && mpPalette) {
		if (mTextureFormat == TexFmt_CI4_8888) {
			memcpy(mpPalette, palette, kPalette4BytesRequired);
		} else if (mTextureFormat == TexFmt_CI8_8888) {
			memcpy(mpPalette, palette, kPalette8BytesRequired);
		}
	}
}

void CNativeTexture::InstallTexture() const
{
	// TODO: Bind texture for rendering
	// For now, no-op
}

u32 CNativeTexture::GetStride() const
{
	return CalcBytesRequired( mTextureBlockWidth, mTextureFormat );
}

u32 CNativeTexture::GetBytesRequired() const
{
	return GetStride() * mCorrectedHeight;
}

bool CNativeTexture::HasData() const
{
	return mpData != nullptr;
}
