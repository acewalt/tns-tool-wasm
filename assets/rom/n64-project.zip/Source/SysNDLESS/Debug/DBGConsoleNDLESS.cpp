/*
   Copyright (C) 2006 StrmnNrmn

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "Debug/DBGConsole.h"

#ifdef DAEDALUS_DEBUG_CONSOLE

#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <errno.h> // NDLESS: For errno in fopen error checking
#include <unistd.h> // NDLESS: For usleep
#include <time.h> // NDLESS: For timeout tracking

#include "Debug/DebugConsoleImpl.h"
#include "Debug/Checkpoint.h"
#include <libndls.h> // NDLESS: lcd_init around the flash flush
#include "Utility/BatchTest.h"

#ifndef DAEDALUS_NDLESS_LOG_PATH
	#define DAEDALUS_NDLESS_LOG_PATH "/documents/daedalus_debug.log.tns"
#endif

// NDLESS: master log gate. Logging EVERY message from boot bloats the log and,
// worse, ANY inline fwrite/fflush to the calc's flash stalls the CPU mid-emulation
// (hang ~18.74M instrs). So (1) this gate stays false during boot and flips true
// just before the first display list, and (2) we NEVER touch the file during
// emulation — messages go to a RAM buffer and are written out in ONE fwrite at
// exit (Daedalus_FlushLog, called from the clean-exit halt).
bool g_ndLogEnable = false;

// Dynarec-activity counters for the frame profiler (defined here so the PROF
// line links in BOTH builds; the dynarec files increment them, interpreter
// builds leave them 0).
u32 g_ndCacheFlushes  = 0;  // _InvalidateAndFlushCaches calls (compile + link patches)
u32 g_ndDLCalls       = 0;  // DLParser_Process invocations
u32 g_ndCompileCount  = 0;  // dynarec trace compiles
u32 g_ndCacheResets   = 0;  // full fragment-cache nukes (ShouldInvalidateOnWrite hits)
u32 g_ndLastResetAddr = 0;  // last triggering write/invalidate address
u32 g_ndLastResetLen  = 0;  // ... and length

static const size_t kLogBufCap = 512 * 1024;
static char   gLogBuf[kLogBufCap];
static size_t gLogLen = 0;

static void LogWriteRaw(const char* s)
{
    size_t n = strlen(s);
    if (gLogLen + n > kLogBufCap) n = kLogBufCap - gLogLen; // truncate, never overflow
    if (n == 0) return;
    memcpy(gLogBuf + gLogLen, s, n);
    gLogLen += n;
}

extern "C" u32 Daedalus_LogLen() { return (u32)gLogLen; }

// Write the whole RAM log buffer to flash in one shot. Called once, at the
// clean-exit halt, so no flash I/O ever happens while the CPU is emulating.
extern "C" void Daedalus_FlushLog()
{
#ifndef NDLESS_DEBUG
    // Release builds never write the debug log to flash (it would grow to
    // megabytes over a session). Nothing is buffered in the first place.
    return;
#endif
    if (gLogLen == 0) return;
    // Instrumented step-by-step (quit-path debugging): a freeze after one of
    // these paints names the exact libc/OS call that wedges.
    Daedalus_ShowStageLog(0x5A, (u32)gLogLen, 0, 0);       // 90: about to test lcd round-trip
    // Isolate the lcd_init OS round-trip from fopen (16:31 run froze at "90",
    // ambiguous between the two).
    lcd_init(SCR_TYPE_INVALID);
    lcd_init(lcd_type());
    Daedalus_ShowStageLog(0x5E, 0, 0, 0);                  // 94: lcd round-trip OK
    FILE* f = fopen(DAEDALUS_NDLESS_LOG_PATH, "wb");
    Daedalus_ShowStageLog(0x5B, (u32)(uintptr_t)f, 0, 0);  // 91: fopen returned
    if (!f) return;
    size_t written = fwrite(gLogBuf, 1, gLogLen, f);
    Daedalus_ShowStageLog(0x5C, (u32)written, 0, 0);       // 92: fwrite returned
    fclose(f);
    Daedalus_ShowStageLog(0x5D, 0, 0, 0);                  // 93: fclose returned
}

class IDebugConsole : public CDebugConsole
{
public:
    IDebugConsole();
    virtual ~IDebugConsole();

    virtual void Msg(u32 type, const char * format, ...);

    virtual void MsgOverwriteStart();
    virtual void MsgOverwrite(u32 type, const char * format, ...);
    virtual void MsgOverwriteEnd();
};

template<> bool	CSingleton< CDebugConsole >::Create()
{
	DAEDALUS_ASSERT_Q(mpInstance == nullptr);

	mpInstance = std::make_shared<IDebugConsole>();

	return true;
}

IDebugConsole::IDebugConsole()
{
}

IDebugConsole::~IDebugConsole()
{
	// Belt-and-suspenders: if we reach a clean destruction, flush the RAM buffer.
	Daedalus_FlushLog();
}

CDebugConsole::~CDebugConsole()
{
}

void IDebugConsole::Msg(u32 type, const char* format, ...)
{
#ifndef NDLESS_DEBUG
	// Release builds capture nothing — the diagnostic log is development-only.
	return;
#endif
	// NDLESS: suppressed during boot (see g_ndLogEnable) so the flash log stays
	// small and its I/O never stalls the CPU. Only the render window is captured.
	if (!g_ndLogEnable) return;

	// NDLESS: Count messages for debugging
	static int msg_count = 0;
	msg_count++;

	// Buffer to hold formatted string
	char buffer[1024];

	// Initialize variable argument list
	va_list args;
	va_start(args, format);

	// Format the string
	vsnprintf(buffer, sizeof(buffer), format, args);

	// Clean up variable argument list
	va_end(args);

	// Append to the RAM buffer only — no flash I/O here (that stalls the CPU).
	LogWriteRaw(buffer);
	LogWriteRaw("\n");
}

void IDebugConsole::MsgOverwriteStart()
{
	// Not applicable without console
}

void IDebugConsole::MsgOverwrite(u32 type, const char * format, ...)
{
	// Not applicable without console
}

void IDebugConsole::MsgOverwriteEnd()
{
	// Not applicable without console
}

#endif // DAEDALUS_DEBUG_CONSOLE
