/*
   NDLESS boot-hang checkpoint probe - implementation.

   Keeps one static 320x240 RGB565 buffer and blits it to the LCD via lcd_blit()
   (which converts to the panel's native format, so this works on the CX II).
   Fully synchronous: after a call returns the pixels are on screen, which is
   what makes it survive a subsequent hard hang.
*/
#include "Debug/Checkpoint.h"

// The drawing infrastructure (font + framebuffer + lcd_blit) compiles whenever
// NDLESS is on, so the on-screen counter readout (Daedalus_ShowCounters) is
// always available for renderer bring-up. The old boot-probe functions below
// also compile but are only *called* via the DAEDALUS_NDLESS_CHECKPOINTS macros
// (currently disabled), so the spin-detector/tags/old-halt stay dead.
#if defined(DAEDALUS_NDLESS)

#include <libndls.h>

// NDLESS_DEBUG (Debug/Checkpoint.h) gates the whole on-screen diagnostic
// layer. When it is off (release builds) every probe painter below returns
// immediately, so the Daedalus_Show*/Checkpoint* calls scattered through the
// emulator become no-ops and nothing is drawn over the running game. The
// early return matters for speed too: some probes sit in hot paths (e.g.
// FlushTris) and would otherwise repaint a full 320x240 buffer every call.
#ifndef NDLESS_DEBUG
	#define ND_DBG_GUARD() return
#else
	#define ND_DBG_GUARD() ((void)0)
#endif

#define CHK_W 320
#define CHK_H 240

static u16 s_buf[CHK_W * CHK_H];

// 3x5 pixel hex font (0-F), one byte per row (low 3 bits = pixels, MSB-left).
static const unsigned char kFont[16][5] =
{
	{0x7,0x5,0x5,0x5,0x7}, // 0
	{0x2,0x6,0x2,0x2,0x7}, // 1
	{0x7,0x1,0x7,0x4,0x7}, // 2
	{0x7,0x1,0x7,0x1,0x7}, // 3
	{0x5,0x5,0x7,0x1,0x1}, // 4
	{0x7,0x4,0x7,0x1,0x7}, // 5
	{0x7,0x4,0x7,0x5,0x7}, // 6
	{0x7,0x1,0x1,0x2,0x2}, // 7
	{0x7,0x5,0x7,0x5,0x7}, // 8
	{0x7,0x5,0x7,0x1,0x7}, // 9
	{0x7,0x5,0x7,0x5,0x5}, // A
	{0x6,0x5,0x6,0x5,0x6}, // B
	{0x7,0x4,0x4,0x4,0x7}, // C
	{0x6,0x5,0x5,0x5,0x6}, // D
	{0x7,0x4,0x7,0x4,0x7}, // E
	{0x7,0x4,0x7,0x4,0x4}, // F
};

#define GLYPH_SCALE   4
#define GLYPH_W       (3 * GLYPH_SCALE)
#define GLYPH_H       (5 * GLYPH_SCALE)
#define GLYPH_GAP     GLYPH_SCALE
#define GLYPH_ADV     (GLYPH_W + GLYPH_GAP)
#define PAD           4
#define ROW_H         (GLYPH_H + GLYPH_SCALE)

static void FillRect(int x0, int y0, int w, int h, u16 colour)
{
	for (int y = y0; y < y0 + h && y < CHK_H; ++y)
	{
		if (y < 0) continue;
		u16 *row = &s_buf[y * CHK_W];
		for (int x = x0; x < x0 + w && x < CHK_W; ++x)
		{
			if (x < 0) continue;
			row[x] = colour;
		}
	}
}

static void DrawGlyph(int x0, int y0, int g, u16 colour)
{
	for (int ry = 0; ry < 5; ++ry)
	{
		unsigned char bits = kFont[g & 0xF][ry];
		for (int rx = 0; rx < 3; ++rx)
			if (bits & (0x4 >> rx))
				FillRect(x0 + rx * GLYPH_SCALE, y0 + ry * GLYPH_SCALE, GLYPH_SCALE, GLYPH_SCALE, colour);
	}
}

// Draw `ndigits` hex digits of `value`, left-to-right, at (x0,y0).
static void DrawHex(int x0, int y0, u32 value, int ndigits, u16 colour)
{
	for (int i = 0; i < ndigits; ++i)
	{
		int shift = (ndigits - 1 - i) * 4;
		DrawGlyph(x0 + i * GLYPH_ADV, y0, (int)((value >> shift) & 0xF), colour);
	}
}

// Draw decimal `value` (up to 10 digits), left-to-right, at (x0,y0). Returns width.
static int DrawDec(int x0, int y0, u32 value, u16 colour)
{
	int  digs[10];
	int  n = 0;
	if (value == 0) { digs[n++] = 0; }
	else { while (value > 0 && n < 10) { digs[n++] = (int)(value % 10); value /= 10; } }

	for (int i = 0; i < n; ++i)
		DrawGlyph(x0 + i * GLYPH_ADV, y0, digs[n - 1 - i], colour);
	return n * GLYPH_ADV;
}

// Global paint sequence number, stamped bottom-right on every probe screen.
// Distinguishes "genuinely frozen early" (small number) from "cycling through
// probe screens that merely LOOK static" (large number).
static u32 s_paintSeq = 0;

// Stack high-water mark: lowest SP observed at any probe paint. Every probe
// fires from a different depth of the synchronous emu/DL chain, so this is a
// cheap proxy for peak stack usage (Ndless apps run on the small OS task
// stack — overflow corrupts the heap/OS data below it).
u32 g_ndMinSP = 0xFFFFFFFF;

static void StampSeq()
{
	++s_paintSeq;
	u32 sp_now = (u32)(uintptr_t)__builtin_frame_address(0);
	if (sp_now < g_ndMinSP) g_ndMinSP = sp_now;
	DrawDec(CHK_W - 10 * GLYPH_ADV, CHK_H - 40 - ROW_H, s_paintSeq, 0x7BEF); // dim gray
}

extern "C" void Daedalus_Checkpoint(u16 rgb565)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = rgb565;

	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

extern "C" void Daedalus_CheckpointNum(u32 number)
{
	ND_DBG_GUARD();
	FillRect(0, 0, PAD * 2 + 10 * GLYPH_ADV, PAD * 2 + GLYPH_H, 0x0000);
	DrawDec(PAD, PAD, number, 0xFFFF);
	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Per-op trace readout: count (decimal), PC (hex8), opcode (hex8), stacked.
extern "C" void Daedalus_CheckpointTrace(u32 count, u32 pc, u32 opcode)
{
	ND_DBG_GUARD();
	const int plate_w = PAD * 2 + 10 * GLYPH_ADV;
	FillRect(0, 0, plate_w, PAD * 2 + 3 * ROW_H, 0x0000);

	int y = PAD;
	DrawDec(PAD, y, count, 0x07FF);            y += ROW_H; // cyan  : instruction count
	DrawHex(PAD, y, pc,     8, 0xFFE0);        y += ROW_H; // yellow: program counter
	DrawHex(PAD, y, opcode, 8, 0xFFFF);                    // white : opcode

	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Steady, readable diagnostic held on a detected spin loop. Green background so
// it is unmistakable that we locked onto a loop. Four rows:
//   count (dec), loop base PC (hex8), opcode (hex8), loop span in bytes (hex).
extern "C" void Daedalus_CheckpointHold(u32 count, u32 pc, u32 opcode, u32 span)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0400; // dark green

	int y = PAD;
	DrawDec(PAD, y, count, 0x07FF);            y += ROW_H; // cyan  : instruction count
	DrawHex(PAD, y, pc,     8, 0xFFE0);        y += ROW_H; // yellow: loop base PC
	DrawHex(PAD, y, opcode, 8, 0xFFFF);        y += ROW_H; // white : opcode at freeze
	DrawHex(PAD, y, span,   4, 0x07E0);                    // green : loop span (bytes)

	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Small square in the TOP-RIGHT corner marking which native subsystem is
// currently running. Blits only when the colour changes (cheap), so on a native
// hang the frozen square colour tells us which subsystem wedged. Coexists with
// the top-left counter (both preserve the rest of the shared buffer).
extern "C" void Daedalus_CheckpointTag(u16 colour)
{
	ND_DBG_GUARD();
	static u16 s_last = 0xDEAD;
	if (colour == s_last) return;
	s_last = colour;

	const int sz = 44;
	FillRect(CHK_W - sz - PAD, PAD, sz, sz, colour);
	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Live render-pipeline readout, painted straight to the LCD. No clean exit
// needed: whatever is on screen when execution sticks IS the diagnosis. Rows
// are prefixed with an index digit (0-7) and colour-coded:
//   0 white   icount (dec)      1 cyan    pc (hex)
//   2 yellow  DLcmds            3 orange  AddTri call
//   4 green   AddTri pass       5 magenta FlushTris
//   6 white   RenderTris        7 cyan    DrawVerts
extern "C" void Daedalus_ShowCounters(u32 icount, u32 dlcmds,
	u32 vi, u32 si, u32 dp, u32 pi, u32 sp, u32 int_taken)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0000;

	const int vx = PAD + 2 * GLYPH_ADV; // value column, after "N " index digit
	int y = PAD;

	DrawHex(PAD, y, 1,   1, 0xF800); DrawDec(vx, y, int_taken, 0xF800); y += ROW_H; // 1 RED  INT TAKEN (dispatched)
	DrawHex(PAD, y, 0,   1, 0xFFFF); DrawDec(vx, y, icount, 0xFFFF); y += ROW_H; // 0 white   icount
	DrawHex(PAD, y, 2,   1, 0xFFE0); DrawDec(vx, y, dlcmds, 0xFFE0); y += ROW_H; // 2 yellow  DLcmds
	DrawHex(PAD, y, 0xB, 1, 0xFFFF); DrawDec(vx, y, vi,     0xFFFF); y += ROW_H; // B white   VI raised
	DrawHex(PAD, y, 0xC, 1, 0xFD20); DrawDec(vx, y, si,     0xFD20); y += ROW_H; // C orange  SI raised
	DrawHex(PAD, y, 0xD, 1, 0x07FF); DrawDec(vx, y, dp,     0x07FF); y += ROW_H; // D cyan    DP raised
	DrawHex(PAD, y, 0xE, 1, 0x07E0); DrawDec(vx, y, pi,     0x07E0); y += ROW_H; // E green   PI raised
	DrawHex(PAD, y, 0xF, 1, 0xF81F); DrawDec(vx, y, sp,     0xF81F);             // F magenta SP raised

	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Slow spin-trace readout: pinpoints the loop the game is wedged in.
//   0 white   icount (dec, confirms it's still spinning)
//   1 cyan    PC (hex8)      current program counter
//   2 yellow  opcode (hex8)  instruction word at PC
//   3 green   lo (hex8)      lowest PC seen since last refresh
//   4 orange  hi (hex8)      highest PC seen since last refresh
//   5 magenta span (hex)     hi-lo = size of the loop in bytes
extern "C" void Daedalus_ShowSpin(u32 icount, u32 pc, u32 opcode, u32 lo, u32 hi)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0000;

	const int vx = PAD + 2 * GLYPH_ADV;
	int y = PAD;

	DrawHex(PAD, y, 0, 1, 0xFFFF); DrawDec(vx, y, icount,     0xFFFF); y += ROW_H;
	DrawHex(PAD, y, 1, 1, 0x07FF); DrawHex(vx, y, pc,     8,  0x07FF); y += ROW_H;
	DrawHex(PAD, y, 2, 1, 0xFFE0); DrawHex(vx, y, opcode, 8,  0xFFE0); y += ROW_H;
	DrawHex(PAD, y, 3, 1, 0x07E0); DrawHex(vx, y, lo,     8,  0x07E0); y += ROW_H;
	DrawHex(PAD, y, 4, 1, 0xFD20); DrawHex(vx, y, hi,     8,  0xFD20); y += ROW_H;
	DrawHex(PAD, y, 5, 1, 0xF81F); DrawHex(vx, y, hi - lo, 4, 0xF81F);

	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Per-op memory-access trace. Same top rows as ShowSpin, but the bottom three
// carry the load/store's effective address and operands so we can see exactly
// which memory region the wedged instruction is hitting.
//   0 white   icount        1 cyan   PC        2 yellow opcode
//   3 green   EA (target)   4 orange base reg  5 magenta value reg
extern "C" void Daedalus_ShowSpinMem(u32 icount, u32 pc, u32 opcode, u32 ea, u32 base, u32 val, u32 stage)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0000;

	const int vx = PAD + 2 * GLYPH_ADV;
	int y = PAD;

	DrawHex(PAD, y, 0, 1, 0xFFFF); DrawDec(vx, y, icount,     0xFFFF); y += ROW_H;
	DrawHex(PAD, y, 1, 1, 0x07FF); DrawHex(vx, y, pc,     8,  0x07FF); y += ROW_H;
	DrawHex(PAD, y, 2, 1, 0xFFE0); DrawHex(vx, y, opcode, 8,  0xFFE0); y += ROW_H;
	DrawHex(PAD, y, 3, 1, 0x07E0); DrawHex(vx, y, ea,     8,  0x07E0); y += ROW_H;
	DrawHex(PAD, y, 4, 1, 0xFD20); DrawHex(vx, y, base,   8,  0xFD20); y += ROW_H;
	DrawHex(PAD, y, 5, 1, 0xF81F); DrawHex(vx, y, val,    8,  0xF81F);

	// Full-width marker bar at the bottom: RED = pre-execute ("about to run this,
	// hang is INSIDE it"), GREEN = post-execute ("this one finished, hang is
	// after it"). Unmistakable even on a poor display.
	FillRect(0, CHK_H - 40, CHK_W, 40, stage ? 0x07E0 : 0xF800);

	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// RSP HLE task probe. Painted at task dispatch so a freeze inside the
// synchronous RSP_HLE_ProcessTask names the task and which handler it entered.
//   0 white   task type (hex8)
//   1 cyan    a  (ucode_boot_size)
//   2 yellow  b  (ucode addr / imem)
//   3 green   c  (data_ptr / dram)
// Bottom bar: 0=entry RED, 1=graphics CYAN, 2=audio MAGENTA, 3=other YELLOW.
extern "C" void Daedalus_ShowTask(u32 type, u32 a, u32 b, u32 c, u32 stage)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0000;

	const int vx = PAD + 2 * GLYPH_ADV;
	int y = PAD;

	DrawHex(PAD, y, 0, 1, 0xFFFF); DrawHex(vx, y, type, 8, 0xFFFF); y += ROW_H;
	DrawHex(PAD, y, 1, 1, 0x07FF); DrawHex(vx, y, a,    8, 0x07FF); y += ROW_H;
	DrawHex(PAD, y, 2, 1, 0xFFE0); DrawHex(vx, y, b,    8, 0xFFE0); y += ROW_H;
	DrawHex(PAD, y, 3, 1, 0x07E0); DrawHex(vx, y, c,    8, 0x07E0);

	u16 barcol = 0xF800;                 // 0 entry = red
	if      (stage == 1) barcol = 0x07FF; // graphics = cyan
	else if (stage == 2) barcol = 0xF81F; // audio    = magenta
	else if (stage == 3) barcol = 0xFFE0; // other    = yellow
	FillRect(0, CHK_H - 40, CHK_W, 40, barcol);

	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Display-list parser probe. Sampled every N commands inside DLParser_ProcessDList.
//   0 white   dlcount (dec)  cumulative DL commands dispatched
//   1 cyan    PC (hex8)      current DL fetch pointer (RDRAM offset)
//   2 yellow  cmd0 (hex8)    high word of the command about to run
//   3 green   cmd1 (hex8)    low word
//   4 orange  sp  (hex)      display-list stack depth
// Bottom bar is blue to distinguish from the task probe. If the dlcount digits
// keep changing on screen => infinite/cyclic DL; if frozen => a handler is stuck.
extern "C" void Daedalus_ShowDL(u32 dlcount, u32 pc, u32 cmd0, u32 cmd1, u32 sp)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0000;

	const int vx = PAD + 2 * GLYPH_ADV;
	int y = PAD;

	DrawHex(PAD, y, 0, 1, 0xFFFF); DrawDec(vx, y, dlcount,   0xFFFF); y += ROW_H;
	DrawHex(PAD, y, 1, 1, 0x07FF); DrawHex(vx, y, pc,   8,    0x07FF); y += ROW_H;
	DrawHex(PAD, y, 2, 1, 0xFFE0); DrawHex(vx, y, cmd0, 8,    0xFFE0); y += ROW_H;
	DrawHex(PAD, y, 3, 1, 0x07E0); DrawHex(vx, y, cmd1, 8,    0x07E0); y += ROW_H;
	DrawHex(PAD, y, 4, 1, 0xFD20); DrawHex(vx, y, sp,   4,    0xFD20);

	FillRect(0, CHK_H - 40, CHK_W, 40, 0x001F); // blue bar
	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// Generic stage marker for localizing a hang along the triangle path.
//   0 white   stage (dec)   which code stage we last entered
//   1 cyan    a (hex8)      2 yellow b (hex8)   3 green c (hex8)
// Bottom bar white so it's visually distinct from the other probes.
extern "C" void Daedalus_ShowStage(u32 stage, u32 a, u32 b, u32 c)
{
	ND_DBG_GUARD();
	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0000;

	const int vx = PAD + 2 * GLYPH_ADV;
	int y = PAD;

	DrawHex(PAD, y, 0, 1, 0xFFFF); DrawDec(vx, y, stage, 0xFFFF); y += ROW_H;
	DrawHex(PAD, y, 1, 1, 0x07FF); DrawHex(vx, y, a, 8,  0x07FF); y += ROW_H;
	DrawHex(PAD, y, 2, 1, 0xFFE0); DrawHex(vx, y, b, 8,  0xFFE0); y += ROW_H;
	DrawHex(PAD, y, 3, 1, 0x07E0); DrawHex(vx, y, c, 8,  0x07E0);

	FillRect(0, CHK_H - 40, CHK_W, 40, 0xFFFF); // white bar
	StampSeq();
	lcd_blit(s_buf, SCR_320x240_565);
}

// ---------------------------------------------------------------------------
// Persistent probe log: each call appends one line (stage dec + 3 hex words)
// to an in-RAM history and re-renders the WHOLE history to the screen. So no
// matter where execution dies, the final frozen screen shows every probe
// result of the run — no video recording needed. Small font (scale 2) fits
// 19 lines; wraps by dropping the oldest line.
#define SGL_SCALE 2
#define SGL_W     (3 * SGL_SCALE)
#define SGL_H     (5 * SGL_SCALE)
#define SGL_ADV   (SGL_W + SGL_SCALE)
#define SROW_H    (SGL_H + SGL_SCALE)
#define SLOG_MAX  19

static void DrawGlyph2(int x0, int y0, int g, u16 colour)
{
	for (int ry = 0; ry < 5; ++ry)
	{
		unsigned char bits = kFont[g & 0xF][ry];
		for (int rx = 0; rx < 3; ++rx)
			if (bits & (0x4 >> rx))
				FillRect(x0 + rx * SGL_SCALE, y0 + ry * SGL_SCALE, SGL_SCALE, SGL_SCALE, colour);
	}
}

static void DrawHex2(int x0, int y0, u32 value, int ndigits, u16 colour)
{
	for (int i = 0; i < ndigits; ++i)
		DrawGlyph2(x0 + i * SGL_ADV, y0, (int)((value >> ((ndigits - 1 - i) * 4)) & 0xF), colour);
}

static void DrawDec2(int x0, int y0, u32 value, u16 colour)
{
	int digs[10]; int n = 0;
	if (value == 0) digs[n++] = 0;
	else while (value > 0 && n < 10) { digs[n++] = (int)(value % 10); value /= 10; }
	for (int i = 0; i < n; ++i)
		DrawGlyph2(x0 + i * SGL_ADV, y0, digs[n - 1 - i], colour);
}

// Heap health probe: malloc(16)+free, logged. On a corrupted heap malloc
// never returns, so the LAST line on the panel names the latest point the
// heap was still sane — bisecting WHEN emulation tramples it.
extern "C" void Daedalus_HeapProbe(u32 tag)
{
	ND_DBG_GUARD();
	void * p = malloc(16);
	Daedalus_ShowStageLog(tag, (u32)(uintptr_t)p, 0, 0);
	free(p);
}

struct SLogEntry { u32 stage, a, b, c, seq; };
static SLogEntry s_slog[SLOG_MAX];
static int s_slogCount = 0;

extern "C" void Daedalus_ShowStageLog(u32 stage, u32 a, u32 b, u32 c)
{
	ND_DBG_GUARD();
	if (s_slogCount == SLOG_MAX) // drop oldest
	{
		for (int i = 1; i < SLOG_MAX; ++i) s_slog[i - 1] = s_slog[i];
		--s_slogCount;
	}
	++s_paintSeq;
	s_slog[s_slogCount++] = { stage, a, b, c, s_paintSeq };

	for (int i = 0; i < CHK_W * CHK_H; ++i)
		s_buf[i] = 0x0000;

	for (int i = 0; i < s_slogCount; ++i)
	{
		const SLogEntry & e = s_slog[i];
		int y = PAD + i * SROW_H;
		DrawDec2(PAD,                 y, e.stage, 0xFFFF);              // white
		DrawHex2(PAD +  4 * SGL_ADV,  y, e.a, 8, 0x07FF);               // cyan
		DrawHex2(PAD + 13 * SGL_ADV,  y, e.b, 8, 0xFFE0);               // yellow
		DrawHex2(PAD + 22 * SGL_ADV,  y, e.c, 8, 0x07E0);               // green
		DrawDec2(PAD + 31 * SGL_ADV,  y, e.seq, 0x7BEF);                // gray seq
	}
	lcd_blit(s_buf, SCR_320x240_565);
}

#endif // DAEDALUS_NDLESS
