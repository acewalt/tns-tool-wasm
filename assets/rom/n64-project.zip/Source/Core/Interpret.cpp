#include <libndls.h>
/*
Copyright (C) 2009 StrmnNrmn

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

// Stuff to handle Processor

// Comment out to remove all per-instruction histogram overhead.
#define DAEDALUS_ND_OPHIST 1

#include <cstdlib>	// NDLESS: exit() for the render-window log-capture clean exit

#include "Base/Types.h"

#include "Core/CPU.h"
#include "Debug/Registers.h"					// For REG_?? defines
#include "Core/Memory.h"
#include "Core/Interpret.h"
#include "Core/Interrupt.h"
#include "RomFile/ROMBuffer.h"
#include "Core/R4300.h"
#include "Interface/ConfigOptions.h"
#include "Debug/Checkpoint.h"
#include "Debug/DBGConsole.h"
#include "Debug/DebugLog.h"
#include "OSHLE/patch.h"				// GetCorrectOp
#include "Ultra/ultra_R4300.h"
#include "Base/Macros.h"
#include "Utility/Profiler.h"
#include "Debug/Synchroniser.h"

#if defined(DAEDALUS_NDLESS)
// Debug
static u64  g_ndCount   = 0;
static bool g_ndPhase3  = false;
static u32  g_ndPc, g_ndOp, g_ndEa, g_ndBase, g_ndVal;
#endif

//*****************************************************************************
//	Execute a single MIPS op. The conditionals for the templated arguments
//	are completely optimised away by the compiler.
//
//	TranslateOp:	Use this to translate breakpoints/patches to original op
//					before execution.
//*****************************************************************************
template< bool TranslateOp > inline void CPU_EXECUTE_OP()
{
	u8 * p_Instruction = 0;

	CPU_FETCH_INSTRUCTION( p_Instruction, gCPUState.CurrentPC );
	OpCode op_code = *(OpCode*)p_Instruction;

	// Cache instruction base pointer (used for SpeedHack() @ R4300.0)
	gLastAddress = p_Instruction;

#ifdef DAEDALUS_BREAKPOINTS_ENABLED
	if ( TranslateOp )
	{
		// Handle breakpoints correctly
		if (op_code.op == OP_DBG_BKPT)
		{
			// Turn temporary disable on to allow instr to be processed
			// Entry is in lower 26 bits...
			u32	breakpoint( op_code.bp_index );

			if ( breakpoint < g_BreakPoints.size() )
			{
				if (g_BreakPoints[ breakpoint ].mEnabled)
				{
					g_BreakPoints[ breakpoint ].mTemporaryDisable = true;
				}
			}
		}
		else
		{
			op_code = GetCorrectOp( op_code );
		}
	}
#endif

	SYNCH_POINT( DAED_SYNC_REG_PC, gCPUState.CurrentPC, "Program Counter doesn't match" );
	SYNCH_POINT( DAED_SYNC_FRAGMENT_PC, gCPUState.CurrentPC + gCPUState.Delay, "Program Counter/Delay doesn't match while interpreting" );

	SYNCH_POINT( DAED_SYNC_REG_PC, gCPUState.CPUControl[C0_COUNT]._u32, "Count doesn't match" );

#if defined(DAEDALUS_NDLESS)
	// DEBUG: Paint the counter every 1M ops or so until the first frame arrives to the screen.
	if (!TranslateOp)
	{
		extern u32 g_ndFrameBlits;
		if (g_ndFrameBlits == 0)
		{
			++g_ndCount;
			if ((g_ndCount & 0xFFFFF) == 0) // Every 1M ops
			{
				extern u32 g_dbgDLCommands, g_dbgVI, g_dbgSI, g_dbgDP, g_dbgPI, g_dbgSP, g_dbgIntTaken;
				Daedalus_ShowCounters((u32)g_ndCount, g_dbgDLCommands,
					g_dbgVI, g_dbgSI, g_dbgDP, g_dbgPI, g_dbgSP, g_dbgIntTaken);
			}
		}
	}
#endif

#if defined(DAEDALUS_NDLESS_CHECKPOINTS)
	if (!TranslateOp)
	{
		const u32 pc = gCPUState.CurrentPC;
		const u32 op = *(u32*)p_Instruction;

		static u64  s_icount   = 0;
		static bool s_reported = false;
		++s_icount;

		// Try to log the halt (the calculator doesn't write this unless the app exited out, so if it crashed then its a race condition)
		static const u64 kHaltAtCount = 18808832ull;
		if (s_icount == kHaltAtCount)
		{
			DBGConsole_Msg(0, "[YLOG-CAPTURE HALT at count=%u]", (u32)s_icount);
			CPU_Halt("log capture");
		}

		// Ring buffer of the 16 most recent ops == the loop body once spinning.
		static u32 s_ring_pc[16];
		static u32 s_ring_op[16];
		static u32 s_ring_i = 0;
		s_ring_pc[s_ring_i & 15] = pc;
		s_ring_op[s_ring_i & 15] = op;
		++s_ring_i;

		if (!s_reported)
		{
			if ((s_icount & 0xFFFF) == 0) // every 65536 ops (4x finer)
				DAEDALUS_CHECKPOINT_NUM((u32)s_icount);

			static const u64 kArmAfter   = 5000000ull;   // past the ~5M checksum; address gate excludes it anyway
			static const u32 kGameCodeLo = 0x80001000u;
			static const u64 kPersistOps = 4000000ull;   // high enough that legit long memcpy/loops pass; only a truly infinite loop trips it

			// Spin detection: how long has the PC stayed inside a small window?
			static u32 s_lo = 1, s_hi = 0, s_min = 0, s_max = 0; // lo>hi => forces re-anchor on first op
			static u64 s_region_start = 0;

			if (s_icount >= kArmAfter && pc >= kGameCodeLo && pc >= s_lo && pc <= s_hi)
			{
				if (pc < s_min) s_min = pc;
				if (pc > s_max) s_max = pc;

				if (s_icount - s_region_start >= kPersistOps)
				{
					s_reported = true;

					// On-screen readable freeze (green plate).
					DAEDALUS_CHECKPOINT_HOLD((u32)s_icount, s_min, op, s_max - s_min);

					// Log the loop body so a clean exit persists it to flash.
					DBGConsole_Msg(0, "[YSPIN DETECTED count=%u base=%08x span=%x]", (u32)s_icount, s_min, s_max - s_min);
					for (u32 k = 0; k < 16; ++k)
					{
						u32 idx = (s_ring_i + k) & 15; // oldest -> newest
						DBGConsole_Msg(0, "  loop[%u] pc=%08x op=%08x", k, s_ring_pc[idx], s_ring_op[idx]);
					}

					// Break the CPU loop cleanly -> returns to ROM menu, where
					// ESC exits the app and commits the log to flash.
					CPU_Halt("spin detected");
				}
			}
			else
			{
				s_lo = pc - 0x400;
				s_hi = pc + 0x400;
				s_min = pc;
				s_max = pc;
				s_region_start = s_icount;
			}
		}
	}
#endif

#if defined(DAEDALUS_NDLESS) && defined(DAEDALUS_ND_OPHIST)
	// Opcode histogram: one indexed increment per executed op. Shows where the
	// interpreter spends its instruction budget. Compile out with DAEDALUS_ND_OPHIST.
	if (!TranslateOp)
	{
		extern u32 g_opHist[64], g_opSpecHist[64];
		++g_opHist[op_code.op];
		if (op_code.op == 0) ++g_opSpecHist[op_code.spec_op];
	}
#endif

	R4300_ExecuteInstruction(op_code);
	gGPR[0]._u64 = 0;	//Ensure r0 is zero

#ifdef DAEDALUS_PROFILE_EXECUTION
		gTotalInstructionsEmulated++;
#endif

	SYNCH_POINT( DAED_SYNC_REGS, CPU_ProduceRegisterHash(), "Registers don't match" );

	// Increment count register
	gCPUState.CPUControl[C0_COUNT]._u32 = gCPUState.CPUControl[C0_COUNT]._u32 + COUNTER_INCREMENT_PER_OP;

	if (CPU_ProcessEventCycles( COUNTER_INCREMENT_PER_OP ) )
	{
		CPU_HANDLE_COUNT_INTERRUPT();
	}

	switch (gCPUState.Delay)
	{
	case DO_DELAY:
		// We've got a delayed instruction to execute. Increment
		// PC as normal, so that subsequent instruction is executed
		INCREMENT_PC();
		gCPUState.Delay = EXEC_DELAY;

		break;
	case EXEC_DELAY:
		{
			//bool	backwards( gCPUState.TargetPC <= gCPUState.CurrentPC );

			// We've just executed the delayed instr. Now carry out jump as stored in gCPUState.TargetPC;
			CPU_SetPC(gCPUState.TargetPC);
			gCPUState.Delay = NO_DELAY;

		}
		break;
	case NO_DELAY:
		// Normal operation - just increment the PC
		INCREMENT_PC();
		break;
	}
}


//*****************************************************************************
// Keep executing instructions until there are other tasks to do (i.e. gCPUState.GetStuffToDo() is set)
// Process these tasks and loop
//*****************************************************************************
void CPU_Go()
{
	DAEDALUS_PROFILE( __FUNCTION__ );

	while (CPU_KeepRunning())
	{
		//
		// Keep executing ops as long as there's nothing to do
		//
		u32	stuff_to_do( gCPUState.GetStuffToDo() );
		while(stuff_to_do == 0)
		{
			CPU_EXECUTE_OP< false >();
static unsigned tns_poll=0;if((++tns_poll&16383)==0&&isKeyPressed(KEY_NSPIRE_ESC))CPU_Halt("User exit");

			stuff_to_do = gCPUState.GetStuffToDo();
		}

		if (CPU_CheckStuffToDo())
			break;
	}
}


void Inter_SelectCore()
{
   g_pCPUCore = CPU_Go;
}

//*****************************************************************************
// Hacky function to use when debugging
//*****************************************************************************
void CPU_Skip()
{
	#ifdef DAEDALUS_DEBUG_CONSOLE
	if (CPU_IsRunning())
	{
		DBGConsole_Msg(0, "Already Running");
		return;
	}
#endif
	INCREMENT_PC();
}

//*****************************************************************************
//
//*****************************************************************************
void CPU_Step()
{
		#ifdef DAEDALUS_DEBUG_CONSOLE
	if (CPU_IsRunning())
	{
		DBGConsole_Msg(0, "Already Running");
		return;
	}
#endif

	CPU_CheckStuffToDo();

	CPU_EXECUTE_OP< true >();
}
