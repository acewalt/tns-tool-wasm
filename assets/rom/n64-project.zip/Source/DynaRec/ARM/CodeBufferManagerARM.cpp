/*
Copyright (C) 2020 MasterFeizz

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


#include <stdio.h>
#include <malloc.h>

#ifdef DAEDALUS_CTR
#include "SysCTR/Utility/MemoryCTR.h"
#endif

#ifdef DAEDALUS_NDLESS
// SysNDLESS/Utility/CacheNDLESS.S: ARM926 test-and-clean D-cache + I-cache
// invalidate. Must run after every code emission (see FinaliseCurrentBlock).
extern "C" void _InvalidateAndFlushCaches();
#endif

#include "DynaRec/CodeBufferManager.h"
#include "Debug/Checkpoint.h"
#include "Debug/DBGConsole.h"
#include "CodeGeneratorARM.h"

#if defined(DAEDALUS_NDLESS)
// The CX II has 64MB total for OS + app + ROM + RDRAM + textures: keep the
// code buffer modest.
#define CODE_BUFFER_SIZE (2 * 1024 * 1024)
#else
#define CODE_BUFFER_SIZE (8 * 1024 * 1024)
#endif

class CCodeBufferManagerARM : public CCodeBufferManager
{
public:
	CCodeBufferManagerARM()
		:	mpBuffer( NULL )
		,	mBufferPtr( 0 )
		,	mBufferSize( 0 )
		,	mpSecondBuffer( NULL )
		,	mSecondBufferPtr( 0 )
		,	mSecondBufferSize( 0 )
	{
	}

	virtual bool			Initialise();
	virtual void			Reset();
	virtual void			Finalise();

	virtual std::shared_ptr<CCodeGenerator> StartNewBlock();
	virtual u32				FinaliseCurrentBlock();

private:

	u8	*					mpBuffer;
	u32						mBufferPtr;
	u32						mBufferSize;

	u8 *					mpSecondBuffer;
	u32						mSecondBufferPtr;
	u32						mSecondBufferSize;

private:
	CAssemblyBuffer			mPrimaryBuffer;
	CAssemblyBuffer			mSecondaryBuffer;
};


std::shared_ptr<CCodeBufferManager>	CCodeBufferManager::Create()
{
	return std::make_shared<CCodeBufferManagerARM>();
}


bool	CCodeBufferManagerARM::Initialise()
{
	// mpSecondBuffer is currently unused

	#ifdef DAEDALUS_CTR
	mpBuffer = (u8*)memalign(4096, CODE_BUFFER_SIZE*2);
	mpSecondBuffer = mpBuffer + CODE_BUFFER_SIZE;
	if (mpBuffer == NULL || mpSecondBuffer == NULL)
		return false;

	_SetMemoryPermission((unsigned int*)mpBuffer, CODE_BUFFER_SIZE*2, 7);
	//_SetMemoryPermission((unsigned int*)mpSecondBuffer, CODE_BUFFER_SIZE, 7);
	#elif defined(DAEDALUS_NDLESS)
	// NDLESS: The ARM926 MMU has no execute-never bit, so anything readable is executable.
	// CacheNDLESS.S handles I/D sync.
	mpBuffer = (u8*)memalign(4096, CODE_BUFFER_SIZE*2);
	mpSecondBuffer = mpBuffer + CODE_BUFFER_SIZE;
	if (mpBuffer == NULL)
		return false;
	#endif

	mBufferPtr = 0;
	mBufferSize = 0;

	mSecondBufferPtr = 0;
	mSecondBufferSize = 0;

	return true;
}


void	CCodeBufferManagerARM::Reset()
{
	mBufferPtr = 0;
	mSecondBufferPtr = 0;
}


void	CCodeBufferManagerARM::Finalise()
{
	if (mpBuffer != NULL && mpSecondBuffer != NULL)
	{
		#ifdef DAEDALUS_CTR
		_SetMemoryPermission((unsigned int*)mpBuffer, CODE_BUFFER_SIZE*2 / 4096, 3);
		//_SetMemoryPermission((unsigned int*)mpSecondBuffer, CODE_BUFFER_SIZE / 4096, 3);
		#endif
		
		free(mpBuffer);
		//free(mpSecondBuffer);

		mpBuffer = NULL;
		mpSecondBuffer = NULL;
	}
}


std::shared_ptr<CCodeGenerator> CCodeBufferManagerARM::StartNewBlock()
{
	#if defined(DAEDALUS_NDLESS)
	// gFragmentCache is a GLOBAL, so Initialise() (and its 4MB memalign) runs
	// at static-init and FragmentCache.cpp ignores its return value. If that
	// alloc failed, mpBuffer is NULL and the compiler would emit code over
	// address 0 -> instant reboot. Retry the alloc here (ROM-open time, heap
	// state differs); if it still fails, park VISIBLY on stage 0xDE instead of
	// silently rebooting the calc.
	if (mpBuffer == NULL)
	{
		mpBuffer = (u8*)memalign(4096, CODE_BUFFER_SIZE*2);
		mpSecondBuffer = mpBuffer + CODE_BUFFER_SIZE;
		if (mpBuffer == NULL)
		{
			Daedalus_ShowStageLog(0xDE, CODE_BUFFER_SIZE*2, 0, 0); // OOM: no code buffer
			for (;;) {} // deliberate halt — panel readable, user force-reboots
		}
	}
	// Never start a block without room for the worst-case fragment (~160KB of interpreter-callout code).
	if (mBufferPtr > CODE_BUFFER_SIZE - (160u * 1024u) ||
	    mSecondBufferPtr > CODE_BUFFER_SIZE - (160u * 1024u))
	{
		Daedalus_ShowStageLog(0xDF, mBufferPtr, mSecondBufferPtr, 0);
		for (;;) {}
	}
	#endif

	// Round up to 16 byte boundry
	u32 aligned_ptr = (mBufferPtr + 15) & (~15);

	mBufferPtr = aligned_ptr;

	u32 aligned_ptr2 = (mSecondBufferPtr + 15) & (~15);
	mSecondBufferPtr = aligned_ptr2;

	mPrimaryBuffer.SetBuffer( mpBuffer + mBufferPtr );
	mSecondaryBuffer.SetBuffer( mpSecondBuffer + mSecondBufferPtr );

	return std::make_shared<CCodeGeneratorARM>( &mPrimaryBuffer, &mSecondaryBuffer );
}


u32 CCodeBufferManagerARM::FinaliseCurrentBlock()
{
	u32		main_block_size( mPrimaryBuffer.GetSize() );

	mBufferPtr += main_block_size;
	mSecondBufferPtr += mSecondaryBuffer.GetSize();

	#if 0 //Second buffer is currently unused
	mSecondBufferPtr += mSecondaryBuffer.GetSize();
	mSecondBufferPtr = ((mSecondBufferPtr - 1) & 0xfffffff0) + 0x10; // align to 16-byte boundary
	#endif

	#if defined(DAEDALUS_CTR) || defined(DAEDALUS_NDLESS)
	// NDLESS: MANDATORY. The ARM926 D-cache is write-back and split from the
	// I-cache: freshly emitted code sits in the D-cache while the I-cache
	// fetches stale RAM -> executes garbage -> hard reboot.
	_InvalidateAndFlushCaches();
	#if defined(DAEDALUS_NDLESS)
	{ extern u32 g_ndCacheFlushes; ++g_ndCacheFlushes; }
	#endif
	#endif

	return main_block_size;
}
