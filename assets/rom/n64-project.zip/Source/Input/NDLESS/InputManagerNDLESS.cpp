// Input manager for NDLESS - TI-Nspire CX II button mapping

#include "Input/InputManager.h"
#include "Ultra/ultra_os.h"
#include <libndls.h>

class CInputManagerNDLESS : public CInputManager
{
public:
	CInputManagerNDLESS() {}
	virtual ~CInputManagerNDLESS() {}

	virtual bool			Initialise() { return true; }
	virtual void			Finalise() {}

	virtual void			GetState(OSContPad pPad[4])
	{
		// Only controller 1 supported on NDLESS
		pPad[0].button = 0;
		pPad[0].stick_x = 0;
		pPad[0].stick_y = 0;

		// Face buttons
		if (isKeyPressed(KEY_NSPIRE_MINUS))  pPad[0].button |= A_BUTTON;
		if (isKeyPressed(KEY_NSPIRE_PLUS))   pPad[0].button |= B_BUTTON;
		if (isKeyPressed(KEY_NSPIRE_ENTER))  pPad[0].button |= START_BUTTON;
		if (isKeyPressed(KEY_NSPIRE_CTRL))   pPad[0].button |= Z_TRIG;

		// Shoulder buttons
		if (isKeyPressed(KEY_NSPIRE_SHIFT))  pPad[0].button |= L_TRIG;
		if (isKeyPressed(KEY_NSPIRE_VAR))    pPad[0].button |= R_TRIG;

		// C buttons (arrow keys)
		if (isKeyPressed(KEY_NSPIRE_UP))     pPad[0].button |= U_CBUTTONS;
		if (isKeyPressed(KEY_NSPIRE_DOWN))   pPad[0].button |= D_CBUTTONS;
		if (isKeyPressed(KEY_NSPIRE_LEFT))   pPad[0].button |= L_CBUTTONS;
		if (isKeyPressed(KEY_NSPIRE_RIGHT))  pPad[0].button |= R_CBUTTONS;

		// D-Pad - TODO: Map to appropriate keys
		// if (isKeyPressed(KEY_NSPIRE_???))  pPad[0].button |= U_JPAD;
		// if (isKeyPressed(KEY_NSPIRE_???))  pPad[0].button |= D_JPAD;
		// if (isKeyPressed(KEY_NSPIRE_???))  pPad[0].button |= L_JPAD;
		// if (isKeyPressed(KEY_NSPIRE_???))  pPad[0].button |= R_JPAD;

		// Analog stick (number keys 1-9 like numpad)
		// Range: -80 to +80
		if (isKeyPressed(KEY_NSPIRE_8)) {
			// UP
			pPad[0].stick_y = 80;
		} else if (isKeyPressed(KEY_NSPIRE_9)) {
			// UP-RIGHT
			pPad[0].stick_x = 57;
			pPad[0].stick_y = 57;
		} else if (isKeyPressed(KEY_NSPIRE_6)) {
			// RIGHT
			pPad[0].stick_x = 80;
		} else if (isKeyPressed(KEY_NSPIRE_3)) {
			// DOWN-RIGHT
			pPad[0].stick_x = 57;
			pPad[0].stick_y = -57;
		} else if (isKeyPressed(KEY_NSPIRE_2)) {
			// DOWN
			pPad[0].stick_y = -80;
		} else if (isKeyPressed(KEY_NSPIRE_1)) {
			// DOWN-LEFT
			pPad[0].stick_x = -57;
			pPad[0].stick_y = -57;
		} else if (isKeyPressed(KEY_NSPIRE_4)) {
			// LEFT
			pPad[0].stick_x = -80;
		} else if (isKeyPressed(KEY_NSPIRE_7)) {
			// UP-LEFT
			pPad[0].stick_x = -57;
			pPad[0].stick_y = 57;
		}

		if(isKeyPressed(KEY_NSPIRE_8)||isKeyPressed(KEY_NSPIRE_2)||isKeyPressed(KEY_NSPIRE_4)||isKeyPressed(KEY_NSPIRE_6)){pPad[0].stick_x=80*(isKeyPressed(KEY_NSPIRE_6)-isKeyPressed(KEY_NSPIRE_4));pPad[0].stick_y=80*(isKeyPressed(KEY_NSPIRE_8)-isKeyPressed(KEY_NSPIRE_2));if(pPad[0].stick_x&&pPad[0].stick_y){pPad[0].stick_x=pPad[0].stick_x*57/80;pPad[0].stick_y=pPad[0].stick_y*57/80;}}
		// Controllers 2-4 not connected
		for (int i = 1; i < 4; i++)
		{
			pPad[i].button = 0;
			pPad[i].stick_x = 0;
			pPad[i].stick_y = 0;
		}
	}

	virtual u32				GetNumConfigurations() const { return 1; }
	virtual const char *	GetConfigurationName(u32 configuration_idx) const { return "NDLESS"; }
	virtual const char *	GetConfigurationDescription(u32 configuration_idx) const { return "TI-Nspire NDLESS Default"; }
	virtual void			SetConfiguration(u32 configuration_idx) {}
	virtual u32				GetConfigurationFromName(const char * name) const { return 0; }
};

// Singleton factory
template<> bool CSingleton<CInputManager>::Create()
{
	DAEDALUS_ASSERT_Q(mpInstance == nullptr);
	mpInstance = std::make_shared<CInputManagerNDLESS>();
	return mpInstance->Initialise();
}

std::shared_ptr<CInputManager> CreateInputManager()
{
	return std::make_shared<CInputManagerNDLESS>();
}
