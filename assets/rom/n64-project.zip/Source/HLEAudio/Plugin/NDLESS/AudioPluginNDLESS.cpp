// Audio plugin stub for NDLESS (no audio hardware)

#include "HLEAudio/AudioPlugin.h"
#include "Interface/ConfigOptions.h"

// NDLESS has no audio support, disable.
EAudioPluginMode gAudioPluginEnabled = APM_DISABLED;

class CAudioPluginNDLESS : public CAudioPlugin
{
public:
	CAudioPluginNDLESS() {}
	virtual ~CAudioPluginNDLESS() {}

	virtual bool			StartEmulation() { return true; }
	virtual void			StopEmulation() {}
	virtual void			DacrateChanged(int system_type) {}
	virtual void			LenChanged() {}
	virtual u32				ReadLength() { return 0; }
	virtual EProcessResult	ProcessAList() { return PR_COMPLETED; }
};

std::unique_ptr<CAudioPlugin> CreateAudioPlugin()
{
	return std::make_unique<CAudioPluginNDLESS>();
}
