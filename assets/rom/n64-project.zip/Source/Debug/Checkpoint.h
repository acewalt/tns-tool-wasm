/*
   NDLESS boot-hang checkpoint probe.

   Synchronous LCD paint (no file I/O, no flush, no graphics-plugin dependency)
   so that on a hard hang the last thing drawn tells us how far execution got.

   Primitives:
     Daedalus_Checkpoint(colour)          - fill the screen with a solid colour.
     Daedalus_CheckpointNum(number)       - overlay a decimal number top-left.
     Daedalus_CheckpointTrace(cnt,pc,op)  - overlay 3 rows: instruction count
                                            (decimal), PC (hex), opcode (hex).
                                            Used per-op in the danger window so a
                                            freeze shows the exact culprit.

   Call sites use the macros, which compile to nothing on non-NDLESS builds.
*/
#ifndef DEBUG_CHECKPOINT_H_
#define DEBUG_CHECKPOINT_H_

#include "Base/Types.h"

// NDLESS_DEBUG: master switch for the on-device diagnostic layer. LEFT OFF for
// release builds, so a normal user gets none of the development instrumentation:
//   - no debug log file written to /documents (it would grow to megabytes
//     during a long session),
//   - no on-screen probe numbers painted over the game while it boots and runs,
//   - no '.' screenshot key.
// Define it (uncomment below, or pass -DNDLESS_DEBUG to the compiler) to build
// the full diagnostic layer back in for development. The probe functions are
// still linked either way; when this is off their bodies simply return, so the
// probe calls scattered through the emulator become no-ops.
//#if defined(DAEDALUS_NDLESS)
//	#define NDLESS_DEBUG 1
//#endif

// RGB565 checkpoint colours.
#define CHK_RED     0xF800
#define CHK_ORANGE  0xFD20
#define CHK_GREEN   0x07E0
#define CHK_BLUE    0x001F
#define CHK_YELLOW  0xFFE0
#define CHK_WHITE   0xFFFF

// Enable checkpoints on NDLESS builds. Comment out to compile them all away.
// DISABLED for renderer bring-up: the full-screen tag/counter blits fight the
// game framebuffer, and the spin-detector/halt-at-count in Interpret.cpp (which
// is gated on this same macro) is no longer needed now the boot hang is fixed.
// Re-enable by uncommenting if we need the on-LCD boot probe again.
//#if defined(DAEDALUS_NDLESS)
//	#define DAEDALUS_NDLESS_CHECKPOINTS 1
//#endif

#if defined(DAEDALUS_NDLESS_CHECKPOINTS)
	#ifdef __cplusplus
	extern "C" {
	#endif
	void Daedalus_Checkpoint(u16 rgb565);
	void Daedalus_CheckpointNum(u32 number);
	void Daedalus_CheckpointTrace(u32 count, u32 pc, u32 opcode);
	void Daedalus_CheckpointHold(u32 count, u32 pc, u32 opcode, u32 span);
	void Daedalus_CheckpointTag(u16 colour); // small top-right square, marks native subsystem
	#ifdef __cplusplus
	}
	#endif
	#define DAEDALUS_CHECKPOINT(colour)        Daedalus_Checkpoint(colour)
	#define DAEDALUS_CHECKPOINT_NUM(n)         Daedalus_CheckpointNum(n)
	#define DAEDALUS_CHECKPOINT_TRACE(c,p,o)   Daedalus_CheckpointTrace(c,p,o)
	#define DAEDALUS_CHECKPOINT_HOLD(c,p,o,s)  Daedalus_CheckpointHold(c,p,o,s)
	#define DAEDALUS_CHECKPOINT_TAG(colour)    Daedalus_CheckpointTag(colour)
#else
	#define DAEDALUS_CHECKPOINT(colour)        do {} while (0)
	#define DAEDALUS_CHECKPOINT_NUM(n)         do {} while (0)
	#define DAEDALUS_CHECKPOINT_TRACE(c,p,o)   do {} while (0)
	#define DAEDALUS_CHECKPOINT_HOLD(c,p,o,s)  do {} while (0)
	#define DAEDALUS_CHECKPOINT_TAG(colour)    do {} while (0)
#endif

// Live on-screen render-pipeline readout. Always available on NDLESS (not gated
// on the checkpoint macro), so it works for renderer bring-up while the old
// boot-probe checkpoints stay disabled. Reads straight to the LCD via lcd_blit.
#if defined(DAEDALUS_NDLESS)
	#ifdef __cplusplus
	extern "C" {
	#endif
	void Daedalus_ShowCounters(u32 icount, u32 dlcmds,
		u32 vi, u32 si, u32 dp, u32 pi, u32 sp, u32 int_taken);
	// Slow spin-trace: current PC, opcode there, and rolling loop bounds.
	void Daedalus_ShowSpin(u32 icount, u32 pc, u32 opcode, u32 lo, u32 hi);
	// Per-op memory-access trace: effective address + base/value registers,
	// for pinpointing a load/store that wedges the memory handler.
	void Daedalus_ShowSpinMem(u32 icount, u32 pc, u32 opcode, u32 ea, u32 base, u32 val, u32 stage);
	// RSP HLE task probe: painted at task dispatch so a freeze inside a
	// synchronous RSP_HLE_ProcessTask names the task type + which handler.
	// stage: 0=entry(red) 1=graphics(cyan) 2=audio(magenta) 3=other(yellow).
	void Daedalus_ShowTask(u32 type, u32 a, u32 b, u32 c, u32 stage);
	// Display-list parser probe: sampled inside DLParser_ProcessDList so a hang
	// shows the running DL command count, current PC, cmd words, and stack depth.
	// A climbing count => cyclic/infinite DL; a frozen count => a stuck handler.
	void Daedalus_ShowDL(u32 dlcount, u32 pc, u32 cmd0, u32 cmd1, u32 sp);
	// Generic stage marker: paints a big stage id + 3 values. Used to localize a
	// hang along the triangle path (batch loop / FlushTris / clip / render).
	void Daedalus_ShowStage(u32 stage, u32 a, u32 b, u32 c);
	// Persistent probe log: appends one small line (stage dec + a/b/c hex) and
	// re-renders the whole history each call, so the final frozen screen shows
	// every probe result of the run. Use for quit-path / one-shot probes.
	void Daedalus_ShowStageLog(u32 stage, u32 a, u32 b, u32 c);
	// malloc(16)+free+log line. On a corrupted heap malloc hangs, so the last
	// panel line names the latest point the heap was still sane.
	void Daedalus_HeapProbe(u32 tag);
	// Write the RAM-buffered debug log (DBGConsoleNDLESS) to flash in one shot.
	// Call only when stopped (e.g. the clean-exit halt) — never mid-emulation.
	void Daedalus_FlushLog();
	// Current length of the RAM log buffer (diagnostics for the quit path).
	u32  Daedalus_LogLen(void);
	// longjmp back to main() -> flush log -> return 0 (clean exit that commits
	// files to flash). Works from ANY depth, including inside the synchronous
	// RSP/graphics chain where CPU_Halt never unwinds.
	void Daedalus_ForceQuit(void);
	#ifdef __cplusplus
	}
	#endif

	// High-res tick source: the OTHERWISE-UNUSED SP804-style timer at
	// 0x900C0000 (found disabled: value pinned at reset 0xFFFFFFFF, load 0,
	// while the OS runs its own tick on 0x900D0000). Daedalus_TimerInit()
	// starts it free-running; Daedalus_Ticks() reads an UP-counting value
	// (down-counter complemented). Rate calibrated offline against the RTC.
	static inline void Daedalus_TimerInit(void)
	{
		*(volatile unsigned *)0x900C0000 = 0xFFFFFFFFu; // load = max
		// SP804 control: bit7 enable, bit6=0 free-running, bit5=0 no irq,
		// bit3 32-bit mode, bits2-1 prescale /1.
		*(volatile unsigned *)0x900C0008 = (1u << 7) | (1u << 3);
	}
	static inline unsigned Daedalus_Ticks(void)
	{
		return ~(*(volatile unsigned *)0x900C0004); // down -> up
	}

	#ifdef __cplusplus
	extern "C" {
	#endif
	#ifdef __cplusplus
	}
	#endif
#endif

// Native subsystem tag colours (top-right square).
#define TAG_GFX    0x07FF  // cyan   : RSP graphics / ProcessDList
#define TAG_AUDIO  0xF81F  // magenta: RSP audio / ProcessAList
#define TAG_SCREEN 0x07E0  // green  : UpdateScreen

#endif // DEBUG_CHECKPOINT_H_
