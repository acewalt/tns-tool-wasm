#include "single-thread.h"
/*
    Copyright 2019-2026 Hydr8gon

    This file is part of NooDS.

    NooDS is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NooDS is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NooDS. If not, see <https://www.gnu.org/licenses/>.
*/

#pragma once

#include <string>
#include <vector>

struct Setting {
    std::string name;
    void *value;
    bool isString;

    Setting(std::string name, void *value, bool isString):
        name(name), value(value), isString(isString) {}
};

class Settings {
public:
    static int directBoot;
    static int romInRam;
    static int fpsLimiter;
    static int frameskip;
    static int threaded2D;
    static int threaded3D;
    static int highRes3D;
    static int screenGhost;
    static int emulateAudio;
    static int audio16Bit;
    static int savesFolder;
    static int statesFolder;
    static int cheatsFolder;
    static int screenFilter;
    static int dsiMode;
    static int arm7Hle;

    static std::string gbaBiosPath;
    static std::string ndsBios9Path;
    static std::string ndsBios7Path;
    static std::string ndsFirmPath;
    static std::string dsiBios9Path;
    static std::string dsiBios7Path;
    static std::string dsiFirmPath;
    static std::string dsiNandPath;
    static std::string sdImagePath;
    static std::string basePath;

    static void add(std::vector<Setting> &settings);
    static bool load(std::string path = ".");
    static bool save();

private:
    static std::vector<Setting> settings;
    Settings() {} // Private to prevent instantiation
};
